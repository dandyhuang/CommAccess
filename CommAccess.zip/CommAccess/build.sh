#!/bin/sh

APP_NAME="CommAcc"
SERVER_NAME="CommAccess"
UPLOAD_EXTRA_PARAMS="-set comm_access.sz.songliao"

python -c "import spp_rpc_tools"
if [ $? -ne 0 ]; then
    pip install spp-rpc-tools --upgrade -i https://mirrors.tencent.com/repository/pypi/tencent_pypi/simple --extra-index-url https://mirrors.tencent.com/pypi/simple/
fi

tools_path=`python -c "import spp_rpc_tools as _; print(_.__path__)" | awk 'BEGIN{FS="\047"} {print $2}'`
echo "tool_path:$tools_path"

source $tools_path/scripts/build.sh
