// Copyright 2020 Tencent authors.
#include <gtest/gtest.h>

#include "spp_rpc/spp_rpc.h"
#include "src/codec/qmf_protocol.h"
#include "src/comm/docker_env.h"
#include "test/env_test.spp_rpc.pb.h"

using com::tencent::spp_rpc::bazel::EnvInfoRequest;
using com::tencent::spp_rpc::bazel::EnvInfoResponse;

struct TestCase {
  std::string polaris_name;
  std::string env_trans_info;
  std::string want_env;
  std::string want_set;
  std::string want_ip;
};

void CheckRsp(const EnvInfoResponse& rsp, const TestCase& item) {
  std::string json_content;
  google::protobuf::util::MessageToJsonString(rsp, &json_content);
  RPC_TLOG("rsp info:\n%s", json_content.c_str());

  if (item.want_env != "*") {
    EXPECT_EQ(rsp.env(), item.want_env);
  }
  if (item.want_set != "*") {
    EXPECT_EQ(rsp.set(), item.want_set);
  }
  if (item.want_ip != "*") {
    EXPECT_EQ(rsp.ip(), item.want_ip);
  }
}

int PbTest(const TestCase& item) {
  if (::spp_rpc::IsOnline()) {
    RPC_TLOG("route_name:%s, is online, filter ...", item.polaris_name.c_str());
    return 0;
  }
  RPC_TLOG("route_name:%s", item.polaris_name.c_str());
  spp_rpc::TrpcMsg msg;
  auto head = msg.GetVideoMutableReqHead();
  head->mutable_bucket_info()->set_bucket_id(4);
  head->mutable_version_info()->set_app_id("1000005");
  if (item.env_trans_info.size()) {
    msg.mutable_req()->logic_header.mutable_trans_info()->insert(
        {"trpc-env", item.env_trans_info});
  }
  msg.UpdateHead();

  if (item.env_trans_info.size()) {
    RPC_TLOG("set polaris env trans_info: %s", item.env_trans_info.c_str());
    msg.mutable_req()->logic_header.mutable_trans_info()->insert(
        {"trpc-env", item.env_trans_info});
  }

  auto ptr =
      spp_rpc::GetServantProxy<com::tencent::spp_rpc::bazel::RpcHelloProxyPtr>(
          item.polaris_name);
  ptr->set_servant_name("com.tencent.spp_rpc.bazel.RpcHello");

  // 实例化请求和回包
  EnvInfoRequest req;
  EnvInfoResponse rsp;
  auto status = ptr->GetEnvInfo(req, &rsp, msg.context());
  EXPECT_TRUE(status.Ok());
  if (!status.Ok()) {
    RPC_LOG_RET(status.GetOneCode(), "route_name:%s err",
                item.polaris_name.c_str());
  }

  CheckRsp(rsp, item);

  return 0;
}

void QmfPolarisTest(const TestCase& item) {
  comm_access::qmf_protocol::QmfHelper helper;
  helper.Init();
  helper.mutable_qmf_head()->Flag = 0x20213;
  helper.mutable_qmf_head()->ResvLen = 16;
  helper.mutable_qmf_head()->Resv[2] = 16;

  comm_access::qmf_protocol::VideoRequestProtocol frame_req;
  frame_req.logic_header.set_callee("com.tencent.spp_rpc.bazel.RpcHello");
  frame_req.logic_header.set_func(
      "/com.tencent.spp_rpc.bazel.RpcHello/GetEnvInfo");

  frame_req.logic_header.mutable_version_info()->set_app_id("1000005");
  frame_req.logic_header.mutable_bucket_info()->set_bucket_id(4);
  if (item.env_trans_info.size()) {
    frame_req.logic_header.mutable_env_info()->mutable_metadata()->insert(
        {"trpc-env", item.env_trans_info});
    frame_req.logic_header.mutable_env_info()->set_name("songliao");
  }

  EnvInfoRequest req;
  EnvInfoResponse rsp;
  frame_req.EncodeBody(req);

  std::vector<char> req_buf;
  frame_req.Encode(&req_buf);
  helper.Encode(req_buf.data(), req_buf.size());

  char* rsp_buf = nullptr;
  size_t rsp_len = 0;
  auto ptr = spp_rpc::GetServantProxy<spp_rpc::BinaryRpcProxyPtr>("qmf_test");
  int ret = ptr->Exec(helper.rsp_buf(), helper.rsp_buff_len(), &rsp_buf,
                      &rsp_len, comm_access::qmf_protocol::QmfChecker);
  ASSERT_EQ(ret, 0);
  ASSERT_EQ(helper.Decode(rsp_buf, rsp_len), 0);
  comm_access::qmf_protocol::VideoResponseProtocol frame_rsp;
  ret = frame_rsp.Decode(reinterpret_cast<const char*>(helper.qmf_head().Body),
                         helper.qmf_head().BodyLen);
  ASSERT_EQ(ret, 0);
  ASSERT_EQ(frame_rsp.DecodeBody(&rsp), 0);

  CheckRsp(rsp, item);
}

TEST(EnvTest, Test) {
  // 正式环境不支持多环境路由
  if (INS_DOCKER_ENV->docker_env() == "formal") {
    return;
  }
  std::vector<TestCase> cases{
      // {"polaris_l5_online_test", "", "formal", "*", "*"},
      // {"polaris_l5_test_test", "", "test", "*", "*"},
      // {"polaris_set_test", "", "formal", "set1.sh.1", "*"},
      {"polaris_test", "", ::spp_rpc::GetContainerEnv(), "*", "*"},
      {"polaris_test", "764138e4,test", "764138e4", "*", "*"}};
  for (auto item : cases) {
    PbTest(item);
    QmfPolarisTest(item);
  }
}
