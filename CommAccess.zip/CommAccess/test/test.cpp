
/*
 *
 * Copyright 2019 Tencent authors.
 *
 * test
 *
 */

#include <arpa/inet.h>
#include <gtest/gtest.h>
#include <netinet/in.h>
#include <qmf_head_parser.h>
#include <stdio.h>

#include <iostream>

#include "proto/complex_object.pb.h"
#include "proto/hello_trpc.pb.h"
#include "proto/hi_pb.spp_rpc.pb.h"
#include "spp_rpc/client/binary_proxy.h"
#include "spp_rpc/client/http_proxy.h"
#include "spp_rpc/codec/trpc/trpc_protocol.h"
#include "spp_rpc/spp_rpc.h"
#include "spp_rpc_test/func_factory.h"
#include "spp_rpc_test/option.h"
#include "src/codec/qmf_protocol.h"
#include "src/comm/config.h"
#include "src/comm/tools.h"
#include "src/interface/common_cache.spp_rpc.pb.h"

// -------------------------------------------------------------
// 如果想获取测试程序的输入参数，可以使用TEST_OPTION宏，
// 1. TEST_OPTION定义在spp_rpc_test/option.h；
// 2. TEST_OPTION封装了util/option.h中的tars::TC_Option对象。
//
// 下面给出获取输入参数方法：
//
// 1. 获取输入参数： --hello=param
// std::string param = TEST_OPTION->getValue("hello");
//
// 2. 判断是否有输入参数：hello
// bool hasParam = TEST_OPTION->hasParam("hello");
//
// 3. 获取所有的普通参数
// std::vector<std::string>& single = TEST_OPTION->getSingle();
//
// 4. 获取所有的标识参数
// std::map<std::string, std::string>& m = TEST_OPTION->getMulti();
// -------------------------------------------------------------
#define ADD_LOGIN_TOKEN(frame_req, type, account, is_main_login) \
  do {                                                           \
    auto token = frame_req.logic_header.add_login_token();       \
    token->set_type(type);                                       \
    token->set_account(account);                                 \
    token->set_is_main_login(is_main_login);                     \
  } while (0)

class QmfSecurityTest : public testing::Test {
 protected:
  virtual void SetUp() {
    spp_rpc::ConfigManager* conf = spp_rpc::ConfigManagerSingleton::getInstance();
    int ret = conf->Init("../conf/CommAccess.xml");
    ASSERT_EQ(0, ret);

    // config信息
    INS_CONFIG->Init();
    INS_CONFIG->UpdateWujiConfig(comm_access::QMF_TYPE);
    INS_CONFIG->PrintConfig();
    helper_.Init();
    helper_.mutable_qmf_head()->Flag = 0x20213;
    helper_.mutable_qmf_acc_head()->ClientIP = 238313840;  // 112.97.52.14
    helper_.mutable_qmf_head()->ResvLen = 16;
    helper_.mutable_qmf_head()->Resv[2] = 16;
    *((uint128_t*)&(helper_.mutable_qmf_head()->Resv[3])) = 69877198038765092;  // NOLINT
  }

  virtual void TearDown() {}
  template <typename RequestType, typename ResponseType>
  int DoRequst(const RequestType& req, ResponseType* rsp) {
    spp_rpc::BinaryRpcProxyPtr ptr =
        spp_rpc::GetServantProxy<spp_rpc::BinaryRpcProxyPtr>("qmf_test");
    frame_req_.EncodeBody(req);
    std::vector<char> req_buf;
    frame_req_.Encode(&req_buf);
    helper_.Encode(req_buf.data(), req_buf.size());
    char* rsp_buf = nullptr;
    size_t rsp_len = 0;
    RPC_LOG_RET(ptr->Exec(helper_.rsp_buf(), helper_.rsp_buff_len(), &rsp_buf, &rsp_len,
                          comm_access::qmf_protocol::QmfChecker),
                "exec err");
    RPC_LOG_RET(helper_.Decode(rsp_buf, rsp_len), "qmf decode err");
    RPC_LOG_RET(frame_rsp_.Decode(reinterpret_cast<const char*>(helper_.qmf_head().Body),
                                  helper_.qmf_head().BodyLen),
                "trpc decode err");
    if (helper_.qmf_head().RetCode) {
      return 0;
    }
    RPC_LOG_RET(frame_rsp_.DecodeBody(rsp), "logic decode err");
    return 0;
  }
  std::shared_ptr<comm_access::WuJiConfig> config = nullptr;
  comm_access::qmf_protocol::VideoRequestProtocol frame_req_;
  comm_access::qmf_protocol::VideoResponseProtocol frame_rsp_;
  comm_access::qmf_protocol::QmfHelper helper_;
};

int CallSetComplexObj(const com::tencent::spp_rpc::ComplexObjectRequest& req,
                      spp_rpc::BinaryRpcProxyPtr prx,
                      com::tencent::spp_rpc::ComplexObjectResponse* rsp) {
  if (!prx || !rsp) {
    return -1;
  }
  comm_access::qmf_protocol::VideoRequestProtocol frame_req;
  comm_access::qmf_protocol::VideoResponseProtocol frame_rsp;
  comm_access::qmf_protocol::QmfHelper helper;
  helper.Init();
  // 设置请求信息
  frame_req.logic_header.mutable_version_info()->set_app_id("1000005");
  frame_req.logic_header.set_callee("com.tencent.spp_rpc.CommCacheTest");
  frame_req.logic_header.set_func("/com.tencent.spp_rpc.CommCacheTest/SetComplexObj");
  // 编码
  std::vector<char> req_buf;
  req_buf.clear();
  char* rsp_buf = nullptr;
  size_t rsp_len = 0;
  RPC_LOG_RET(frame_req.EncodeBody(req), "logic encode err");
  RPC_LOG_RET(frame_req.Encode(&req_buf), "trpc encode err");
  RPC_LOG_RET(helper.Encode(req_buf.data(), req_buf.size()), "qmf encode err");
  // 调用
  RPC_LOG_RET(prx->Exec(helper.rsp_buf(), helper.rsp_buff_len(), &rsp_buf, &rsp_len,
                        comm_access::qmf_protocol::QmfChecker),
              "exec err");
  // 解码
  RPC_LOG_RET(helper.Decode(rsp_buf, rsp_len), "qmf decode err");
  RPC_LOG_RET(frame_rsp.Decode(reinterpret_cast<const char*>(helper.qmf_head().Body),
                               helper.qmf_head().BodyLen),
              "trpc decode err");
  RPC_LOG_RET(frame_rsp.DecodeBody(rsp), "logic decode err");
  return 0;
}

// zkroute
int QmfTest() {
  comm_access::qmf_protocol::QmfHelper helper;
  helper.Init();
  helper.mutable_qmf_head()->Flag = 0x20213;
  // 112.97.52.14
  helper.mutable_qmf_acc_head()->ClientIP = 238313840;

  spp_rpc::ConfigManager* conf = spp_rpc::ConfigManagerSingleton::getInstance();
  RPC_LOG_RET(conf->Init("../conf/CommAccess.xml"), "config init err");

  INS_CONFIG->Init();
  INS_CONFIG->PrintConfig();
  auto area_code = INS_TOOLS->GetAreaCode(helper.qmf_acc_head().ClientIP, helper.qmf_head());

  RPC_TLOG("ipv4 areacode=%s, ipv4=%ld", area_code.c_str(),
           helper.mutable_qmf_acc_head()->ClientIP);

  helper.mutable_qmf_head()->ResvLen = 16;
  helper.mutable_qmf_head()->Resv[2] = 16;

  // GetAreaCode 函数下面获取:ipv6
  //  ipv6 = *(uint128_t*)(&qmf_head.Resv[3]);
  *((uint128_t*)&(helper.mutable_qmf_head()->Resv[3])) = 69877198038765092;  // NOLINT

  area_code = INS_TOOLS->GetAreaCode(helper.qmf_acc_head().ClientIP, helper.qmf_head());
  RPC_TLOG("ipv6 areacode=%s", area_code.c_str());

  comm_access::qmf_protocol::VideoRequestProtocol frame_req;
  frame_req.logic_header.set_callee("com.tencent.spp_rpc.RpcHello");
  frame_req.logic_header.set_func("/com.tencent.spp_rpc.RpcHello/Sum");

  frame_req.logic_header.mutable_version_info()->set_app_id("1000005");
  frame_req.logic_header.mutable_bucket_info()->set_bucket_id(4);
  frame_req.logic_header.mutable_device_info()->set_guid("pb_test_guid_11");

  frame_req.logic_header.mutable_user_status_info()->set_session_code(
      "D07B1890330EB7FFE93F7EE0A71F673A9779FE4E78CDE718FD0791BA38F29142E97C4B34969B75060A6BC628DC28"
      "EBD156C63F59F57B66E91A1AC16D");  // NOLINT
  // auto trans = frame_req.logic_header.mutable_trans_info();
  // (*trans)["teenGuardSessionCode"] =
  // "E3BBC92BD85AF2812AF53FE3653B2105F73EF7AE2A43B797496A836CC121F2FD054DAD46554F11D3A18F2228592013389B6E475E7BB198A737F08692D1769F122CC85A93E6262CBADBD18780685068B7293A0D2391FC5517BF5875453C03EEBD8BB1BF87CD0B5499588827B2";

  auto key = GetWujiConfigKey(comm_access::QMF_TYPE, frame_req.logic_header.version_info().app_id(),
                              frame_req.logic_header.callee(), frame_req.logic_header.func());
  INS_CONFIG->UpdateWujiConfig(comm_access::QMF_TYPE);
  std::shared_ptr<comm_access::WuJiConfig> config =
      INS_CONFIG->GetWujiConfig(key, comm_access::QMF_TYPE);
  EXPECT_NE(config->mod_id, 0);
  EXPECT_NE(config->cmd_id, 0);

  // qq
  auto token = frame_req.logic_header.add_login_token();
  token->set_type(1);
  token->set_account("12345678");

  // vuid
  token = frame_req.logic_header.add_login_token();
  token->set_type(9);
  token->set_account("87654321");

  // qq openid
  token = frame_req.logic_header.add_login_token();
  token->set_type(10);
  token->set_account("90D8FFD43E9DEFDXXXXXXC7B7B797371");

  // wechat openid
  token = frame_req.logic_header.add_login_token();
  token->set_type(100);
  token->set_account("90D8FFD43E9DEFDYYYYYYC7B7B797371");

  com::tencent::spp_rpc::SumRequest sum_req;
  sum_req.set_lhs(1);
  sum_req.set_rhs(2);
  frame_req.EncodeBody(sum_req);

  std::vector<char> req_buf;
  frame_req.Encode(&req_buf);

  helper.Encode(req_buf.data(), req_buf.size());

  char* rsp_buf = nullptr;
  size_t rsp_len = 0;
  auto ptr = spp_rpc::GetServantProxy<spp_rpc::BinaryRpcProxyPtr>("qmf_test");
  RPC_LOG_RET(ptr->Exec(helper.rsp_buf(), helper.rsp_buff_len(), &rsp_buf, &rsp_len,
                        comm_access::qmf_protocol::QmfChecker),
              "exec err");

  RPC_LOG_RET(helper.Decode(rsp_buf, rsp_len), "qmf decode err");
  comm_access::qmf_protocol::VideoResponseProtocol frame_rsp;
  RPC_LOG_RET(frame_rsp.Decode(reinterpret_cast<const char*>(helper.qmf_head().Body),
                               helper.qmf_head().BodyLen),
              "trpc decode err");

  com::tencent::spp_rpc::SumResponse sum_rsp;
  RPC_LOG_RET(frame_rsp.DecodeBody(&sum_rsp), "logic decode err");
  RPC_TLOG("%d + %d = %d", sum_req.lhs(), sum_req.rhs(), sum_rsp.value());
  if (sum_req.lhs() + sum_req.rhs() != sum_rsp.value()) return -1;
  return 0;
}

int TrpcTest() {
  std::vector<char> req_buf;
  spp_rpc::TrpcRequestProtocol req;
  (*req.logic_header.mutable_trans_info())["yo_key"] = "yo_value";
  com::tencent::spp_rpc::SumRequest sum_req;
  sum_req.set_lhs(1);
  sum_req.set_rhs(2);
  req.EncodeBody(sum_req);
  (*req.logic_header.mutable_trans_info())["yo_body"].assign(req.body.begin(), req.body.end());
  req.Encode(&req_buf);
  std::string str(req_buf.begin(), req_buf.end());

  auto ptr = spp_rpc::GetServantProxy<spp_rpc::HttpRpcProxyPtr>();
  std::string host = "conn.video.qq.com";
  auto env = getenv("DOCKER_ENV");
  if (env) {
    std::string docker_env = env;
    if (docker_env == "test") {
      host = "test" + host;
      // sparta 接入层内网ip，外网ip在idc网络访问不了
      ptr->mutable_route_point()->SetIp("100.115.145.38", 80);
    } else if (docker_env == "pre") {
      host = "pre" + host;
      ptr->mutable_route_point()->SetIp("100.115.145.38", 80);
    } else {
      ptr->mutable_route_point()->SetIp("100.95.8.20", 80);
    }
  }
  std::string url =
      std::string("http://") + host + std::string("/com.tencent.spp_rpc.RpcHello/Sum");

  tars::TC_HttpRequest http_req;
  tars::TC_HttpResponse* http_rsp = nullptr;
  http_req.setPostRequest(url, str);

  RPC_LOG_RET(ptr->AccessHttp(http_req, &http_rsp), "access http err");
  RPC_TLOG("http status:%d", http_rsp->getStatus());

  spp_rpc::TrpcResponseProtocol rsp;
  const auto& content = http_rsp->getContent();
  RPC_LOG_RET(rsp.Decode(content.c_str(), content.size()), "decode rsp err");

  com::tencent::spp_rpc::SumResponse sum_rsp;
  RPC_LOG_RET(rsp.DecodeBody(&sum_rsp), "decode body err");

  RPC_TLOG("%d + %d = %d", sum_req.lhs(), sum_req.rhs(), sum_rsp.value());
  if (sum_req.lhs() + sum_req.rhs() != sum_rsp.value()) return -1;

  return 0;
}

// 不走sparta，直接请求本地服务
int TrpcLocalTest() {
  spp_rpc::TrpcMsg msg;
  auto head = msg.GetVideoMutableReqHead();
  head->mutable_bucket_info()->set_bucket_id(4);

  msg.mutable_req()->logic_header.set_callee("com.tencent.spp_rpc.RpcHello");
  msg.mutable_req()->logic_header.set_func("/com.tencent.spp_rpc.RpcHello/Sum");

  (*(msg.mutable_req()->logic_header.mutable_trans_info()))["trpc_http_path"] =  // NOLINT
      "/com.tencent.spp_rpc.RpcHello/Sum";
  // qq
  auto token = head->add_login_token();
  token->set_type(1);
  token->set_account("12345678");

  // vuid
  token = head->add_login_token();
  token->set_type(9);
  token->set_account("87654321");

  // qq openid
  token = head->add_login_token();
  token->set_type(10);
  token->set_account("90D8FFD43E9DEFDXXXXXXC7B7B797371");

  // wechat openid
  token = head->add_login_token();
  token->set_type(100);
  token->set_account("90D8FFD43E9DEFDYYYYYYC7B7B797371");

  // 更新包头
  msg.UpdateHead();

  com::tencent::spp_rpc::SumRequest sum_req;
  sum_req.set_lhs(1);
  sum_req.set_rhs(2);
  com::tencent::spp_rpc::SumResponse sum_rsp;
  auto ptr = spp_rpc::GetServantProxy<com::tencent::spp_rpc::RpcHelloProxyPtr>(
      "com.tencent.spp_rpc.RpcHello");
  auto status = ptr->Sum(sum_req, &sum_rsp, msg.context());
  if (!status.Ok()) {
    RPC_LOG_RET(-1, "status:%d,%d,%s", status.logic_error_code(), status.frame_error_code(),
                status.error_message().c_str());
  }
  return 0;
}

int HttpTest() {
  spp_rpc::HttpRpcProxyPtr greeter =
      spp_rpc::GetServantProxy<spp_rpc::HttpRpcProxyPtr>("http_test");

  tars::TC_HttpRequest http_req;
  tars::TC_HttpResponse* http_rsp = NULL;
  http_req.setHost("vip.video.qq.com");
  http_req.setGetRequest(
      "http://vip.video.qq.com/fcgi-bin/"
      "comm_cgi_js?name=bindphone_task&vappid=34382579&vsecret="
      "e496b057758aeb04b3a2d623c952a1c47e04ffb0a01e19cf",
      true);

  int ret = greeter->AccessHttp(http_req, &http_rsp);
  // 首先要判断当前次请求是否有效
  if (greeter->GetResult() != 200 && greeter->GetResult() != 0) {
    std::cout << "invalid function call, result: " << greeter->GetResult() << std::endl;
    return -1;
  }
  return ret;
}

// 北极星路由test
int Trpc123MsgTest() {
  spp_rpc::HttpRpcProxyPtr greeter =
      spp_rpc::GetServantProxy<spp_rpc::HttpRpcProxyPtr>("trpc123_test");

  tars::TC_HttpRequest http_req;
  tars::TC_HttpResponse* http_rsp = NULL;
  http_req.setHost("vip.video.qq.com");
  // http_req.setGetRequest(, true);
  http_req.setHeader("trpc-callee", "trpc.dandyhuang.dandyhuang.GreeterHttp");
  http_req.setHeader("trpc-func", "/trpc.dandyhuang.dandyhuang.Greeter/SayHello");
  // http_req.setHeader("Content-Type", "application/octet-stream");
  http_req.setHeader("Content-Type", "application/protobuf");
  http_req.setHeader("Referer", "http://video.qq.com");

  std::string cookie =
      "video_platform=2; video_guid=99f6565a96421d80; pgv_pvid=9133944646;"
      " pac_uid=0_5eba7b8686e88; pgv_pvi=3896183808; mobileUV=1_17293d0ec27_76904;"
      " RK=aM4BwrKHZI; ptcz=704bc593991c0f8aa441368779cef1ce9ddcaa85f0484b0099b315fc646b9a00;"
      " main_login=qq; vqq_access_token=BA6BB153206C53999F56775582405D3C; vqq_appid=101483052;"
      " vqq_openid=EF58243272F0B65C42CC39E180B057FB; vqq_vuserid=301609889;"
      " vqq_refresh_token=DD1D277F3FBC6D5D5152ADA01019E909; uid=680530912; "
      "pgv_info=ssid=s5037830070;"
      " vqq_vusession=rR_34bxCAoonB7WhP75F9Q..;";
  http_req.setCookie(cookie);

  trpc::dandyhuang::dandyhuang::HelloRequest req;
  req.set_msg("dandyhuang test");
  std::vector<char> buf;
  buf.resize(req.ByteSizeLong());
  req.SerializeToArray(buf.data(), req.ByteSizeLong());
  string body;
  body.insert(body.begin(), buf.begin(), buf.end());
  std::string url =
      "http://9.146.153.3:10025/trpc.dandyhuang.dandyhuang.Greeter/SayHello?"
      "g_vstk=283616281&g_actk=1458743151";
  http_req.setPostRequest(url, body, true);

  trpc::dandyhuang::dandyhuang::HelloReply rsp;

  greeter->AccessHttp(http_req, &http_rsp);

  // 首先要判断当前次请求是否有效
  if (greeter->GetResult()) {
    std::cout << "invalid function call, result: " << greeter->GetResult() << std::endl;
    return 0;
  }
  return 0;
}

// l5路由test
int QmfCommCacheTest() {
  comm_access::qmf_protocol::QmfHelper helper;
  helper.Init();
  helper.mutable_qmf_head()->Flag = 0x20213;
  // 112.97.52.14
  helper.mutable_qmf_acc_head()->ClientIP = 238313840;
  helper.mutable_qmf_head()->ResvLen = 16;
  helper.mutable_qmf_head()->Resv[2] = 16;
  *((uint128_t*)&(helper.mutable_qmf_head()->Resv[3])) = 69877198038765092;  // NOLINT
  comm_access::qmf_protocol::VideoRequestProtocol frame_req;
  frame_req.logic_header.set_callee("com.tencent.spp_rpc.CommCacheTest");
  frame_req.logic_header.set_func("/com.tencent.spp_rpc.CommCacheTest/SetComplexObj");
  frame_req.logic_header.mutable_version_info()->set_app_id("1000005");
  frame_req.logic_header.mutable_bucket_info()->set_bucket_id(4);
  frame_req.logic_header.mutable_device_info()->set_guid("pb_test_guid_11");
  frame_req.logic_header.mutable_user_status_info()->set_session_code(
      "D07B1890330EB7FFE93F7EE0A71F673A9779FE4E78CDE718FD0791BA38F29142E97C4B34969B75060A6BC628DC28"
      "EBD156C63F59F57B66E91A1AC16D");  // NOLINT
  // qq
  auto token = frame_req.logic_header.add_login_token();
  token->set_type(1);
  token->set_account("12345678");
  // vuid
  token = frame_req.logic_header.add_login_token();
  token->set_type(9);
  token->set_account("87654321");
  // qq openid
  token = frame_req.logic_header.add_login_token();
  token->set_type(10);
  token->set_account("90D8FFD43E9DEFDXXXXXXC7B7B797371");
  // wechat openid
  token = frame_req.logic_header.add_login_token();
  token->set_type(100);
  token->set_account("90D8FFD43E9DEFDYYYYYYC7B7B797371");

  // 先发一个请求 cache wuji已经配置规则hotkey_time_ms=1ms expired_time_s=1s
  com::tencent::spp_rpc::ComplexObjectRequest obj;
  obj.set_email("fromsource");
  frame_req.EncodeBody(obj);
  std::vector<char> req_buf;
  frame_req.Encode(&req_buf);
  helper.Encode(req_buf.data(), req_buf.size());
  char* rsp_buf = nullptr;
  size_t rsp_len = 0;
  auto ptr = spp_rpc::GetServantProxy<spp_rpc::BinaryRpcProxyPtr>("comm_cache_proxy_test");
  RPC_LOG_RET(ptr->Exec(helper.rsp_buf(), helper.rsp_buff_len(), &rsp_buf, &rsp_len,
                        comm_access::qmf_protocol::QmfChecker),
              "exec err");

  RPC_LOG_RET(helper.Decode(rsp_buf, rsp_len), "qmf decode err");
  comm_access::qmf_protocol::VideoResponseProtocol frame_rsp;
  RPC_LOG_RET(frame_rsp.Decode(reinterpret_cast<const char*>(helper.qmf_head().Body),
                               helper.qmf_head().BodyLen),
              "trpc decode err");

  com::tencent::spp_rpc::ComplexObjectResponse obj_rsp;
  RPC_LOG_RET(frame_rsp.DecodeBody(&obj_rsp), "logic decode err");
  RPC_TLOG("obj_rsp.value:%d", obj_rsp.value());
  if (obj_rsp.value() != 3) {
    return -2;
  }
  return 0;
}

int Http2TrpcTest() {
  spp_rpc::HttpRpcProxyPtr greeter =
      spp_rpc::GetServantProxy<spp_rpc::HttpRpcProxyPtr>("http2trpc_test");

  tars::TC_HttpRequest http_req;
  tars::TC_HttpResponse* http_rsp = NULL;
  http_req.setHost("vip.video.qq.com");
  http_req.setGetRequest("http://vip.video.qq.com/fcgi-bin/comm_cgi_js?name=bindphone_task", true);

  int ret = greeter->AccessHttp(http_req, &http_rsp);
  // 首先要判断当前次请求是否有效
  if (greeter->GetResult()) {
    std::cout << "invalid function call, result: " << greeter->GetResult() << std::endl;
    return -1;
  }
  return ret;
}

// 特区用户测试+黑洞路由
int HoleSpecialUserTest() {
  comm_access::qmf_protocol::QmfHelper helper;
  helper.Init();
  helper.mutable_qmf_head()->Flag = 0x20213;
  comm_access::qmf_protocol::VideoRequestProtocol frame_req;
  frame_req.logic_header.set_callee("com.tencent.qqlive.protocol.pb.EmptyService");
  frame_req.logic_header.set_func("/com.tencent.qqlive.protocol.pb.EmptyService/getPage");

  frame_req.logic_header.mutable_version_info()->set_app_id("1000005");
  frame_req.logic_header.mutable_bucket_info()->set_bucket_id(4);
  frame_req.logic_header.mutable_device_info()->set_guid("pb_test_guid_11");

  auto key = GetWujiConfigKey(comm_access::QMF_TYPE, frame_req.logic_header.version_info().app_id(),
                              frame_req.logic_header.callee(), frame_req.logic_header.func());
  INS_CONFIG->UpdateWujiConfig(comm_access::QMF_TYPE);
  std::shared_ptr<comm_access::WuJiConfig> config =
      INS_CONFIG->GetWujiConfig(key, comm_access::QMF_TYPE);

  // qq
  auto token = frame_req.logic_header.add_login_token();
  token->set_type(1);
  token->set_account("192885973");

  // vuid
  token = frame_req.logic_header.add_login_token();
  token->set_type(9);
  token->set_account("192885973");  //  特区用户

  com::tencent::spp_rpc::SumRequest sum_req;
  sum_req.set_lhs(1);
  sum_req.set_rhs(2);
  frame_req.EncodeBody(sum_req);

  std::vector<char> req_buf;
  frame_req.Encode(&req_buf);

  helper.Encode(req_buf.data(), req_buf.size());

  char* rsp_buf = nullptr;
  size_t rsp_len = 0;
  auto ptr = spp_rpc::GetServantProxy<spp_rpc::BinaryRpcProxyPtr>("special_user_test");
  RPC_LOG_RET(ptr->Exec(helper.rsp_buf(), helper.rsp_buff_len(), &rsp_buf, &rsp_len,
                        comm_access::qmf_protocol::QmfChecker),
              "exec err");

  RPC_LOG_RET(helper.Decode(rsp_buf, rsp_len), "qmf decode err");
  comm_access::qmf_protocol::VideoResponseProtocol frame_rsp;
  RPC_LOG_RET(frame_rsp.Decode(reinterpret_cast<const char*>(helper.qmf_head().Body),
                               helper.qmf_head().BodyLen),
              "trpc decode err");
  int special_user = frame_rsp.logic_header.user_status_info().special_user();
  EXPECT_EQ(special_user, 1);
  return 0;
}

int QmfAntiWhiteScreenPluginTest() {
  // 先向接入层发起一个请求，接入层转发到真正被调业务，业务返回成功，触发防白屏插件更新数据
  com::tencent::spp_rpc::ComplexObjectRequest obj;
  obj.set_email("coldcache");
  com::tencent::spp_rpc::ComplexObjectResponse obj_rsp;
  auto prx = spp_rpc::GetServantProxy<spp_rpc::BinaryRpcProxyPtr>("comm_cache_proxy_test");
  RPC_LOG_RET(CallSetComplexObj(obj, prx, &obj_rsp), "CallSetComplexObj call1 failed");
  if (obj_rsp.value() != 3) {
    return -1;
  }
  // 再向接入层发起一个请求，该特定请求使业务返回失败，触发防白屏插件读兜底数据
  obj.set_name("return -1");
  RPC_LOG_RET(CallSetComplexObj(obj, prx, &obj_rsp), "CallSetComplexObj call2 failed");
  if (obj_rsp.value() != 3) {
    return -1;
  }
  return 0;
}

// qmf重试 接口测试
int QmfRetryTest() {
  // TODO(leomryang):写接口测试逻辑
  return 0;
}

// @suite_name: QmfSecurityTest
// @case_name: Case1_Qmf_Security_Test_P0
// @priority: P0
// @author: oliverlli
// @interface_name: your_interface_name
TEST_F(QmfSecurityTest, Case1_Qmf_Security_Test_P0) {
  /*
      callee : com.tencent.spp_rpc.RpcHello
      func : /com.tencent.spp_rpc.RpcHello/Sum
      safe_type : 3
      对应: bussnissId 不存在, 返回15030 需要验证
  */
  std::string appid = "1000005";
  std::string callee = "com.tencent.spp_rpc.RpcHello";
  std::string func = "/com.tencent.spp_rpc.RpcHello/SumSecurity";
  int bucket_id = 4;

  // 安全
  int safe_type = 3;
  std::string safe_key = "safe_type_test_01";

  // 登录态
  ADD_LOGIN_TOKEN(frame_req_, 1, "12345678", true);
  ADD_LOGIN_TOKEN(frame_req_, 9, "87654321", false);
  ADD_LOGIN_TOKEN(frame_req_, 10, "90D8FFD43E9DEFDXXXXXXC7B7B797371", false);
  ADD_LOGIN_TOKEN(frame_req_, 100, "90D8FFD43E9DEFDYYYYYYC7B7B797371", false);

  frame_req_.logic_header.mutable_version_info()->set_app_id(appid);
  frame_req_.logic_header.set_callee(callee);
  frame_req_.logic_header.set_func(func);
  frame_req_.logic_header.mutable_bucket_info()->set_bucket_id(bucket_id);
  frame_req_.logic_header.mutable_safe_info()->set_type(safe_type);
  frame_req_.logic_header.mutable_safe_info()->set_safe_key(safe_key);

  auto key = GetWujiConfigKey(comm_access::QMF_TYPE, appid, callee, func);

  config = INS_CONFIG->GetWujiConfig(key, comm_access::QMF_TYPE);
  ASSERT_NE(config->mod_id, 0);
  ASSERT_NE(config->cmd_id, 0);

  // 请求 与 回包
  com::tencent::spp_rpc::SumRequest req;
  com::tencent::spp_rpc::SumResponse rsp;
  req.set_lhs(1);
  req.set_rhs(2);

  int ret = this->DoRequst(req, &rsp);
  ASSERT_EQ(ret, 0);

  if (frame_rsp_.logic_header.err_code()) {
    EXPECT_LE(15026, frame_rsp_.logic_header.err_code());
    EXPECT_GE(15032, frame_rsp_.logic_header.err_code());
  } else if (helper_.qmf_head().RetCode == 0) {
    EXPECT_EQ(3, rsp.value());
  }
  EXPECT_EQ(15030, frame_rsp_.logic_header.err_code());
  EXPECT_NE("", frame_rsp_.logic_header.safe_info().safe_result());
}

/*
TEST_F(QmfSecurityTest, Case2_Qmf_Security_Test_P0) {
    // callee : com.tencent.spp_rpc.RpcHello
    // func : /com.tencent.spp_rpc.RpcHello/Sum
    // safe_type : 2
    // 对应: bussnissId 不存在, 返回15031 验证失败
    std::string appid = "1000005";
    std::string callee = "com.tencent.spp_rpc.RpcHello";
    std::string func = "/com.tencent.spp_rpc.RpcHello/SumSecurity";
    int bucket_id = 4;

    // 安全
    int safe_type = 2;
    std::string safe_key = "safe_type_test_01";

    // 登录态
    ADD_LOGIN_TOKEN(frame_req_, 1, "12345678", true);
    ADD_LOGIN_TOKEN(frame_req_, 9, "87654321", false);
    ADD_LOGIN_TOKEN(frame_req_, 10, "90D8FFD43E9DEFDXXXXXXC7B7B797371", false);
    ADD_LOGIN_TOKEN(frame_req_, 100, "90D8FFD43E9DEFDYYYYYYC7B7B797371", false);

    frame_req_.logic_header.mutable_version_info()->set_app_id(appid);
    frame_req_.logic_header.set_callee(callee);
    frame_req_.logic_header.set_func(func);
    frame_req_.logic_header.mutable_bucket_info()->set_bucket_id(bucket_id);
    frame_req_.logic_header.mutable_safe_info()->set_type(safe_type);
    frame_req_.logic_header.mutable_safe_info()->set_safe_key(safe_key);

    string key =  appid + callee + func;
    INS_CONFIG->GetWujiConfig(key, &config, comm_access::QMF_TYPE);
    ASSERT_NE(config->mod_id, 0);
    ASSERT_NE(config->cmd_id, 0);

    // 请求 与 回包
    com::tencent::spp_rpc::SumRequest req;
    com::tencent::spp_rpc::SumResponse rsp;
    req.set_lhs(1);
    req.set_rhs(2);

    int ret = this->DoRequst(req, &rsp);
    ASSERT_EQ(ret, 0);

    if (frame_rsp_.logic_header.err_code()) {
        EXPECT_LE(15026, frame_rsp_.logic_header.err_code());
        EXPECT_GE(15032, frame_rsp_.logic_header.err_code());
    } else {
        EXPECT_EQ(3, rsp.value());
    }
    EXPECT_EQ(15031, frame_rsp_.logic_header.err_code());
    EXPECT_NE("", frame_rsp_.logic_header.safe_info().safe_result());
}
*/

TEST(CommAccessCase, Case2_QmfTest_P0) { EXPECT_EQ(QmfTest(), 0); }

TEST(CommAccessCase, Case3_TrpcTest_P0) {
  // EXPECT_EQ(TrpcTest(), 0);
}
TEST(CommAccessCase, Case4_TrpcLocalTest_P0) { EXPECT_EQ(TrpcLocalTest(), 0); }

TEST(CommAccessCase, Case5_HttpTest_P0) { EXPECT_EQ(HttpTest(), 0); }

TEST(CommAccessCase, Case6_Http2TrpcTest_P0) { EXPECT_EQ(Http2TrpcTest(), 0); }

TEST(CommAccessCase, Case7_Trpc123MsgTest_P0) { EXPECT_EQ(Trpc123MsgTest(), 0); }
/**
 * @case_name CommAccessCase.Case5_QmfCommCacheTest_P0
 * @priority P0
 * @brief 测qmf协议转发到CommCacheTest服务用于压力测试
 */
TEST(CommAccessCase, Case8_QmfCommCacheTest_P0) { EXPECT_EQ(QmfCommCacheTest(), 0); }

TEST(CommAccessCase, Case9_HoleSpecialUserTest_P0) { EXPECT_EQ(HoleSpecialUserTest(), 0); }
extern int HttpMsgTest();

/**
 * @case_name CommAccessCase.Case10_QmfAntiWhiteScreenPluginTest_P0
 * @priority P0
 * @brief 测防白屏插件支持旁路缓存
 */
TEST(CommAccessCase, Case10_QmfAntiWhiteScreenPluginTest_P0) {
  EXPECT_EQ(QmfAntiWhiteScreenPluginTest(), 0);
}

// 测试重试逻辑
TEST(CommAccessCase, Case11_QmfRetryTest_P0) {
  EXPECT_EQ(QmfRetryTest(), 0);
}

// 必须定义这个函数，该函数用于注册所有需要测试的函数
void AddFunction() {
  ADD_FUNCTION(QmfTest);
  ADD_FUNCTION(TrpcTest);
  ADD_FUNCTION(TrpcLocalTest);
  ADD_FUNCTION(HttpTest);
  ADD_FUNCTION(Http2TrpcTest);
  ADD_FUNCTION(Trpc123MsgTest);
  ADD_FUNCTION(QmfCommCacheTest);
  ADD_FUNCTION(HttpMsgTest);
  ADD_FUNCTION(QmfAntiWhiteScreenPluginTest);
  ADD_FUNCTION(QmfRetryTest);
}
