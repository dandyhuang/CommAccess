
/*
 *
 * Copyright 2020 Tencent authors.
 *
 * http_test
 *
 */

#include <arpa/inet.h>
#include <gtest/gtest.h>
#include <netinet/in.h>
#include <qmf_head_parser.h>
#include <stdio.h>

#include <iostream>

#include "proto/complex_object.pb.h"
#include "proto/hello_trpc.pb.h"
#include "proto/hi_pb.spp_rpc.pb.h"
#include "spp_rpc/client/binary_proxy.h"
#include "spp_rpc/client/http_proxy.h"
#include "spp_rpc/codec/trpc/trpc_protocol.h"
#include "spp_rpc/spp_rpc.h"
#include "spp_rpc_test/func_factory.h"
#include "spp_rpc_test/option.h"
#include "src/codec/qmf_protocol.h"
#include "src/comm/config.h"
#include "testcase_hello2/hello2.pb.h"

int HttpMsgTest() {
  spp_rpc::HttpRpcProxyPtr greeter =
      spp_rpc::GetServantProxy<spp_rpc::HttpRpcProxyPtr>("trpc123_test");

  tars::TC_HttpRequest http2trp_req;
  tars::TC_HttpResponse* http2trpc_rsp = NULL;
  http2trp_req.setHost("vip.video.qq.com");
  // http2trp_req.setGetRequest(, true);
  http2trp_req.setHeader("trpc-callee", "trpc.dandyhuang.dandyhuang.GreeterHttp");
  http2trp_req.setHeader("trpc-func", "/trpc.dandyhuang.dandyhuang.Greeter/SayHello");
  // http2trp_req.setHeader("Content-Type", "application/octet-stream");
  http2trp_req.setHeader("Content-Type", "application/protobuf");
  http2trp_req.setHeader("Referer", "http://video.qq.com");

  trpc::dandyhuang::dandyhuang::HelloRequest req1;
  req1.set_msg("dandyhuang test");
  std::vector<char> buf;
  buf.resize(req1.ByteSizeLong());
  req1.SerializeToArray(buf.data(), req1.ByteSizeLong());
  string body;
  body.insert(body.begin(), buf.begin(), buf.end());
  std::string url =
      "http://9.146.153.3:10025/trpc.dandyhuang.dandyhuang.Greeter/SayHello?"
      "g_vstk=283616281&g_actk=1458743151";
  http2trp_req.setPostRequest(url, body, true);

  trpc::dandyhuang::dandyhuang::HelloReply rsp;

  greeter->AccessHttp(http2trp_req, &http2trpc_rsp);

  // 校验cors问题
  EXPECT_EQ(http2trpc_rsp->getHeader("Access-Control-Allow-Credentials"), "true");
  EXPECT_EQ(http2trpc_rsp->getHeader("Access-Control-Allow-Headers"), "Content-Type,Access-Token");
  EXPECT_EQ(http2trpc_rsp->getHeader("Content-Type"), "application/json; charset=utf-8");

  // 首先要判断当前次请求是否有效
  if (greeter->GetResult()) {
    std::cout << "invalid function call, result: " << greeter->GetResult() << std::endl;
    return 0;
  }
  return 0;
}

int HttpTrpcMsgTest() {
  spp_rpc::HttpRpcProxyPtr greeter =
      spp_rpc::GetServantProxy<spp_rpc::HttpRpcProxyPtr>("http_trpc_test");

  tars::TC_HttpRequest http2trpc_req;
  tars::TC_HttpResponse* http2trpc_rsp = NULL;
  http2trpc_req.setHost("tpbaccess.video.qq.com");
  // http2trpc_req.setGetRequest(, true);
  // http2trpc_req.setHeader("trpc-callee", "fcgi-bin");
  // http2trpc_req.setHeader("trpc-func", "/fcgi-bin/sayhello");
  http2trpc_req.setHeader("Content-Type", "application/octet-stream");
  http2trpc_req.setHeader("Referer", "https://tpbaccess.video.qq.com/");

  spp_rpc::TrpcRequestProtocol trpc_req_;
  spp_rpc::TrpcResponseProtocol trpc_rsp_;
  trpc_req_.logic_header.set_callee("fcgi-bin");
  trpc_req_.logic_header.set_func("/fcgi-bin/sayhello");
  using com::tencent::qqlive::protocol::pb::RequestHead;

  RequestHead head_;
  std::string s_head;
  head_.mutable_version_info()->set_app_id("300005");
  head_.set_callee("fcgi-bin");
  head_.set_func("/fcgi-bin/sayhello");
  head_.SerializeToString(&s_head);

  (*trpc_req_.logic_header.mutable_trans_info())["qqlive_head"] = s_head;

  std::string body;
  std::vector<char> http_body;
  trpc_req_.Encode(&http_body);
  body.assign(http_body.begin(), http_body.end());

  trpc::commaccess::testcase::HelloRequest req1;
  req1.set_msg("dandyhuang test");
  std::vector<char> buf;
  buf.resize(req1.ByteSizeLong());
  req1.SerializeToArray(buf.data(), req1.ByteSizeLong());

  trpc_req_.body.assign(buf.begin(), buf.end());
  std::string url =
      "http://tpbaccess.video.qq.com/fcgi-bin/sayhello?"
      "g_vstk=283616281&g_actk=1458743151";
  http2trpc_req.setPostRequest(url, body, true);

  trpc::commaccess::testcase::HelloReply rsp;

  greeter->AccessHttp(http2trpc_req, &http2trpc_rsp);

  // 首先要判断当前次请求是否有效
  if (greeter->GetResult()) {
    std::cout << "invalid function call, result: " << greeter->GetResult() << std::endl;
    return 0;
  }
  return 0;
}

TEST(CommAccessHttpCase, Case1_HttpMsgTest_P0) { EXPECT_EQ(HttpMsgTest(), 0); }

TEST(CommAccessHttpCase, Case2_HttpTrpcMsgTest_P0) { EXPECT_EQ(HttpTrpcMsgTest(), 0); }
