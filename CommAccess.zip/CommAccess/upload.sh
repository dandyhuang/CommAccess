#########################################################################
# File Name: upload.sh
# Author: 
# Desc:
# Created Time: 2020年07月24日 星期五 14时46分50秒
#########################################################################
#!/bin/bash
./build.sh
cp  bazel-bin/_deploy/sumeru-app.tgz ./
echo ======$1
/usr/local/commlib/tool/dpatch --env test --moduleType normal --application CommAcc --server CommAccess --tgz sumeru-app.tgz --user dandyhuang --set=$1
