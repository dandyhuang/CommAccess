[![BK Pipelines Status](https://api.bkdevops.qq.com/process/api/external/pipelines/projects/video-access/p-0b39b4122d9744ed95ee366a41a548ae/badge?X-DEVOPS-PROJECT-ID=video-access)](http://v2.devops.oa.com/ms/process/api-html/user/builds/projects/video-access/pipelines/p-0b39b4122d9744ed95ee366a41a548ae/latestFinished?X-DEVOPS-PROJECT-ID=video-access)
 [![VEPC Score](https://tpbaccess.video.qq.com/trpc.vepc_tools.vepc_banner.http/score?vappid=70420569&vsecret=6db9bf8c97010b57dd401166223ccd57b8d009c257261d53&origin=1&path=video_pf_access%2fCommAccess)](https://tpbaccess.video.qq.com/trpc.vepc_tools.vepc_banner.http/detail?vappid=70420569&vsecret=6db9bf8c97010b57dd401166223ccd57b8d009c257261d53&origin=1&path=video_pf_access%2fCommAccess)
# CommAccess

基于pb的统一接入层。

[TOC]


## 架构
https://docs.qq.com/doc/DQlZ4TXR2dmpmVnZt?

## 接口
## API

## 背景
统一协议，入口, 对外提供服务

## SOP

## 监控
- 自定义监控
http://007.pcg.com/#/queryData?type=defind&appname=pp_trc_CommAcc.CommAccess_custom_acc_formal
- 主调监控
http://007.pcg.com/#/queryData?appname=vda_CommAcc.CommAccess
- 被调监控
http://007.pcg.com/#/queryData?appname=vdp_CommAcc.CommAccess
- 属性监控
http://007.pcg.com/#/detail?appname=vdm_CommAcc.CommAccess

## 问题定位 染色日志上报
http://tjg.oa.com/?auth_cm_com_ticket=b35df70f-d4c6-4a91-90da-f1f69c2ec56e#/service/txvideo/trace


## 部署与配置
- sumeru部署和tconf管理：
http://sumeru.wsd.com/business_manage/module_main.do?groupId=146291&serviceId=185798&moduleId=185812&envCode=formal&priMenuId=35|module|185812|formal&menupath=Sumeru~%E4%B8%9A%E5%8A%A1%E6%A0%91&treepath=[N][%E8%85%BE%E8%AE%AF%E8%A7%86%E9%A2%91]~[%E5%85%AC%E5%85%B1%E6%9C%8D%E5%8A%A1][%E7%BB%9F%E4%B8%80%E6%8E%A5%E5%85%A5]~CommAcc.CommAccess&layout_p_host=sumeru.wsd.com

- http协议配置:
http://wuji.oa.com/p/edit?appid=dispatch_sz_set&schemaid=t_trpc_routeconf
- pb协议配置:
http://wuji.oa.com/p/edit?appid=dispatch_sz_set&schemaid=t_trpc_routeconf

- 多set
压测:commaccess.sz.pressure
第三方: commaccess.sz.httpthird
主端: commaccess.sz.app
极速版: commaccess.sz.speedapp
http协议: commaccess.sz.http

## 环境信息

- 上游conn测试环境：```9.84.150.120```
- conn预发布环境： ```10.49.123.222```
- 上游conn负责人：```jersonliao```
- 运维：```leefwang```
- 接入层对外网ip：
  - 联通 ```58.251.116.44```
  - 腾讯CAP ```121.51.18.59```
  - 电信 ```113.96.232.73```
- 测试环境L5：```64915649:65536```
- 预发布环境L5: ```64915649:65538```



## 多协议
- 主端
终端: http+qmf+trpc
conn: qmf+qmfacc+trpc
dispatch: trpc
server: trpc
![image.png](/uploads/59C57C08E4D949F880A61DF84F8568A8/image.png)
- tv主端
终端: http+trpc
h5、厂商: http

### http+qmf+trpc接入方案
app->stgw->conn->dispatch->server

### http+trpc接入方案
app->stgw->dispatch->server

123平台: 只需北极星上配置好trpc对应的callee
sumeru: ons上配置好trpc对应的callee

测试环境: callee_147
预发布环境: callee_213
[参考](https://git.code.oa.com/video_pf_access/issues/issues/31)

### 后台代码编写接入
[参考](https://git.code.oa.com/vepc_demo/SppRpcPbDemo)

## 接入层能力
- 支持http、trpc、qmf+trcp等自定义多套协议
- 支持l5、zkname、北极星服务发现
- 负载均衡、流式传输
- 支持鉴权、防水墙、公共开关等通用业务
- 支持染色、链路跟踪、主调被调服务的健康度监控等
- 插件管理

