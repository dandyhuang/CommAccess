#!/bin/sh
PROJECT_NAME="CommAccess"
source /usr/local/commlib/platformlib/spp_rpc_sumeru//scripts/build.sh
build