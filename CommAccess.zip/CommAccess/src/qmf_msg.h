/*
 *
 * Copyright 2019 Tencent authors.
 *
 * qmf msg
 *
 */

#pragma once

#include <arpa/inet.h>
#include <qmf_head_parser.h>

#include <memory>
#include <string>
#include <vector>

#include "common_security_pb/proto/comm_security.spp_rpc.pb.h"
#include "spp_rpc/msg/base_msg.h"
#include "spp_rpc/msg/trpc_msg.h"
#include "src/codec/qmf_protocol.h"
#include "src/comm/config.h"
#include "src/comm/util.h"
#include "video_packet/video_packet.h"

namespace comm_access {

using com::tencent::qqlive::protocol::pb::BackEndRequestHead;
using com::tencent::qqlive::protocol::pb::RequestHead;

class QmfMsg : public spp_rpc::TrpcMsg {
 public:
  QmfMsg() { context_->set_msg(this); }
  ~QmfMsg() = default;

  void set_busi_remote_ip(const std::string& ip) { busi_remote_ip_ = ip; }
  RouteInfo& GetRouteInfo() { return r_info_; }
  void set_config(const WuJiConfig& config) { config_ = std::make_shared<WuJiConfig>(config); }
  std::shared_ptr<const WuJiConfig> config() const {
    if (!config_) {
      static std::shared_ptr<WuJiConfig> empty = std::make_shared<WuJiConfig>();
      return empty;
    }
    return config_;
  }
  com::tencent::spp_rpc::CommAcc::common_security_pb::CheckUserSecurityReply*
  mutable_security_rsp() {
    return &security_rsp_;
  }
  const com::tencent::spp_rpc::CommAcc::common_security_pb::CheckUserSecurityReply& security_rsp()
      const {
    return security_rsp_;
  }
  // void InitVideoPacket();
  const comm_access::qmf_protocol::VideoRequestProtocol& video_req() const { return video_req_; }
  comm_access::qmf_protocol::VideoRequestProtocol* mutable_video_req() { return &video_req_; }
  const comm_access::qmf_protocol::VideoResponseProtocol& video_rsp() const { return video_rsp_; }
  comm_access::qmf_protocol::VideoResponseProtocol* mutable_video_rsp() { return &video_rsp_; }
  // std::shared_ptr<CVideoPacket> packet() const { return packet_; }
  const spp_rpc::ProtoType GetProto() const override { return spp_rpc::PROTO_TYPE_QMF; }
  std::shared_ptr<RequestHead> GetVideoMutableReqHead() override {
    if (!head_) {
      head_ = std::make_shared<RequestHead>(video_req_.logic_header);
    }
    return head_;
  }
  void ResponseImp(int frame_code, int logic_code) override;

 protected:
  int DecodeAcc(const char* buf, const size_t len);
  // 输入参数是trpc协议序列化的结果
  int EncodeTrpc(const char* buf, const size_t len);
  int DecodeTrpcHead(const char* buf, const size_t len);
  void GetRoute();
  void ErrorCodeCovert(int* frame_code);

  int DecodeReq() override;
  int CheckParams() override;
  void ParseLoginToken() override;
  int ProcessServant() override;
  const std::string& GetTracerServantName() const override {
    static std::string name = "normal.CommAcc.CommAccess";
    return name;
  }
  void AttaReport();
  void SetEnvTransInfo();

 protected:
  comm_access::qmf_protocol::QmfHelper qmf_helper_;
  comm_access::qmf_protocol::VideoRequestProtocol video_req_;
  comm_access::qmf_protocol::VideoResponseProtocol video_rsp_;
  // std::shared_ptr<CVideoPacket> packet_;
  std::shared_ptr<WuJiConfig> config_ = nullptr;
  RouteInfo r_info_;
  std::string busi_remote_ip_;

  com::tencent::spp_rpc::CommAcc::common_security_pb::CheckUserSecurityReply security_rsp_;
};

spp_rpc::SppRpcBaseMsg* QmfMsgCreater();

}  // namespace comm_access
