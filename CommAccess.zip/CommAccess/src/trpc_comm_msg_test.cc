
// Copyright 2020 Tencent authors.

#include "trpc_comm_msg.h"

#include <iostream>

#include "gtest/gtest.h"

TEST(TrpcMsg, DefaultConifg_Test) {
  ASSERT_NE(comm_access::TrpcCommMsg::default_config(), nullptr);
  EXPECT_EQ(comm_access::TrpcCommMsg::default_config()->route_flag, 2);
}
