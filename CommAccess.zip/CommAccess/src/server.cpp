/*
 *
 * Copyright 2019 Tencent authors.
 *
 * qmf协议校验逻辑
 *
 */

#include "spp_rpc/codec/http/http_protocol.h"
#include "spp_rpc/common/flow.h"
#include "spp_rpc/spp_rpc.h"
#include "src/access_err.h"
#include "src/codec/qmf_protocol.h"
#include "src/comm/config.h"
#include "src/comm/tools.h"
#include "src/config_frame/config_factory.h"
#include "src/http_comm_msg.h"
#include "src/plugin_frame/plugin_comm_msg.h"
#include "src/plugin_frame/plugin_factory.h"
#include "src/qmf_msg.h"
#include "src/third_msg.h"
#include "src/trpc_comm_msg.h"
#include "src/trpc_comm_msg_v2.h"
#include "src/trpc_http_msg_v2.h"

extern "C" int spp_handle_init(void* arg1, void* arg2) {
  int ret = spp_rpc_handle_init(arg1, arg2);
  if (ret) return ret;

  RPC_LOG_RET(INS_CONFIG->Init(), "init config err");
  RPC_LOG_RET(INS_TOOLS->Init(), "init tools err");

  RPC_LOG_RET(INS_DOCKER_ENV->Init(), "init docker env err");
  RPC_DLOG("docker env:env[%s], namespace[%s], set[%s]", INS_DOCKER_ENV->docker_env().c_str(),
           INS_DOCKER_ENV->namepsace().c_str(), INS_DOCKER_ENV->docker_set().c_str());

  // 可以在这里实现自己的初始化逻辑，如果有需要的话。
  auto conf = spp_rpc::ConfigManagerSingleton::getInstance();
  spp_rpc::MsgFactory::getInstance()->Add(conf->main_port(),
                                          comm_access::PluginMsgCreater<comm_access::QmfMsg>);
  spp_rpc::ProtoCheckerFactory::getInstance()->Add(conf->main_port(),
                                                   comm_access::qmf_protocol::QmfChecker);
  RPC_DLOG("port:%u add qmf checker", conf->main_port());

  char* env = getenv("trpc_acc_port");
  if (env == nullptr) {
    RPC_LOG_RET(-1, "getenv trpc_acc_port ret null");
  }
  uint32_t trpc_acc_port = atoi(env);
  if (INS_TOOLS->refactor_version()) {
    spp_rpc::MsgFactory::getInstance()->Add(
        trpc_acc_port, comm_access::PluginMsgCreater<comm_access::TrpcCommMsgV2>);
  } else {
    spp_rpc::MsgFactory::getInstance()->Add(
        trpc_acc_port, comm_access::PluginMsgCreater<comm_access::TrpcCommMsg>);
  }

  spp_rpc::ProtoCheckerFactory::getInstance()->Add(trpc_acc_port, spp_rpc::TrpcChecker);
  RPC_DLOG("bind trpc, port:%d", trpc_acc_port);

  // http协议
  env = getenv("http_acc_port");
  if (env == nullptr) {
    RPC_LOG_RET(-1, "getenv http_acc_port ret null");
  }
  uint32_t http_acc_port = atoi(env);
  spp_rpc::MsgFactory::getInstance()->Add(http_acc_port, comm_access::ThirdMsgCreater);
  spp_rpc::ProtoCheckerFactory::getInstance()->Add(http_acc_port, spp_rpc::HttpChecker);
  RPC_DLOG("port:%u add http msg", http_acc_port);

  // http2trp协议
  env = getenv("http2trpc_port");
  if (env == nullptr) {
    RPC_LOG_RET(-1, "getenv http2trpc_port ret null");
  }
  uint32_t http2trpc_port = atoi(env);
  spp_rpc::ProtoCheckerFactory::getInstance()->Add(http2trpc_port, spp_rpc::HttpChecker);
  spp_rpc::MsgFactory::getInstance()->Add(http2trpc_port,
                                          comm_access::PluginMsgCreater<comm_access::HttpCommMsg>);

  RPC_DLOG("port:%u add http2trpc msg", http2trpc_port);

  // http+trpc协议
  env = getenv("http_trpc_port");
  if (env == nullptr) {
    RPC_LOG_RET(-1, "getenv http_trpc_port ret null");
  }
  if (INS_TOOLS->refactor_version()) {
    uint32_t http_trpc_port = atoi(env);
    spp_rpc::ProtoCheckerFactory::getInstance()->Add(http_trpc_port, spp_rpc::HttpChecker);
    spp_rpc::MsgFactory::getInstance()->Add(
        http_trpc_port, comm_access::PluginMsgCreater<comm_access::TrpcHttpMsgV2>);
    RPC_DLOG("port:%u add http_trpc_port msg", http_trpc_port);
  }

  // 插件初始化
  RPC_LOG_RET(comm_access::PluginFactorySingleton::getInstance()->Init(arg1, arg2),
              "init plugin err");
  if (INS_TOOLS->refactor_version()) {
    RPC_LOG_RET(INS_CONFIG_MGR->Init(), "init config err");
  }

  return 0;
}

extern "C" int spp_handle_input(unsigned flow, void* arg1, void* arg2) {
  return spp_rpc_handle_input(flow, arg1, arg2);
}

extern "C" int spp_handle_route(unsigned flow, void* arg1, void* arg2) {
  return spp_rpc_handle_route(flow, arg1, arg2);
}

extern "C" int spp_handle_process(unsigned flow, void* arg1, void* arg2) {
  return spp_rpc_handle_process(flow, arg1, arg2);
}

extern "C" void spp_handle_fini(void* arg1, void* arg2) { return spp_rpc_handle_fini(arg1, arg2); }
