// Copyright 2020 Tencent authors.
#include "src/configs/route/route_config.h"

#include <map>
#include <utility>
#include <vector>

#include "spp_rpc/common/logger/logger_interface.h"
#include "spp_rpc/spp_rpc.h"
#include "src/config_frame/config_factory.h"

namespace comm_access {

extern "C" void* access_trpc_troute_config() {
  return NewConfigUpdater<TrpcRouteConfigParser, RouteConfig>("route_config_id");
}

COMM_ACCESS_REGISTER_CONFIG_FUNC(kTrpcRouteConfigId, access_trpc_troute_config);

ConfigRecordPtr TrpcRouteConfigParser::Parse(const std::map<std::string, std::string>& m) {
  RouteConfigRecordPtr config = std::make_shared<RouteConfig>();
  config->proto_type_ = atoi(GetOrElse(m, "prototype", "").c_str());
  config->route_flag_ = atoi(GetOrElse(m, "route_flag", "").c_str());
  config->service_namespace_ = GetOrElse(m, "service_namespace", "");
  config->service_name_ = GetOrElse(m, "service_name", "");
  std::string meta = GetOrElse(m, "metadata", "");
  // 失败继续执行，不要影响其他配置
  int ret = config->ParseMetaData(meta);
  if (ret) ::spp_rpc::AttrApi(config->func_ + "meta", 1);
  config->mod_id_ = atol(GetOrElse(m, "modid", "").c_str());
  config->cmd_id_ = atol(GetOrElse(m, "cmdid", "").c_str());
  config->appid_ = GetOrElse(m, "appid", "");
  config->callee_ = GetOrElse(m, "callee", "");
  config->func_ = GetOrElse(m, "func", "");
  config->timeout_ = atoi(GetOrElse(m, "timeout", "").c_str());
  return config;
}

int RouteConfig::ParseMetaData(const std::string& metadata) {
  if (metadata.empty()) return 0;
  rapidjson::Document doc;
  if (doc.Parse(metadata.data()).HasParseError()) {
    RPC_TLOG("func:%s meta parse error", this->func_.c_str());
    return -1;
  }
  // 防止NULL对象
  if (!doc.IsObject()) {
    doc.SetObject();
  }
  if (!doc.HasMember("metadata") || !doc["metadata"].IsArray()) {
    return -1;
  }

  const rapidjson::Value& array = doc["metadata"];
  size_t len = array.Size();
  for (size_t i = 0; i < len; i++) {
    const rapidjson::Value& object = array[i];
    if (object.IsObject()) {
      std::string key, value;
      if (object.HasMember("key") && object["key"].IsString()) {
        key = object["key"].GetString();
      }
      if (object.HasMember("value") && object["value"].IsString()) {
        value = object["value"].GetString();
      }
      if (!key.empty() && !value.empty()) {
        this->meta_data_.insert(std::make_pair(key, value));
      } else {
        RPC_ELOG("func:%s meta key value set empty", this->func_.c_str());
        return -1;
      }
    }
  }
  return 0;
}

}  // namespace comm_access
