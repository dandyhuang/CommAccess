// Copyright 2020 Tencent authors.

#pragma once

#include <map>
#include <memory>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

#include "spp_rpc/common/logger/logger_interface.h"
#include "src/comm/docker_env.h"
#include "src/comm/tools.h"
#include "src/config_frame/config_interface.h"

namespace comm_access {

static const int kRouteTimeOut = 800;
enum ConfigRouteType {
  ACCESS_ONS_TYPE = 0,
  ACCESS_L5_TYPE = 1,
  ACCESS_BJX_TYPE = 2,
};

enum RouteStandardType {
  ACCESS_TRPC_TYPE = 0,
  ACCESS_HTTP_TYPE = 1,
  ACCESS_THIRD_TYPE = 2,
};

inline std::string GetRouteConfigKey(int proto_type, const std::string& appid,
                                     const std::string& callee, const std::string& func) {
  std::string prototype;
  switch (proto_type) {
    case ACCESS_TRPC_TYPE:
      prototype = "Qmf.";
      break;
    case ACCESS_HTTP_TYPE:
      prototype = "Http.";
      break;
    case ACCESS_THIRD_TYPE:
      prototype = "Third.";
      break;
    default:
      prototype = "Trpc.";
      break;
  }
  std::string key = prototype + appid + callee + func;
  return key;
}

class RouteConfig : public ConfigRecord {
 public:
  uint16_t route_flag_{ACCESS_ONS_TYPE};  // 0: zkname 1:l5 路由 2:bjx
  uint32_t mod_id_{0};
  uint32_t cmd_id_{0};
  uint32_t timeout_{kRouteTimeOut};

  std::string service_namespace_;
  std::string service_name_;
  std::string url_;
  std::unordered_map<std::string, std::string> meta_data_;
  const std::string key() const override {
    return comm_access::GetRouteConfigKey(proto_type_, appid_, callee_, func_);
  }

  int ParseMetaData(const std::string& metadata);
};
typedef tars::TC_AutoPtr<RouteConfig> TrpcRouteConfigRecordPtr;

class TrpcRouteConfigParser : public ConfigParser {
 public:
  ConfigRecordPtr Parse(const std::map<std::string, std::string>& m) override;
};

extern "C" void* access_trpc_troute_config();
typedef std::shared_ptr<RouteConfig> RouteConfigRecordPtr;

inline std::string GetOnsBackfix(std::string protocol = "") {
  static std::string backfix = "";
  if (backfix.empty()) {
    static const std::string& dockerenv = INS_DOCKER_ENV->docker_env();
    if (dockerenv == kEnvTest) backfix = "_147";
    if (dockerenv == kEnvPre) backfix = "_213";
  }
  return protocol + backfix;
}

template <typename Ptr>
void RouteOnsInfo(const Ptr& ptr, const std::string& name, std::string protocol = "") {
  static const std::string backfix = GetOnsBackfix(protocol);
  RPC_TLOG("name:%s, fix:%s", name.c_str(), backfix.c_str());
  if (backfix.empty()) {
    ptr->mutable_route_point()->SetZkname(name);
  } else {
    ptr->mutable_route_point()->SetZkname(name + backfix);
  }
}

template <typename Ptr>
inline void SetRouteInfo(const Ptr& ptr, const RouteConfig& info, std::string callee = "",
                         std::string protocol = "") {
  switch (info.route_flag_) {
    case ACCESS_ONS_TYPE:
      RouteOnsInfo(ptr, callee, protocol);
      break;
    case ACCESS_L5_TYPE:
      ptr->mutable_route_point()->SetL5(info.mod_id_, info.cmd_id_);
      break;
    case ACCESS_BJX_TYPE:
      ptr->mutable_route_point()->SetPolaris(&info.service_name_, &info.service_namespace_);
      if (info.meta_data_.size() > 0) {
        ptr->mutable_route_point()->SetPolarisMetadata(info.meta_data_);
      }
      break;
    default:
      RouteOnsInfo(ptr, callee);
      break;
  }

  if (info.timeout_ == 0 || info.timeout_ == kRouteTimeOut) {
    ptr->mutable_route_point()->SetTimeout(kRouteTimeOut);
  } else {
    ptr->mutable_route_point()->SetTimeout(info.timeout_);
  }
}

}  // namespace comm_access
