//  Copyright 2020 Tencent authors.

#define private public
#define protected public

#include "src/configs/demo/demo_config.h"

#include <map>

#include "gmock/gmock.h"
#include "gtest/gtest.h"
#include "src/config_frame/config_interface.h"

TEST(ConfigParser, Case1_ConfigParser_P0) {
  comm_access::DemoConfigParser parser;
  const std::map<std::string, std::string> m{
      {"prototype", "5"},
      {"appid", "appid_test"},
      {"callee", "callee_test"},
      {"func", "func_test"},
  };
  auto config = parser.Parse(m);
  ASSERT_NE(config, nullptr);
  ASSERT_TRUE(parser.Filter(config));
  EXPECT_EQ(config->proto_type_, 5);
  EXPECT_EQ(config->appid_, "appid_test");
  EXPECT_EQ(config->callee_, "callee_test");
  EXPECT_EQ(config->func_, "func_test");
}
