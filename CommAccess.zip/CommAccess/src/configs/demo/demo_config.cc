// Copyright 2020 Tencent authors.
#include "src/configs/demo/demo_config.h"

#include <map>
#include <utility>
#include <vector>

#include "spp_rpc/common/logger/logger_interface.h"
#include "spp_rpc/spp_rpc.h"
#include "src/config_frame/config_factory.h"

namespace comm_access {

extern "C" void* access_demo_config() {
  return NewConfigUpdater<DemoConfigParser, DemoConfig>("demo_config_id");
}

COMM_ACCESS_REGISTER_CONFIG_FUNC(kDemoConfig, access_demo_config);

ConfigRecordPtr DemoConfigParser::Parse(const std::map<std::string, std::string>& m) {
  DemoConfigRecordPtr config = std::make_shared<DemoConfig>();
  config->proto_type_ = atoi(GetOrElse(m, "prototype", "").c_str());
  config->callee_ = GetOrElse(m, "callee", "");
  config->func_ = GetOrElse(m, "func", "");
  config->appid_ = GetOrElse(m, "appid", "");
  config->demo_ = "demo_test";
  return config;
}
}  // namespace comm_access
