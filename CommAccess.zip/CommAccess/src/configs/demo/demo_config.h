// Copyright 2020 Tencent authors.

#pragma once

#include <map>
#include <memory>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

#include "spp_rpc/common/logger/logger_interface.h"
#include "src/config_frame/config_interface.h"

namespace comm_access {

class DemoConfig : public ConfigRecord {
 public:
  std::string demo_;
};

class DemoConfigParser : public ConfigParser {
 public:
  ConfigRecordPtr Parse(const std::map<std::string, std::string>& m) override;
};

extern "C" void* access_demo_config();

typedef std::shared_ptr<DemoConfig> DemoConfigRecordPtr;
}  // namespace comm_access
