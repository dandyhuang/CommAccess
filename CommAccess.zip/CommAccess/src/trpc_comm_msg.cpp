/*
 *
 * Copyright 2019 Tencent authors.
 *
 * trpc msg.
 *
 */

#include "src/trpc_comm_msg.h"

#include <string>
#include <vector>

#include "spp_rpc/client/binary_proxy.h"
#include "spp_rpc/client/trpc_servant_proxy.h"
#include "spp_rpc/codec/trpc/trpc_protocol.h"
#include "spp_rpc/spp_rpc.h"
#include "src/access_err.h"
#include "src/comm/tools.h"
#include "src/config_frame/config_factory.h"

namespace comm_access {

spp_rpc::SppRpcBaseMsg* TpcCommMsgCreater() { return new (std::nothrow) TrpcCommMsg; }

int TrpcCommMsg::DecodeReq() {
  RPC_LOG_FUNCTION_START;
  // 作为路由层，只需要解析包头即可
  RPC_LOG_RET(req_.DecodeHeader(_msg_buff.data(), _msg_buff.size()), "decode req err");
  seqnum_ = std::to_string(req_.logic_header.request_id());
  body_ = _msg_buff.data() + spp_rpc::TrpcFixedHeader::TRPC_PROTO_PREFIX_SPACE +
          req_.frame_header.pb_header_size;
  body_len_ = req_.frame_header.data_frame_size -
              spp_rpc::TrpcFixedHeader::TRPC_PROTO_PREFIX_SPACE - req_.frame_header.pb_header_size;

#if SPP_RPC_DEBUG
  for (const auto& item : req_.logic_header.trans_info()) {
    RPC_TLOG("trans_info value, [%lu]%s:%s", item.second.size(), item.first.c_str(),
             item.second.c_str());
  }
#endif

  appid_ = GetCallerId();
  if (appid_.empty()) {
    appid_ = INS_CONFIG->GetVAppid();
  }

  string c_key =
      GetWujiConfigKey(QMF_TYPE, appid_, req_.logic_header.callee(), req_.logic_header.func());

  SPAN_DLOG(this, "c_key:%s ", c_key.c_str());

  config_ = INS_CONFIG->GetWujiConfig(c_key, QMF_TYPE);
  // 后续迁到北极星这块逻辑就可以废掉了
  if (INS_CONFIG->IsDefault(config_)) {
    config_ = TrpcCommMsg::default_config();
  }
  RPC_LOG_FUNCTION_END;
  return 0;
}

int TrpcCommMsg::ProcessServant() {
  RPC_LOG_FUNCTION_START;
  proxy_ptr_ = spp_rpc::GetServantProxy<spp_rpc::BinaryRpcProxyPtr>(req_.logic_header.callee());
  RouteInfo info;
  info.name = req_.logic_header.callee();
  SetRoute(proxy_ptr_, info);
  proxy_ptr_->set_cur_func_name(req_.logic_header.func());

  std::vector<char> req_buff;
  spp_rpc::EncodeTrpcProtocol(&req_buff, req_.frame_header, req_.logic_header, body_, body_len_);

  // TODO(songliao): 暂时是直接转发，
  // 后续看下接入层接入天机阁是否需要在包头塞字段
  RPC_LOG_RET(proxy_ptr_->Exec(req_buff.data(), req_buff.size(), &rsp_, &rsp_size_,
                               spp_rpc::CheckTrpcPacket),
              "proxy err");
  RPC_LOG_FUNCTION_END;
  return 0;
}

void TrpcCommMsg::ResponseImp(int frame_code, int logic_code) {
  if (frame_code) {
    SPAN_ELOG(msg(), "process err, ret:%d", frame_code);
    spp_rpc::TrpcResponseProtocol rsp;
    if (!rsp_ || !rsp_size_) {
      static std::vector<char> rsp_buf;
      rsp.logic_header.set_ret(frame_code);
      rsp.logic_header.set_func_ret(logic_code);
      rsp.Encode(&rsp_buf);
      this->Response(rsp_buf.data(), rsp_buf.size());
      return;
    }
  }
  RPC_TLOG("response|rsp:%p|rsp_size:%lu", rsp_, rsp_size_);
  this->Response(rsp_, rsp_size_);
  INS_CONFIG->UpdateWujiConfig(QMF_TYPE);
  if (INS_TOOLS->refactor_version()) {
    INS_CONFIG_MGR->UpdateConfig();
  }
}

}  // namespace comm_access
