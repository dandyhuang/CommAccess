// Copyright 2019 Tencent authors.
#include "src/qmf_msg.h"

#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>

#include <array>
#include <map>
#include <string>
#include <vector>

#include "backend_header.pb.h"  // NOLINT
#include "jce/teen_guardian_flag.h"
#include "spp_rpc/codec/trpc/pb2jce.h"
#include "spp_rpc/common/flow.h"
#include "src/access_err.h"
#include "src/attr_report.h"
#include "src/codec/qmf_protocol.h"
#include "src/comm/taskdec.h"
#include "src/comm/tools.h"
#include "src/plugins/check_auth/check_auth_server.h"
#include "token_api.h"            // NOLINT
#include "unified_config_wuji.h"  // NOLINT

namespace comm_access {

using com::tencent::qqlive::protocol::pb::BackEndRequestHead;

spp_rpc::SppRpcBaseMsg* QmfMsgCreater() { return new (std::nothrow) QmfMsg; }

int QmfMsg::DecodeReq() {
  SPAN_LOG_FUNCTION_START(this);
  // TODO(songliao): 不用第三方库提供的序列化逻辑，可以避免部分拷贝
  SPAN_LOG_RET(this, DecodeAcc(_msg_buff.data(), _msg_buff.size()), "decode acc err");

  // 视频私有pb协议解析
  SPAN_LOG_RET(this,
               video_req_.Decode(reinterpret_cast<const char*>(qmf_helper_.qmf_head().Body),
                                 qmf_helper_.qmf_head().BodyLen),
               "VideoRequestProtocol decode err");
  string c_key =
      GetWujiConfigKey(QMF_TYPE, GetVideoMutableReqHead()->version_info().app_id(),
                       GetVideoMutableReqHead()->callee(), GetVideoMutableReqHead()->func());

  SPAN_DLOG(this, "c_key:%s ", c_key.c_str());
  config_ = INS_CONFIG->GetWujiConfig(c_key, QMF_TYPE);

  req_.frame_header = video_req_.frame_header;
  req_.logic_header.set_callee(GetVideoMutableReqHead()->callee());
  req_.logic_header.set_func(GetVideoMutableReqHead()->func());
  req_.logic_header.set_request_id(GetVideoMutableReqHead()->request_id());

  SetEnvTransInfo();

  GetVideoMutableReqBackendHead()->mutable_user_info()->set_area_code(
      INS_TOOLS->GetAreaCode(qmf_helper_.qmf_acc_head().ClientIP, qmf_helper_.qmf_head()));

  req_.body = video_req_.body;
  RPC_DLOG("req:%s", req_.logic_header.DebugString().c_str());
  SPAN_LOG_FUNCTION_END(this);
  return 0;
}

void QmfMsg::SetEnvTransInfo() {
  const auto& env_info = GetVideoMutableReqHead()->env_info();
  auto it = env_info.metadata().find("trpc-env");
  if (it == env_info.metadata().end() || it->second.empty()) return;

  // 理论上，正式环境不应该走到这里
  SetExtraValue(it->first, it->second);
  std::string json_content;
  google::protobuf::util::MessageToJsonString(env_info, &json_content);
  SPAN_TLOG(this, "set env trans info:%s", json_content.c_str());
}

void QmfMsg::ParseLoginToken() {
  int token_size = GetVideoMutableReqHead()->login_token_size();
  std::string v_openid;
  bool has_qq_openid{false};
  uint64_t qq{0};
  std::vector<LoginToken> v_token;
  for (int i = 0; i < token_size; ++i) {
    const auto& item = GetVideoMutableReqHead()->login_token(i);
    switch (item.type()) {
      case 1:
      case 7:
        qq_ = item.account();
        break;
      case 9:
        vuid_ = item.account();
        v_openid = item.token();
        if (GetQQFromToken(v_openid, qq)) {
          qq = 0;
        }
        qq_ = std::to_string(qq);
        break;
      case 10:
        qq_openid_ = item.account();
        has_qq_openid = true;
        break;
      case 100:
        wechat_openid_ = item.account();
        break;
    }
    v_token.push_back(item);
  }
  if (has_qq_openid) {
    if (!GetQQFromToken(v_openid, qq)) {
      SPAN_TLOG(context_->msg(), "v_openid:%s|qq_:%lu", v_openid.c_str(), qq);
      qq_ = std::to_string(qq);
      LoginToken token;
      token.set_app_id("350001");
      token.set_type(1);
      token.set_account(qq_);
      token.set_token(v_openid);
      token.set_is_main_login(false);
      v_token.push_back(token);
    }
  }
  GetVideoMutableReqHead()->clear_login_token();
  for (auto& v : v_token) {
    LoginToken* token = GetVideoMutableReqHead()->add_login_token();
    *token = v;
  }
  RPC_TLOG("qq:%s vuid:%s qq_openid:%s wechat_openid:%s token.size:%d", qq_.c_str(), vuid_.c_str(),
           qq_openid_.c_str(), wechat_openid_.c_str(),
           GetVideoMutableReqHead()->login_token_size());
}

int QmfMsg::CheckParams() {
  // TODO(dandyhuang): 看看是否需要对解析后的包做参数校验
  return 0;
}

int QmfMsg::ProcessServant() {
  RPC_LOG_FUNCTION_START;

  auto prx = spp_rpc::GetServantProxy<spp_rpc::TrpcServantProxyPtr>(req_.logic_header.callee());
  prx->set_cur_func_name(req_.logic_header.func());

  GetRoute();
  SetRoute(prx, r_info_);

  auto status = prx->InvokeTrpc2(req_, &rsp_, context_);
  frame_error_code_ = status.GetOneCode();
  RPC_LOG_RET(frame_error_code_, "InvokeTrpc2 err");

  // TODO(songliao): logic_header.ret() 是不是也算作框架错误码？
  logic_error_code_ =
      rsp_.logic_header.ret() ? rsp_.logic_header.ret() : rsp_.logic_header.func_ret();
  // 业务返回的错误码放在ResponseHead里
  video_rsp_.logic_header.set_err_code(logic_error_code_);
  video_rsp_.logic_header.set_request_id(GetVideoMutableReqHead()->request_id());
  RPC_TLOG("proxy %s, %s, ret:%d func_ret:%d, ip=%s, port=%d", req_.logic_header.callee().c_str(),
           req_.logic_header.func().c_str(), rsp_.logic_header.ret(), rsp_.logic_header.func_ret(),
           prx->route_point().GetIp().c_str(), prx->route_point().GetPort());
  busi_remote_ip_ = prx->route_point().GetIp();
  video_rsp_.body = rsp_.body;

  RPC_LOG_FUNCTION_END;
  return 0;
}

void QmfMsg::ResponseImp(int frame_code, int logic_code) {
  if (replied()) {
    return;
  }
  video_rsp_.logic_header.set_err_code(logic_code);
  video_rsp_.logic_header.set_request_id(req_.logic_header.request_id());
  video_rsp_.body = rsp_.body;
  if (frame_code) {
    RPC_ELOG("process err, ret:%d", frame_code);
    ErrorCodeCovert(&frame_code);
    if (config_ && 1 == config_->water_flag && security_rsp_.ret() == frame_code &&
        E_QMF_SECURITY_BEGIN <= frame_code && E_QMF_SECURITY_END >= frame_code) {
      qmf_helper_.mutable_qmf_head()->RetCode = frame_code;
      std::vector<char> rsp_buf;
      comm_access::qmf_protocol::VideoResponseProtocol video_rsp;
      video_rsp.logic_header.set_err_code(frame_code);
      video_rsp.logic_header.mutable_safe_info()->set_safe_result(security_rsp_.safe_result());
      video_rsp.Encode(&rsp_buf);
      qmf_helper_.Encode(rsp_buf.data(), rsp_buf.size());
    } else {
      qmf_helper_.mutable_qmf_head()->RetCode = frame_code;
      static std::vector<char> rsp_buf;
      if (rsp_buf.empty()) {
        comm_access::qmf_protocol::VideoResponseProtocol video_rsp_;
        video_rsp_.Encode(&rsp_buf);
      }
      qmf_helper_.Encode(rsp_buf.data(), rsp_buf.size());
    }
  } else {
    std::vector<char> rsp_buf;
    video_rsp_.Encode(&rsp_buf);
    qmf_helper_.Encode(_msg_buff.data(), rsp_buf.data(), rsp_buf.size());
  }

  RPC_TLOG("response len:%lu", qmf_helper_.rsp_buff_len());
  this->Response(qmf_helper_.rsp_buf(), qmf_helper_.rsp_buff_len());
  INS_CONFIG->UpdateWujiConfig(QMF_TYPE);
  AttaReport();
}

void QmfMsg::ErrorCodeCovert(int* frame_code) {
  switch (*frame_code) {
    case spp_rpc::SPP_RPC_SPP_SEND:
      *frame_code = E_DISPATCH_SEND_TIME_OUT;
      break;
    case spp_rpc::SPP_RPC_SPP_RCV:
      *frame_code = E_DISPATCH_REV_TIME_OUT;
      break;
    case spp_rpc::SPP_RPC_SPP_LINK:
      *frame_code = E_DISPATCH_LINK_TIME_OUT;
      break;
    case spp_rpc::SPP_RPC_SPP_CLOSE:
      *frame_code = E_DISPATCH_SEND_TIME_OUT;
      break;
    case spp_rpc::SPP_RPC_GET_ADDR:
      *frame_code = E_DISPATCH_ROUTE_FAIL;
      break;
  }
}

void QmfMsg::AttaReport() {
  pcg_attr::STAttrReport report;
  report.callee = req_.logic_header.callee();
  report.func = req_.logic_header.func();
  report.appid = GetVideoMutableReqHead()->version_info().app_id();
  report.version = GetVideoMutableReqHead()->version_info().version_name();
  auto pf = std::to_string(GetVideoMutableReqHead()->version_info().platform());
  report.platform = pf;

  report.active_ip = context_->GetLocalIp();
  report.passive_ip = busi_remote_ip_;
  report.calltype = "active";

  // Dimension
  report.total = 1;
  if (rsp_.logic_header.func_ret() == 0) {
    report.success = 1;
  } else {
    report.failed = 1;
  }

  report.cost = context_->msg()->GetMsgCost();
  report.ret = rsp_.logic_header.ret();
  report.func_ret = rsp_.logic_header.func_ret();
  report.auto_retry_flag = video_req_.logic_header.flag_info().auto_retry_flag();

  RPC_TLOG("report callee:%s, func:%s ,cost:%d", report.callee.c_str(), report.func.c_str(),
           report.cost);
  INS_ATTR->CustomItemAttr(report);

  report.active_ip = remote_ip_;
  report.passive_ip = context_->GetLocalIp();
  report.calltype = "passive";
  INS_ATTR->CustomItemAttr(report);
}

void QmfMsg::GetRoute() {
  r_info_.name = req_.logic_header.callee();
  RPC_DLOG("route_flag:%d", config_->route_flag);
  if (config_->route_flag == ROUTE_L5) {
    r_info_.mod_id = config_->mod_id;
    r_info_.cmd_id = config_->cmd_id;
    r_info_.type = ROUTE_L5;
  } else if (config_->route_flag == ROUTE_POLIARIS) {
    r_info_.type = ROUTE_POLIARIS;
    r_info_.service_name = config_->service_name;
    r_info_.service_namespace = config_->service_namespace;
  }
}

int QmfMsg::DecodeAcc(const char* buf, const size_t len) { return qmf_helper_.Decode(buf, len); }

int QmfMsg::DecodeTrpcHead(const char* buf, const size_t len) {
  int ret = req_.DecodeHeader(reinterpret_cast<const char*>(qmf_helper_.qmf_head().Body),
                              qmf_helper_.qmf_head().BodyLen);
  if (ret) {
    spp_rpc::AttrApi("decode_trpc_head", 1);
    RPC_ELOG("decode trpc head ret:%d", ret);
    return E_QMF_DECODE_TRPC_HEAD;
  }
  return 0;
}
}  // namespace comm_access
