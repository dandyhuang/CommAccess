/*
 *
 * Copyright 2020 Tencent authors.
 *
 * config
 *
 */

#pragma once

#include <map>
#include <memory>
#include <string>
#include <unordered_map>

#include "ipblock_api/include/Area2Code.h"
#include "ipblock_api/include/ipblock_api.h"
#include "ipblock_api/include/ipblock_api_v6.h"
#include "qmf_protocal_inter.h"  // NOLINT
#include "spp_rpc/common/logger/logger_interface.h"
#include "src/attr_report.h"
#include "src/comm/docker_env.h"
#include "unified_config_wuji.h"  // NOLINT
#include "util/tc_singleton.h"

namespace comm_access {

static const int kTimeOut = 800;

enum StandardType {
  QMF_TYPE = 0,
  HTTP_TYPE = 1,
  TRPC_TYPE = 2,
};

enum CacheMode {
  kNotCacheMode = 0,         // 不走缓存和防白屏
  kCacheMode = 1,            // 缓存
  kAntiWhiteScreenMode = 2,  // 防白屏
};

enum FlagType {
  CLOSE_FLAG_TYPE = 0,
  START_FLAG_TYPE = 1,
};

inline std::string GetWujiConfigKey(int proto_type, std::string appid, std::string callee,
                                    std::string func) {
  std::string prototype;
  switch (proto_type) {
    case QMF_TYPE:
      prototype = "Qmf.";
      break;
    case HTTP_TYPE:
      prototype = "Http.";
      break;
    case TRPC_TYPE:
      prototype = "Trpc.";
      break;
    default:
      prototype = "Qmf.";
      break;
  }
  std::string key = prototype + appid + callee + func;
  return key;
}

struct WuJiConfig {
  uint16_t auth_flag{0};
  uint16_t water_flag{0};
  uint16_t video_flag{0};
  uint16_t area_level{0};
  uint16_t dye_flag{0};
  uint16_t route_flag{0};  // 0: zkname 1:l5 路由 2:bjx
  uint16_t user_flag{0};
  uint32_t cmd_id{0};
  uint32_t mod_id{0};
  uint32_t proto_type{0};
  uint32_t timeout{kTimeOut};
  uint32_t gtk_flag{0};
  uint32_t limit_flag{0};
  uint64_t t_id{0};
  std::string appid;
  std::string url;
  std::string callee;
  std::string service_namespace;
  std::string service_name;
  std::unordered_map<std::string, std::string> meta_data;
  std::string func;
  std::string hosts;
  std::string referer;
  bool close_retry{true};

  CacheMode cache_type{kNotCacheMode};
  uint32_t cache_mod_id{0};        // CommCache读服务L5
  uint32_t cache_cmd_id{0};        // CommCache读服务L5
  uint32_t cache_write_mod_id{0};  // CommCache写服务L5
  uint32_t cache_write_cmd_id{0};  // CommCache写服务L5

  inline std::string GetWujiConfigKey() {
    return comm_access::GetWujiConfigKey(proto_type, appid, callee, func);
  }
};

// 杒件框架酝置 mode是指业务指定杒件的模弝，未酝置，黑坝坕，白坝坕三秝模弝
enum MODE { kNotConfig = 0,
            kIsBlacklist = 1,
            kIsWhitelist = 2 };

// 杒件框架酝置结构
struct PluginConfig {
  int id{0};
  int mode{0};                      // 0:黑坝坕模弝，1:白坝坕模弝
  std::vector<uint32_t> blacklist;  // 覝按照杒件id排庝
  std::vector<uint32_t> whitelist;
  std::unordered_map<uint32_t, uint32_t> custom_priority;  // 自定义杒件优先级
};

class Config {
 public:
  Config() { default_wuji_ = std::make_shared<WuJiConfig>(); }
  ~Config() {}

  int Init();
  void SplitStr(const std::string& str, const std::string& sign,
                std::vector<std::string>& results);  // NOLINT

  int CheckIP(const std::string& ip);

  // std::string GetAreaCode(const uint64_t& ipv4, const QMF_PROTOCAL::QmfHead& qmf_head);
  std::string AreaGbk2Utf8(const vapi::IPBlockNode& node);

  const UnifiedConfigWujiMult& GetWujiInstance() { return config_wuji_mult_; }
  uint32_t timeout() const { return timeout_; }

  std::shared_ptr<WuJiConfig> GetWujiConfig(const std::string& key, int type);
  int ParseMetaData(WuJiConfig* config, const std::string& metadata);
  int UpdateWujiConfig(int type);
  uint32_t ConfigId() const { return r_config_id_; }
  bool third_plugin_enable() const { return third_plugin_enable_; }
  uint32_t GetThridCheck() const { return third_check_; }
  const std::string& GetVAppid() const { return video_appid_; }
  const std::string& GetUAppid() const { return union_appid_; }
  const std::string& GetUAppkey() const { return union_appkey_; }
  uint32_t GetFormalFlag() const { return formal_flag_; }
  uint64_t GetExpireMs() const { return expire_ms_; }

  // 默认配置相关
  bool IsDefault(std::shared_ptr<const WuJiConfig> wuji) { return wuji == default_wuji_; }

  // 杒件酝置相关酝置加载坊工具api
  int PluginUpdateConfig();
  const PluginConfig* PluginGetConfig(const std::string& key) const;
  int PluginMode(const PluginConfig* conf);
  bool PluginFindInBlacklist(const PluginConfig* conf, const int32_t id) const;
  bool PluginFindInWhitelist(const PluginConfig* conf, const int32_t id) const;
  int32_t PluginGetCustomPriority(const PluginConfig* conf, const int32_t id) const;

  const pcg_attr::AttrReport& GetAttrInstance() { return attr_report_; }
  int PrintConfig();

 private:
  vapi::CIPBlockAPI ipblock_api_;
  vapi_v6::CIPv6BlockAPI ipblockv6_api_;

  Area2Code area2code_;
  UnifiedConfigWujiMult config_wuji_mult_;
  pcg_attr::AttrReport attr_report_;

  std::unordered_map<int, std::unordered_map<std::string, std::shared_ptr<WuJiConfig> > > wuji_m_;
  // 朝务对应的业务杒件酝置 key:appid+callee+func
  std::unordered_map<std::string, PluginConfig> plugin_m_;
  uint64_t plugin_last_update_time_ = 0;

  std::string area_code_;
  std::shared_ptr<WuJiConfig> default_wuji_;
  uint32_t timeout_ = kTimeOut;
  std::unordered_map<uint32_t, uint64_t> config_last_update_time_;
  uint32_t r_config_id_ = 0;
  bool third_plugin_enable_ = true;
  uint32_t http_config_id_ = 0;
  std::string video_appid_;  // 视频应用 appid
  std::string union_appid_;  // union appid
  std::string union_appkey_;
  uint64_t expire_ms_ = 0;
  uint32_t plugin_config_id_ = 0;
  uint32_t third_check_ = 0;
  uint32_t formal_flag_ = 0;
};

typedef tars::TC_Singleton<Config> ConfigSingleton;
}  // namespace comm_access

#define INS_CONFIG comm_access::ConfigSingleton::getInstance()

#define INS_WJ const_cast<UnifiedConfigWujiMult*>(&INS_CONFIG->GetWujiInstance())

#define INS_ATTR const_cast<pcg_attr::AttrReport*>(&INS_CONFIG->GetAttrInstance())
