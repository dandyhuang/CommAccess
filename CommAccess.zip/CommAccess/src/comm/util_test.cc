// Copyright 2020 Tencent authors.
#include <iostream>
#include <vector>

#include "config.h"
#include "gmock/gmock.h"
#include "gtest/gtest.h"

void TEST_GetBackfix(std::string env, std::string protocol, std::string protocol_with_backfix) {
  int ret = putenv(const_cast<char*>(env.c_str()));
  ASSERT_EQ(ret, 0);
  EXPECT_EQ(comm_access::GetBackfix(protocol), protocol_with_backfix);
}

TEST(GetBackfix, GetBackfix_test_Test) { TEST_GetBackfix("DOCKER_ENV=test", "xx", "xx_147"); }
TEST(GetBackfix, GetBackfix_prev_Test) { TEST_GetBackfix("DOCKER_ENV=prev", "xx", "xx_213"); }
TEST(GetBackfix, GetBackfix_normal_Test) { TEST_GetBackfix("DOCKER_ENV=normal", "xx", "xx"); }
