/*
 *
 * Copyright 2020 Tencent authors.
 *
 * taskdec.cpp
 *
 */

#include "taskdec.h"

#include <arpa/inet.h>
#include <string.h>

// changelog
// 20181008 1.0
// 20190408 1.1  , add struin

namespace task_dec {
const unsigned int DELTA = 0x9e3779b9;

// BKDR Hash
unsigned int BKDRHash_mywan(const unsigned char *str, unsigned int uLen) {
  unsigned int seed = 131;  // 31 131 1313 13131 131313 etc..
  unsigned int hash = 0;

  for (unsigned int i = 0; i < uLen; i++) {
    hash = hash * seed + (*str++);
  }

  return (hash & 0x7FFFFFFF);
}

static void TeaEncryptECB(const char *pInBuf, const char *pKey, char *pOutBuf) {
  unsigned int y, z;
  unsigned int sum;
  unsigned int k[4];
  int i;
  /*plain-text is TCP/IP-endian;*/
  /*GetBlockBigEndian(in, y, z);*/
  y = ntohl(*((unsigned int *)pInBuf));
  z = ntohl(*((unsigned int *)(pInBuf + 4)));
  /*TCP/IP network byte order (which is big-endian).*/
  for (i = 0; i < 4; i++) {
    /*now key is TCP/IP-endian;*/
    k[i] = ntohl(*((unsigned int *)(pKey + i * 4)));
  }
  sum = 0;
  for (i = 0; i < 16; i++) {
    sum += DELTA;
    y += ((z << 4) + k[0]) ^ (z + sum) ^ ((z >> 5) + k[1]);
    z += ((y << 4) + k[2]) ^ (y + sum) ^ ((y >> 5) + k[3]);
  }
  *((unsigned int *)pOutBuf) = htonl(y);
  *((unsigned int *)(pOutBuf + 4)) = htonl(z);
  /*now encrypted buf is TCP/IP-endian;*/
}

static void TeaDecryptECB(const char *pInBuf, const char *pKey, char *pOutBuf) {
  unsigned int y, z, sum;
  unsigned int k[4];
  int i;
  /*now encrypted buf is TCP/IP-endian;*/
  /*TCP/IP network byte order (which is big-endian).*/
  y = ntohl(*((unsigned int *)pInBuf));
  z = ntohl(*((unsigned int *)(pInBuf + 4)));
  for (i = 0; i < 4; i++) {
    /*key is TCP/IP-endian;*/
    k[i] = ntohl(*((unsigned int *)(pKey + i * 4)));
  }
  sum = DELTA << 4;
  for (i = 0; i < 16; i++) {
    z -= ((y << 4) + k[2]) ^ (y + sum) ^ ((y >> 5) + k[3]);
    y -= ((z << 4) + k[0]) ^ (z + sum) ^ ((z >> 5) + k[1]);
    sum -= DELTA;
  }
  *((unsigned int *)pOutBuf) = htonl(y);
  *((unsigned int *)(pOutBuf + 4)) = htonl(z);
  /*now plain-text is TCP/IP-endian;*/
}

static char oi_symmetry_decrypt2(const char *pInBuf, int nInBufLen, const char *pKey, char *pOutBuf,
                                 int *pOutBufLen) {
  int nPadLen, nPlainLen;
  char dest_buf[8], zero_buf[8];
  const char *iv_pre_crypt, *iv_cur_crypt;
  int dest_i, i, j;
  // if (nInBufLen%8) return 0; BUG!
  if ((nInBufLen % 8) || (nInBufLen < 16)) return 0;
  TeaDecryptECB(pInBuf, pKey, dest_buf);
  nPadLen = dest_buf[0] & 0x7;

  i = nInBufLen - 1 /*PadLen(1byte)*/ - nPadLen - 2 - 7;
  if (*pOutBufLen < i) return 0;
  *pOutBufLen = i;
  if (*pOutBufLen < 0) return 0;
  for (i = 0; i < 8; i++) zero_buf[i] = 0;
  iv_pre_crypt = zero_buf;
  iv_cur_crypt = pInBuf; /*init iv*/
  nInBufLen -= 8;
  pInBuf += 8;
  dest_i = 1;
  dest_i += nPadLen;
  for (i = 1; i <= 2;) {
    if (dest_i < 8) {
      dest_i++;
      i++;
    } else if (dest_i == 8) {
      iv_pre_crypt = iv_cur_crypt;
      iv_cur_crypt = pInBuf;
      for (j = 0; j < 8; j++) dest_buf[j] ^= pInBuf[j];
      /*dest_i==8*/
      TeaDecryptECB(dest_buf, pKey, dest_buf);
      nInBufLen -= 8;
      pInBuf += 8;
      dest_i = 0;
    }
  }
  nPlainLen = *pOutBufLen;
  while (nPlainLen) {
    if (dest_i < 8) {
      *(pOutBuf++) = dest_buf[dest_i] ^ iv_pre_crypt[dest_i];
      dest_i++;
      nPlainLen--;
    } else if (dest_i == 8) {
      iv_pre_crypt = iv_cur_crypt;
      iv_cur_crypt = pInBuf;
      for (j = 0; j < 8; j++) dest_buf[j] ^= pInBuf[j];
      TeaDecryptECB(dest_buf, pKey, dest_buf);
      nInBufLen -= 8;
      pInBuf += 8;
      dest_i = 0;
    }
  }

  for (i = 1; i <= 7;) {
    if (dest_i < 8) {
      if (dest_buf[dest_i] ^ iv_pre_crypt[dest_i]) return 0;
      dest_i++;
      i++;
    } else if (dest_i == 8) {
      iv_pre_crypt = iv_cur_crypt;
      iv_cur_crypt = pInBuf;
      for (j = 0; j < 8; j++) dest_buf[j] ^= pInBuf[j];
      TeaDecryptECB(dest_buf, pKey, dest_buf);
      nInBufLen -= 8;
      pInBuf += 8;
      dest_i = 0;
    }
  }
  return 1;
}

bool GetStrFromBuf_net(string strData, string &strOutData, unsigned int &unCurLen,
                       unsigned int unNeLen) {
  if (unCurLen >= strData.length()) {
    return false;
  }
  unsigned int unLen = strData.length();
  unsigned short neDataLen = ntohs(*(unsigned short *)(strData.c_str() + unCurLen));  // NOLINT
  unCurLen += 0x02;
  if (unLen < (unCurLen + neDataLen + unNeLen)) {
    return false;
  }
  strOutData = strData.substr(unCurLen, neDataLen);
  unCurLen += neDataLen;
  return true;
}

bool GetIntFromBuf_net(string strData, unsigned int &outInt, unsigned int &unCurLen) {
  unsigned int uLen = strData.length();
  if (uLen < (unCurLen + 4)) {
    return false;
  }
  outInt = ntohl(*(unsigned int *)(strData.c_str() + unCurLen));
  unCurLen += 0x04;
  return true;
}

uint64_t htonll(uint64_t v) {
  union {
    uint32_t lv[2];
    uint64_t llv;
  } u;
  u.lv[0] = htonl(v >> 32);
  u.lv[1] = htonl(v & 0xFFFFFFFFULL);
  return u.llv;
}

uint64_t ntohll(uint64_t v) {
  union {
    uint32_t lv[2];
    uint64_t llv;
  } u;
  u.llv = v;
  return ((uint64_t)ntohl(u.lv[0]) << 32) | (uint64_t)ntohl(u.lv[1]);
}

int task_decrypt(string strTask, int platform, stTask &st_task) {
  if ((strTask.size() < 3) || (strTask.size() >= 512) || (strTask.size() % 2 != 0)) {
    return -1;
  }

  char chdata[512] = {0};
  char chdata_out[512] = {0};

  int outLen = 0;
  int datasize = strTask.size();
  char one_byte[3];
  char *pStop = NULL;

  for (int i = 0; (i < datasize - 1) && (i < datasize / 2); i++) {
    memcpy(one_byte, (char *)strTask.c_str() + i * 2, 2);  // NOLINT
    one_byte[2] = '\0';
    chdata[i] = strtol(one_byte, &pStop, 16);
  }
  outLen = datasize / 2;

  if ((4 - (outLen % 4)) < 4) {
    outLen += 4 - (outLen % 4);
  }

  if (outLen < 0x10) {
    return -2;
  }

  string strKey;
  if (0 == platform) {
    // Androidmagic2018taskkey
    strKey = "\x3E\x5C\xA4\x58\x38\x56\x4D\x7E\x39\x94\xC0\x4A\x0F\xE0\x26\x20";
  } else if (1 == platform) {
    // iOSmagic2018taskkey
    strKey = "\xB0\xC2\xFB\xBD\xB9\x6D\x73\xCE\x63\x85\xD8\x21\xCA\xF7\xB2\x59";
  } else {
    return -3;
  }
  string strData;
  strData.assign(chdata, outLen - 4);
  unsigned int unCurHash = *(unsigned int *)(chdata + outLen - 4);
  int outlen_1 = 512;
  int decret = oi_symmetry_decrypt2(strData.c_str(), strData.length(), strKey.c_str(), chdata_out,
                                    &outlen_1);
  if (decret <= 0) {
    return -4;
  }
  unsigned int unPlainHash = BKDRHash_mywan((unsigned char *)chdata_out, outlen_1);
  if ((unCurHash != unPlainHash) && (unCurHash != ntohl(unPlainHash))) {
    return -5;
  }
  string strPlain;
  // printf("%d\n", outlen_1);
  strPlain.assign(chdata_out, outlen_1);
  unsigned int curLen = 2;
  string strUin;
  GetStrFromBuf_net(strPlain, st_task.seqid, curLen, 0x02);
  GetStrFromBuf_net(strPlain, st_task.vid, curLen, 0x02);
  GetStrFromBuf_net(strPlain, st_task.guid, curLen, 0x02);
  GetStrFromBuf_net(strPlain, st_task.omgid, curLen, 0x02);
  GetStrFromBuf_net(strPlain, strUin, curLen, 0x02);
  uint64_t ulluin = ntohll(*(uint64_t *)(strUin.c_str()));  // NOLINT
  st_task.uin = ulluin;
  GetIntFromBuf_net(strPlain, st_task.timestamp, curLen);
  GetIntFromBuf_net(strPlain, st_task.rand, curLen);
  GetIntFromBuf_net(strPlain, st_task.type, curLen);
  GetIntFromBuf_net(strPlain, st_task.systemtype, curLen);
  GetIntFromBuf_net(strPlain, st_task.taskid, curLen);
  GetStrFromBuf_net(strPlain, st_task.struin, curLen, 0x00);

  return 0;
}

void AddStr2buf(char *chdata, char *strData, unsigned int inlen, unsigned int &curLen) {
  if ((curLen + 0x02 + inlen) >= 5000) {
    return;
  }
  *(unsigned short *)(chdata + curLen) = htons(inlen);  // NOLINT
  curLen += 0x02;
  memcpy(chdata + curLen, strData, inlen);
  curLen += inlen;
}

void AddStr2buf_str(char *chdata, string strData, unsigned int &curLen) {
  unsigned int inlen = strData.length();
  if ((curLen + 0x02 + inlen) >= 5000) {
    return;
  }
  *(unsigned short *)(chdata + curLen) = htons(inlen);  // NOLINT
  curLen += 0x02;
  memcpy(chdata + curLen, strData.c_str(), inlen);
  curLen += inlen;
}

void AddInt2Buf(char *chdata, unsigned int indata, unsigned int &curLen) {
  if ((curLen + 0x04) >= 5000) {
    return;
  }
  *(unsigned int *)(chdata + curLen) = htonl(indata);
  curLen += 4;
}

}  // namespace task_dec
