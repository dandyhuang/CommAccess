/*
 *
 * Copyright 2019 Tencent authors.
 *
 * util
 *
 */

#pragma once

#include <rapidjson/document.h>
#include <rapidjson/rapidjson.h>
#include <rapidjson/reader.h>
#include <rapidjson/stringbuffer.h>
#include <rapidjson/writer.h>
#include <stdlib.h>

#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

#include "spp_rpc/common/config_manager.h"
#include "spp_rpc/common/logger/logger_interface.h"
#include "src/comm/config.h"
#include "src/comm/docker_env.h"

namespace comm_access {

enum RouteType {
  ROUTE_ZKNAME = 0,
  ROUTE_L5 = 1,
  ROUTE_POLIARIS = 2,
};

const char kCommAccessName[] = "trpc.CommAccess.TestCase.sayhello";

struct RouteInfo {
  RouteInfo() : type(ROUTE_ZKNAME) {}
  std::string name;
  std::string service_name;
  std::string service_namespace;
  std::unordered_map<std::string, std::string> metadata;
  uint32_t mod_id = 0;
  uint32_t cmd_id = 0;
  uint32_t type = 0;
  uint32_t time_out = 0;
};
inline int SplitString(const string &content, const string &deil,
                       std::vector<std::string> *v_content);
inline std::string GetBackfix(std::string protocol = "") {
  static std::string backfix = "";
  if (backfix.empty()) {
    const std::string &dockerenv = INS_DOCKER_ENV->docker_env();
    if (dockerenv == kEnvTest) backfix = "_147";
    if (dockerenv == kEnvPre) backfix = "_213";
  }
  return protocol + backfix;
}

template <typename Ptr>
inline void GetRoute(const WuJiConfig &config, RouteInfo *r_info, std::string name, Ptr proxy) {
  if (r_info == nullptr) return;
  switch (config.route_flag) {
    case ROUTE_POLIARIS:
      r_info->service_name = config.service_name.empty() ? name : config.service_name;
      if (config.service_namespace.size()) {
        r_info->service_namespace = config.service_namespace;
      }
      r_info->type = ROUTE_POLIARIS;
      if (config.meta_data.size() > 0) {
        // r_info->metadata.insert(config.meta_data.begin(), config.meta_data.end());
        r_info->metadata = config.meta_data;
      }

      // static bool status = !INS_DOCKER_ENV->docker_formal() || INS_CONFIG->GetFormalFlag();
      // if (SPP_RPC_UNLIKELY(status)) {
      //   static const std::string dockerenv = INS_DOCKER_ENV->docker_env();
      //   r_info->metadata.insert(std::make_pair("env", dockerenv));
      //   // TODO(dandyhuang): 后续换成接入层123的服务
      //   static std::string name = kCommAccessName;
      //   static std::string name_space = INS_DOCKER_ENV->namepsace();
      //   proxy->mutable_route_point()->SetPolarisSourceKey(&name, &name_space);
      // }
      break;
    case ROUTE_ZKNAME:
      r_info->type = ROUTE_ZKNAME;
      r_info->name = config.service_name.empty() ? name : config.service_name;
      break;
    case ROUTE_L5:
      r_info->mod_id = config.mod_id;
      r_info->cmd_id = config.cmd_id;
      r_info->type = ROUTE_L5;
      break;
    default:
      r_info->type = ROUTE_ZKNAME;
      r_info->name = name;
      break;
  }
  // 都走无极的配置
  r_info->time_out = config.timeout;
}

template <typename Ptr>
void RouteZkInfo(const Ptr &ptr, const std::string &name, std::string protocol = "") {
  static const std::string backfix = GetBackfix(protocol);
  RPC_TLOG("name:%s, fix:%s", name.c_str(), backfix.c_str());
  if (backfix.empty()) {
    ptr->mutable_route_point()->SetZkname(name);
  } else {
    ptr->mutable_route_point()->SetZkname(name + backfix);
  }
}

template <typename Ptr>
inline void SetRoute(const Ptr &ptr, const RouteInfo &info, std::string protocol = "") {
  switch (info.type) {
    case ROUTE_ZKNAME:
      RouteZkInfo(ptr, info.name, protocol);
      break;
    case ROUTE_L5:
      ptr->mutable_route_point()->SetL5(info.mod_id, info.cmd_id);
      break;
    case ROUTE_POLIARIS:
      ptr->mutable_route_point()->SetPolaris(&info.service_name, &info.service_namespace);
      if (info.metadata.size() > 0) {
        ptr->mutable_route_point()->SetPolarisMetadata(info.metadata);
      }
      break;
    default:
      RouteZkInfo(ptr, info.name);
      break;
  }
  // 没有设置，或者走的默认的无极配置时走该逻辑
  if (info.time_out == 0 || info.time_out == kTimeOut) {
    ptr->mutable_route_point()->SetTimeout(INS_CONFIG->timeout());
  } else {
    ptr->mutable_route_point()->SetTimeout(info.time_out);
  }
}

inline bool IsRefererValid(const string &referer, const string &valid_domain) {
  if (referer.empty() || valid_domain.empty()) return false;

  std::string referers = referer;
  size_t end = referers.find("?");
  if (end != string::npos) {
    referers = referers.substr(0, end);
  }

  size_t left_pos = referers.find("http://");
  if (left_pos == string::npos) {
    left_pos = referers.find("https://");
    if (left_pos == string::npos) {
      left_pos = 0;
    } else {
      unsigned int size = sizeof("https://");
      left_pos += size - 1;
    }
  } else {
    size_t size = sizeof("http://");
    left_pos += size - 1;
  }

  size_t right_pos = referers.find("/", left_pos);
  std::string domain = referers.substr(left_pos, right_pos - left_pos);
  RPC_TLOG("domain:%s", domain.c_str());
  std::vector<std::string> valid_domains;
  SplitString(valid_domain, ";", &valid_domains);
  for (size_t i = 0; i < valid_domains.size(); i++) {
    size_t domain_pos = domain.find(valid_domains[i]);
    if (domain_pos != string::npos && domain_pos + valid_domains[i].length() == domain.length()) {
      if (domain_pos == 0) {
        return true;
      } else if (domain[domain_pos - 1] == '.') {
        return true;
      } else {
        continue;
      }
    }
  }

  return false;
}

inline int SplitString(const string &content, const string &deil,
                       std::vector<std::string> *v_content) {
  if (content.length() == 0) return -1;

  string strImgUrl;
  string::size_type index = 0;

  string::size_type pos = content.find(deil, index);

  while (pos != string::npos) {
    strImgUrl = content.substr(index, pos - index);
    v_content->push_back(strImgUrl);

    index = pos + 1;
    pos = content.find(deil, index);
  }

  if (index < content.length()) {
    strImgUrl = content.substr(index);
    v_content->push_back(strImgUrl);
  }

  return 0;
}

inline int HexToMem(const char *pMem, size_t uDumpOffset, size_t uDumpLen, unsigned char aMemOut[],
                    int *pwMemLen) {
  size_t i;
  char sTmp[10] = {0};
  const char *pSrc = pMem + uDumpOffset;

  int j = 0;
  sTmp[2] = '\0';
  size_t iTmpLength = uDumpLen;

  if (pwMemLen == NULL) {
    return -1;
  }

  if (uDumpLen % 2 != 0) {
    uDumpLen = uDumpLen - 1;
  }

  for (i = uDumpOffset; i < uDumpOffset + uDumpLen;) {
    sTmp[0] = *pSrc;
    pSrc++;
    sTmp[1] = *pSrc;
    pSrc++;
    i += 2;
    aMemOut[j++] = static_cast<char>(strtoul(sTmp, NULL, 16));
  }
  if (iTmpLength > uDumpLen) {
    sTmp[1] = '\0';
    sTmp[0] = *pSrc;
    int iTmp = 0;
    iTmp = static_cast<char>(strtoul(sTmp, NULL, 16));
    aMemOut[j++] = iTmp << 4;
  }

  *pwMemLen = j;
  return 0;
}

// 获取插件启用状态，默认是启用，如果想禁用则插件名称配成0
inline bool GetPluginStatus(const string &name) {
  std::string enable_str = spp_rpc::GetConfParams(name);
  if (enable_str.empty()) return true;
  return strtoul(enable_str.c_str(), NULL, 10);
}

}  // namespace comm_access
