// Copyright 2020 Tencent authors.
#include "config.h"

#include <iostream>
#include <vector>

#include "gmock/gmock.h"
#include "gtest/gtest.h"

TEST(CONFIG, GetWujiConfig_Test) {
  auto config = INS_CONFIG->GetWujiConfig("xx", 0);
  ASSERT_NE(config, nullptr);
  EXPECT_TRUE(INS_CONFIG->IsDefault(config));
}

TEST(CONFIG, IsDefault_Test) {
  auto config = INS_CONFIG->GetWujiConfig("", 0);
  EXPECT_TRUE(INS_CONFIG->IsDefault(config));
}