/*
 *
 * Copyright 2019 Tencent authors.
 *
 * tools.h
 *
 */

#pragma once
#include <string>
#include <vector>

#include "ipblock_api/include/Area2Code.h"
#include "ipblock_api/include/ipblock_api.h"
#include "ipblock_api/include/ipblock_api_v6.h"
#include "qmf_protocal_inter.h"  // NOLINT
#include "src/attr_report.h"
#include "util/tc_singleton.h"

namespace comm_access {
class Tools {
 public:
  Tools() = default;
  ~Tools() = default;

  int Init();
  int PrintPbBody(const std::vector<char>* buf);
  void SplitStr(const std::string& str, const std::string& sign, std::vector<std::string>* results);
  int CheckIP(const std::string& ip);
  std::string GetAreaCode(const uint64_t& ipv4, const QMF_PROTOCAL::QmfHead& qmf_head);
  std::string AreaGbk2Utf8(const vapi::IPBlockNode& node);

  const pcg_attr::AttrReport& GetAttrInstance() { return attr_report_; }
  uint32_t formal_flag() const { return formal_flag_; }
  uint32_t refactor_version() const { return refactor_version_; }

 private:
  std::string area_code_;
  vapi::CIPBlockAPI ipblock_api_;
  vapi_v6::CIPv6BlockAPI ipblockv6_api_;

  Area2Code area2code_;
  pcg_attr::AttrReport attr_report_;
  uint32_t formal_flag_ = 0;
  uint32_t refactor_version_ = 0;
};

typedef tars::TC_Singleton<Tools> ToolsSingleton;
}  // namespace comm_access

#define INS_TOOLS comm_access::ToolsSingleton::getInstance()
#define INS_TOOLS_ATTR const_cast<pcg_attr::AttrReport*>(&INS_TOOLS->GetAttrInstance())
