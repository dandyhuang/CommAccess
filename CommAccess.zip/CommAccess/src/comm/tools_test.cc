// Copyright 2020 Tencent authors.
#include "src/comm/tools.h"

#include <iostream>
#include <vector>

#include "gmock/gmock.h"
#include "gtest/gtest.h"
#include "src/codec/qmf_protocol.h"

TEST(TOOLS, TOOLS_Test_CASE0) {
  comm_access::Tools tool;
  comm_access::qmf_protocol::QmfHelper helper;
  helper.Init();
  helper.mutable_qmf_head()->Flag = 0x20213;
  // 112.97.52.14
  helper.mutable_qmf_acc_head()->ClientIP = 238313840;

  EXPECT_EQ(INS_TOOLS->CheckIP("1.3.4.6"), 4);
  EXPECT_EQ(INS_TOOLS->CheckIP("4sfds:4dfa:uyu:sjk:1:2:1:23"), 6);
  EXPECT_EQ(INS_TOOLS->CheckIP("4dfa.uyu.sjk.1.23"), 0);

  auto area_code = INS_TOOLS->GetAreaCode(helper.qmf_acc_head().ClientIP, helper.qmf_head());
  EXPECT_NE(area_code, "");
}
