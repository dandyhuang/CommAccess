/*
 *
 * Copyright 2020 Tencent authors.
 *
 * taskdec.h
 *
 */

#ifndef _task_dec_H_
#define _task_dec_H_

// changelog
// 20181008 1.0
// 20190408 1.1  , add struin

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include <string>

using namespace std;  // NOLINT

namespace task_dec {

/*
 1、用户信息
 guid(字符串) + omgid(字符串) + type(登录类型)(uint32) + uin(用户帐号)(uint64)
 2、任务信息
 systemtype(体系类型)(uint32) + taskid(任务ID)(uint32) + seqid(任务唯一seq) (字符串)
 3、时间信息
 timestamp(时间戳)(uint32)
 3、其他额外信息
 vid(若有观看视频信息，无则空)(字符串) + rand(随机数)(uint32)
 */
typedef struct _stTask {
  unsigned int timestamp;
  unsigned int rand;
  string seqid;
  string vid;
  string omgid;
  string guid;
  uint64_t uin;
  unsigned int taskid;
  unsigned int type;
  unsigned int systemtype;
  // by mingyuewan 20190408
  string struin;

  _stTask()
      : timestamp(0),
        rand(0),
        seqid(""),
        vid(""),
        omgid(""),
        guid(""),
        uin(0),
        taskid(0),
        type(0),
        systemtype(0),
        struin("") {}
} stTask;

// platform 0--Android, 1--iOS
int task_decrypt(string strTask, int platform, stTask &st_task);
}  // namespace task_dec

#endif
