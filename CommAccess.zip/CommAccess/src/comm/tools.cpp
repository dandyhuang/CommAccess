/*
 *
 * Copyright 2020 Tencent authors.
 *
 * tools
 *
 */

#include "src/comm/tools.h"

#include "google/protobuf/descriptor.h"
#include "google/protobuf/descriptor.pb.h"
#include "google/protobuf/dynamic_message.h"
#include "google/protobuf/io/zero_copy_stream_impl.h"
#include "google/protobuf/text_format.h"
#include "include/tconv_g2u.h"
#include "spp_rpc/spp_rpc.h"

namespace comm_access {

using google::protobuf::Descriptor;
using google::protobuf::DescriptorPool;
using google::protobuf::DynamicMessageFactory;
using google::protobuf::FileDescriptorProto;
using google::protobuf::Message;
using google::protobuf::TextFormat;
int Tools::Init() {
  formal_flag_ = std::atoi(spp_rpc::GetConfParams("formal_flag").c_str());
  refactor_version_ = std::atoi(spp_rpc::GetConfParams("refactor_version").c_str());
  if (refactor_version_) return 0;

  area2code_.Init();
  RPC_LOG_RET(ipblock_api_.Init(0x05930355, 0x05930455, 0x06930355, 0x06930455, 0x07930355),
              "init ipv4 err:%s", ipblock_api_.Error());  // NOLINT
  RPC_LOG_RET(ipblockv6_api_.Init(0x15930355, 0x15930455, 0x16930355, 0x16930455, 0x17930355),
              "init ipv6 err:%s", ipblockv6_api_.Error());  // NOLINT

  int ret = attr_report_.Init();
  RPC_LOG_RET(ret, "atta report init error:%d ", ret);

  return 0;
}

int Tools::PrintPbBody(const std::vector<char>* buf) {
  char* env = getenv("DOCKER_ENV");
  if (env) {
    std::string str = env;
    if (str != "test") return 0;
  }

  DescriptorPool pool;
  FileDescriptorProto file;
  file.set_name("empty_message.proto");
  file.add_message_type()->set_name("EmptyMessage");
  if (!pool.BuildFile(file)) {
    RPC_ELOG("BuildFile failed");
    return 1;
  }

  const Descriptor* type = pool.FindMessageTypeByName("EmptyMessage");
  if (type == NULL) {
    RPC_ELOG("BuildFile failed");
    return 1;
  }

  DynamicMessageFactory dynamic_factory(&pool);
  std::unique_ptr<Message> message(dynamic_factory.GetPrototype(type)->New());  // NOLINT

  if (!message->ParseFromArray(buf->data(), buf->size())) {
    RPC_ELOG("Failed to parse input.");
    return 1;
  }
  string msgDebug = message->DebugString();
  RPC_DLOG("msgDebug: %s buf", msgDebug.c_str());

  return 0;
}

void Tools::SplitStr(const std::string& str, const std::string& sign,
                     std::vector<std::string>* results) {
  std::string::size_type pos;
  size_t size = str.size();
  for (size_t i = 0; i < size; ++i) {
    // 从第i个位置查找sign分割符第一次出现的位置，没有找到则返回npos;
    pos = str.find(sign, i);
    // 将剩余部分存入
    if (pos == str.npos) {
      std::string s = str.substr(i, size);
      results->push_back(s);
      break;
    }
    if (pos < size) {
      // 把从i开始，长度为pos-i的元素拷贝给s;
      std::string s = str.substr(i, pos - i);
      results->push_back(s);
      i = pos;
    }
  }
}

int Tools::CheckIP(const std::string& ip) {
  if (ip.empty()) {
    return 0;
  }
  std::vector<std::string> results;
  SplitStr(ip, ".", &results);
  if (results.size() == 4) {
    return 4;
  } else {
    results.clear();
    SplitStr(ip, ":", &results);
    if (results.size() == 8) {
      return 6;
    }
  }
  return 0;
}

std::string Tools::AreaGbk2Utf8(const vapi::IPBlockNode& node) {
  char first_utf8_key[1024] = {0};
  char second_utf8_key[1024] = {0};
  char third_utf8_key[1024] = {0};

  size_t first_len = sizeof(first_utf8_key);
  size_t second_len = sizeof(second_utf8_key);
  size_t third_len = sizeof(third_utf8_key);

  int ret = tconv_gbk2utf8(node.country, strlen(node.country), first_utf8_key,
                           &first_len);  // NOLINT
  if (ret != 0) {
    strncpy(first_utf8_key, node.country, strlen(node.country));
    // Attr_API(413298, 1);
  }

  ret = tconv_gbk2utf8(node.province, strlen(node.province), second_utf8_key,
                       &second_len);  // NOLINT
  if (ret != 0) {
    strncpy(second_utf8_key, node.province, strlen(node.province));
    // Attr_API(413298, 1);
  }

  ret = tconv_gbk2utf8(node.city, strlen(node.city), third_utf8_key,
                       &third_len);  // NOLINT
  if (ret != 0) {
    strncpy(third_utf8_key, node.city, strlen(node.city));
    // Attr_API(413298, 1);
  }

  area_code_ = area2code_.getCodeByArea(first_utf8_key, second_utf8_key,
                                        third_utf8_key);  // NOLINT
  RPC_DLOG("areacode:%s", area_code_.c_str());
  return area_code_;
}

std::string Tools::GetAreaCode(const uint64_t& ipv4, const QMF_PROTOCAL::QmfHead& qmf_head) {
  area_code_ = "";
  vapi::IPBlockNode node;
  uint128_t ipv6 = 0;
  uint8_t len = qmf_head.Resv[2];
  if (len == 16) {
    ipv6 = *(uint128_t*)(&qmf_head.Resv[3]);  // NOLINT
  }

  if (ipv6 != 0) {
    vapi_v6::IPv6BlockNode nodev6;
    char szIpv6[1024] = {0};
    inet_ntop(AF_INET6, reinterpret_cast<void*>(&ipv6), szIpv6, sizeof(szIpv6));
    RPC_DLOG("ipv6addr:%s", szIpv6);
    int ret = ipblockv6_api_.Find(szIpv6, &nodev6);
    if (ret == 0) {
      strncpy(node.country, nodev6.country, strlen(nodev6.country));
      strncpy(node.city, nodev6.city, strlen(nodev6.city));
      strncpy(node.province, nodev6.province, strlen(nodev6.province));
      strncpy(node.isp, nodev6.isp, strlen(nodev6.isp));
    }
  } else {
    RPC_DLOG("ipv4:%ld", ipv4);
    ipblock_api_.Find(ipv4, &node);
  }

  AreaGbk2Utf8(node);
  return area_code_;
}
}  // namespace comm_access
