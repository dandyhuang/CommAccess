/*
 *
 * Copyright 2020 Tencent authors.
 *
 * config
 *
 */

#include "src/comm/config.h"

#include <util/tc_common.h>

#include <map>
#include <utility>
#include <vector>

#include "include/tconv_g2u.h"
#include "spp_rpc/spp_rpc.h"
#include "src/comm/util.h"

namespace comm_access {

int Config::Init() {
  area2code_.Init();
  RPC_LOG_RET(ipblock_api_.Init(0x05930355, 0x05930455, 0x06930355, 0x06930455, 0x07930355),
              "init ipv4 err:%s", ipblock_api_.Error());  // NOLINT
  RPC_LOG_RET(ipblockv6_api_.Init(0x15930355, 0x15930455, 0x16930355, 0x16930455, 0x17930355),
              "init ipv6 err:%s", ipblockv6_api_.Error());  // NOLINT
  // 默认北极星 namespace
  // default_wuji_->service_namespace = INS_DOCKER_ENV->namepsace();

  // 无极配置
  r_config_id_ = atoi(spp_rpc::GetConfParams("route_config_id").c_str());
  http_config_id_ = atoi(spp_rpc::GetConfParams("http_config_id").c_str());
  video_appid_ = spp_rpc::GetConfParams("v_appid");
  union_appid_ = spp_rpc::GetConfParams("union_appid");
  union_appkey_ = spp_rpc::GetConfParams("union_appkey");
  formal_flag_ = std::atoi(spp_rpc::GetConfParams("formal_flag").c_str());
  expire_ms_ = std::atoi(spp_rpc::GetConfParams("expire_second").c_str()) * 1000;
  plugin_config_id_ = atoi(spp_rpc::GetConfParams("plugin_config_id").c_str());
  if (!plugin_config_id_) {
    plugin_config_id_ = 3789;
  }
  std::vector<uint64_t> vec_config_id;
  vec_config_id.emplace_back(r_config_id_);
  vec_config_id.emplace_back(http_config_id_);
  vec_config_id.emplace_back(plugin_config_id_);
  config_last_update_time_.insert(make_pair(r_config_id_, 0));
  config_last_update_time_.insert(make_pair(http_config_id_, 0));
  auto ret = config_wuji_mult_.Init(&vec_config_id);
  RPC_LOG_RET(ret, "wuji init error|ret:%d", ret);
  UpdateWujiConfig(QMF_TYPE);
  UpdateWujiConfig(HTTP_TYPE);
  PrintConfig();

  ret = attr_report_.Init();
  RPC_LOG_RET(ret, "atta report init error:%d ", ret);

  third_check_ = atoi(spp_rpc::GetConfParams("third_check").c_str());

  std::string time_out = "time_out";
  if (INS_DOCKER_ENV->docker_env() == "test") time_out = "test_time_out";
  timeout_ = atoi(spp_rpc::GetConfParams(time_out).c_str());
  if (timeout_ == 0) {
    RPC_LOG_RET(-1, "get timeout err from:%s", time_out.c_str());
  }
  RPC_DLOG("time_out:%s, timeout_:%u", time_out.c_str(), timeout_);

  RPC_LOG_RET(ret, "wuji init error:%d env_:%s", ret, INS_DOCKER_ENV->docker_env().c_str());
  ret = attr_report_.Init();
  RPC_LOG_RET(ret, "atta report init error:%d ", ret);

  // 插件
  third_plugin_enable_ = spp_rpc::GetConfParams("third_plugin_enable") != "0";

  RPC_DLOG("trpc_plugin_enable:%d", third_plugin_enable_);
  return 0;
}

int Config::ParseMetaData(WuJiConfig* config, const std::string& metadata) {
  if (metadata.empty()) return 0;
  rapidjson::Document doc;
  if (doc.Parse(metadata.data()).HasParseError()) {
    RPC_TLOG("func:%s meta parse error", config->func.c_str());
    return -1;
  }
  // 防止NULL对象
  if (!doc.IsObject()) {
    doc.SetObject();
  }
  if (!doc.HasMember("metadata") || !doc["metadata"].IsArray()) {
    RPC_TLOG("func:%s has no meta member or array", config->func.c_str());
    return -1;
  }

  // const rapidjson::Value& array = doc["metadata"];
  // size_t len = array.Size();
  // for (size_t i = 0; i < len; i++) {
  //   const rapidjson::Value& object = array[i];
  //   if (object.IsObject()) {
  //     std::string key, value;
  //     if (object.HasMember("key") && object["key"].IsString()) {
  //       key = object["key"].GetString();
  //     }
  //     if (object.HasMember("value") && object["value"].IsString()) {
  //       value = object["value"].GetString();
  //     }
  //     if (!key.empty() && !value.empty()) {
  //       config->meta_data.insert(std::make_pair(key, value));
  //     } else {
  //       RPC_ELOG("func:%s meta key value set empty", config->func.c_str());
  //       return -1;
  //     }
  //   }
  // }
  return 0;
}

int Config::UpdateWujiConfig(int type) {
  uint32_t config_id = 0;
  if (type == QMF_TYPE) {
    config_id = r_config_id_;
  } else {
    config_id = http_config_id_;
  }

  uint64_t last_update_time = config_last_update_time_[config_id];

  uint64_t update_time = config_wuji_mult_.GetLastUpdateTimestamp();
  RPC_DLOG("now:%ld, last:%ld", update_time, last_update_time);
  if (update_time <= last_update_time) return 0;

  std::vector<std::string> keys;
  int ret = config_wuji_mult_.GetKeys(config_id, &keys);
  RPC_LOG_RET(ret, "wuji.GetKeys failed err:%s", config_wuji_mult_.GetErrorMsg().c_str());

  auto iter = wuji_m_.find(type);
  if (iter != wuji_m_.end()) {
    iter->second.clear();
  }
  // wuji_m_.clear();
  std::unordered_map<std::string, std::shared_ptr<WuJiConfig> > wuji;
  for (auto& k : keys) {
    std::vector<std::map<std::string, std::string> > vecValue;
    int ret = config_wuji_mult_.Get(config_id, k, &vecValue);
    if (ret == 0) {
      for (auto m : vecValue) {
        WuJiConfig* config = new WuJiConfig;
        string key;
        if (type == QMF_TYPE) {
          config->auth_flag = atoi(m["authFlag"].c_str());
          config->water_flag = atoi(m["water_flag"].c_str());
          config->video_flag = atoi(m["video_flag"].c_str());
          config->area_level = atoi(m["area_level"].c_str());
          config->dye_flag = atoi(m["dye_flag"].c_str());
          config->proto_type = atoi(m["prototype"].c_str());
          config->route_flag = atoi(m["route_flag"].c_str());
          config->user_flag = atoi(m["user_type"].c_str());
          config->service_namespace = m["service_namespace"];
          config->service_name = m["service_name"];
          std::string meta = m["metadata"];
          // 失败继续执行，不要影响其他配置
          int ret = ParseMetaData(config, meta);
          if (ret) ::spp_rpc::AttrApi(config->func + "meta", 1);
          config->mod_id = atol(m["modid"].c_str());
          config->cmd_id = atol(m["cmdid"].c_str());
          config->t_id = atol(m["tid"].c_str());
          config->appid = m["appid"];
          config->callee = m["callee"];
          config->timeout = atoi(m["timeout"].c_str());
          config->func = m["func"];
          key = config->GetWujiConfigKey();
          config->cache_type = static_cast<CacheMode>(atoi(m["cache_type"].c_str()));
          config->cache_mod_id = atoi(m["cache_mod_id"].c_str());
          config->cache_cmd_id = atoi(m["cache_cmd_id"].c_str());
          config->cache_write_mod_id = atoi(m["cache_write_mod_id"].c_str());
          config->cache_write_cmd_id = atoi(m["cache_write_cmd_id"].c_str());
          config->hosts = m["hosts"];
          config->referer = m["referer"];
          config->gtk_flag = atoi(m["gtk"].c_str());
          config->limit_flag = atoi(m["limit_flag"].c_str());
          config->close_retry = atoi(m["close_retry"].c_str());
        } else {
          config->appid = m["appid"];
          config->url = m["url"];
          config->proto_type = atoi(m["proto_type"].c_str());
          config->timeout = atoi(m["timeout"].c_str());
          key = config->appid + config->url;
          config->cache_type = static_cast<CacheMode>(atoi(m["cache_type"].c_str()));
          config->cache_mod_id = atoi(m["cache_mod_id"].c_str());
          config->cache_cmd_id = atoi(m["cache_cmd_id"].c_str());
          config->cache_write_mod_id = atoi(m["cache_write_mod_id"].c_str());
          config->cache_write_cmd_id = atoi(m["cache_write_cmd_id"].c_str());
        }
        wuji.insert(std::make_pair(key, std::shared_ptr<WuJiConfig>(config)));
      }
    }
  }
  // wuji_m_.insert(std::make_pair(type, wuji));
  wuji_m_[type] = wuji;
  config_last_update_time_[config_id] = update_time;
  return 0;
}

int Config::PrintConfig() {
  for (auto iter = wuji_m_.begin(); iter != wuji_m_.end(); iter++) {
    for (auto iter_data = iter->second.begin(); iter_data != iter->second.end(); iter_data++) {
      RPC_DLOG("key =  %s", iter_data->first.c_str());
    }
  }
  return 0;
}

std::shared_ptr<WuJiConfig> Config::GetWujiConfig(const std::string& key, int type) {
  std::shared_ptr<WuJiConfig> wuji_config_ptr = default_wuji_;
  const auto& t_iter = wuji_m_.find(type);
  if (t_iter != wuji_m_.end()) {
    const auto& wuji = t_iter->second;
    const auto& iter = wuji.find(key);
    if (iter != wuji.end()) {
      wuji_config_ptr = iter->second;
    }
  }

  RPC_DLOG(
      "key:%s,authflag:%u, water_flag:%u, video_flag:%u, area_level:%u, "
      "route_flag:%u, modid:%d, cmdid:%d, timeout:%d, url:%s, pro_type:%d, "
      "servicenamespace:%s, service_name:%s, user_flag:%d, cache_type:%d",
      key.c_str(), wuji_config_ptr->auth_flag, wuji_config_ptr->water_flag,
      wuji_config_ptr->video_flag, wuji_config_ptr->area_level, wuji_config_ptr->route_flag,
      wuji_config_ptr->mod_id, wuji_config_ptr->cmd_id, wuji_config_ptr->timeout,
      wuji_config_ptr->url.c_str(), wuji_config_ptr->proto_type,
      wuji_config_ptr->service_namespace.c_str(), wuji_config_ptr->service_name.c_str(),
      wuji_config_ptr->user_flag, wuji_config_ptr->cache_type);
  return wuji_config_ptr;
}

int Config::PluginUpdateConfig() {
  auto update_time = config_wuji_mult_.GetLastUpdateTimestamp(plugin_config_id_);
  RPC_DLOG("id:%u plugin_last_update_time:%lu get wuji update_time:%lu", plugin_config_id_,
           plugin_last_update_time_, update_time);
  if (update_time <= plugin_last_update_time_) {
    return 0;
  }

  std::vector<std::string> keys;
  int wuji_ret = config_wuji_mult_.GetKeys(plugin_config_id_, &keys);
  RPC_LOG_RET(wuji_ret, "config_wuji_mult_.GetKeys error|err:%s",
              config_wuji_mult_.GetErrorMsg().c_str());
  std::unordered_map<std::string, PluginConfig> new_plugin_conf;
  RPC_DLOG("wuji id:%u key.size:%lu", plugin_config_id_, keys.size());
  bool wuji_has_failed = false;
  for (auto& key : keys) {
    std::vector<std::map<std::string, std::string> > vecValue;
    int ret = config_wuji_mult_.Get(plugin_config_id_, key, &vecValue);
    if (ret == 0) {
      for (auto m : vecValue) {
        if (m["status"] == "0") {
          continue;
        }
        PluginConfig item;
        item.id = strtoul(m["id"].c_str(), NULL, 10);
        item.mode = strtoul(m["mode"].c_str(), NULL, 10);
        item.blacklist = tars::TC_Common::sepstr<uint32_t>(m["blacklist"], ",");
        item.whitelist = tars::TC_Common::sepstr<uint32_t>(m["whitelist"], ",");
        std::vector<std::string> prioritys =
            tars::TC_Common::sepstr<string>(m["custom_priority"], ",");
        for (auto& priority : prioritys) {
          std::vector<uint32_t> p = tars::TC_Common::sepstr<uint32_t>(priority, ":");
          if (p.size() == 2) {
            item.custom_priority.insert(std::make_pair(p[0], p[1]));
          }
        }
        auto item_key = m["appid"] + m["callee"] + m["func"];
        new_plugin_conf.insert(std::make_pair(item_key, item));
        RPC_DLOG(
            "get one plugin conf|key:%s|id:%u|blacklist.size:%lu|"
            "whitelist.size:%lu|prior.size:%lu",
            item_key.c_str(), item.id, item.blacklist.size(), item.whitelist.size(),
            item.custom_priority.size());
      }
    } else {
      wuji_has_failed = true;
      RPC_DLOG("wuji route Get this key failed. key:%s", key.c_str());
      break;
    }
  }
  if (wuji_has_failed) {
    return -1;
  }
  plugin_m_ = std::move(new_plugin_conf);  // 保险点先更新到临时变量再覆盖
  plugin_last_update_time_ = update_time;
  return 0;
}

const PluginConfig* Config::PluginGetConfig(const std::string& key) const {
  const auto& it = plugin_m_.find(key);
  if (it != plugin_m_.end()) {
    RPC_DLOG(
        "mode:%d|blacklist.size:%lu|whitelist.size:%lu"
        "|priority.size:%lu",
        it->second.mode, it->second.blacklist.size(), it->second.whitelist.size(),
        it->second.custom_priority.size());
    return &it->second;
  }
  RPC_DLOG("not find this key:%s plugin.size:%lu", key.c_str(), plugin_m_.size());
  return nullptr;
}

// 获取业务插件模式 黑白名单或未配置模式
int Config::PluginMode(const PluginConfig* conf) {
  if (!conf) {
    return kNotConfig;
  }
  return conf->mode;
}
bool Config::PluginFindInBlacklist(const PluginConfig* conf, const int32_t id) const {
  if (!conf) {
    return false;
  }
  return binary_search(conf->blacklist.begin(), conf->blacklist.end(), id);
}
bool Config::PluginFindInWhitelist(const PluginConfig* conf, const int32_t id) const {
  if (!conf) {
    return false;
  }
  return binary_search(conf->whitelist.begin(), conf->whitelist.end(), id);
}
int32_t Config::PluginGetCustomPriority(const PluginConfig* conf, const int32_t id) const {
  if (!conf) {
    return 0;
  }
  if (conf->custom_priority.empty()) {
    return 0;
  }
  const auto& it = conf->custom_priority.find(id);
  if (it != conf->custom_priority.end()) {
    return it->second;
  } else {
    return 0;
  }
}

void Config::SplitStr(const std::string& str, const std::string& sign,
                      std::vector<std::string>& results) {
  std::string::size_type pos;
  size_t size = str.size();
  for (size_t i = 0; i < size; ++i) {
    // 从第i个位置查找sign分割符第一次出现的位置，没有找到则返回npos;
    pos = str.find(sign, i);
    // 将剩余部分存入
    if (pos == str.npos) {
      std::string s = str.substr(i, size);
      results.push_back(s);
      break;
    }
    if (pos < size) {
      // 把从i开始，长度为pos-i的元素拷贝给s;
      std::string s = str.substr(i, pos - i);
      results.push_back(s);
      i = pos;
    }
  }
}

int Config::CheckIP(const std::string& ip) {
  if (ip.empty()) {
    return 0;
  }
  std::vector<std::string> results;
  SplitStr(ip, ".", results);
  if (results.size() == 4) {
    return 4;
  } else {
    results.clear();
    SplitStr(ip, ":", results);
    if (results.size() == 8) {
      return 6;
    }
  }
  return 0;
}

std::string Config::AreaGbk2Utf8(const vapi::IPBlockNode& node) {
  char sFirstUtf8Key[1024] = {0};
  char sSecondUtf8Key[1024] = {0};
  char sThirdUtf8Key[1024] = {0};

  size_t FirstLen = sizeof(sFirstUtf8Key);
  size_t SecondtLen = sizeof(sSecondUtf8Key);
  size_t ThirdLen = sizeof(sThirdUtf8Key);

  int ret = tconv_gbk2utf8(node.country, strlen(node.country), sFirstUtf8Key,
                           &FirstLen);  // NOLINT
  if (ret != 0) {
    strncpy(sFirstUtf8Key, node.country, strlen(node.country));
    // Attr_API(413298, 1);
  }

  ret = tconv_gbk2utf8(node.province, strlen(node.province), sSecondUtf8Key,
                       &SecondtLen);  // NOLINT
  if (ret != 0) {
    strncpy(sSecondUtf8Key, node.province, strlen(node.province));
    // Attr_API(413298, 1);
  }

  ret = tconv_gbk2utf8(node.city, strlen(node.city), sThirdUtf8Key,
                       &ThirdLen);  // NOLINT
  if (ret != 0) {
    strncpy(sThirdUtf8Key, node.city, strlen(node.city));
    // Attr_API(413298, 1);
  }

  area_code_ = area2code_.getCodeByArea(sFirstUtf8Key, sSecondUtf8Key,
                                        sThirdUtf8Key);  // NOLINT
  RPC_DLOG("areacode:%s", area_code_.c_str());
  return area_code_;
}

// std::string Config::GetAreaCode(const uint64_t& ipv4, const QMF_PROTOCAL::QmfHead& qmf_head) {
//   area_code_ = "";
//   vapi::IPBlockNode node;
//   uint128_t ipv6 = 0;
//   uint8_t len = qmf_head.Resv[2];
//   if (len == 16) {
//     ipv6 = *(uint128_t*)(&qmf_head.Resv[3]);  // NOLINT
//   }

//   if (ipv6 != 0) {
//     vapi_v6::IPv6BlockNode nodev6;
//     char szIpv6[1024] = {0};
//     inet_ntop(AF_INET6, reinterpret_cast<void*>(&ipv6), szIpv6, sizeof(szIpv6));
//     RPC_DLOG("ipv6addr:%s", szIpv6);
//     int ret = ipblockv6_api_.Find(szIpv6, &nodev6);
//     if (ret == 0) {
//       strncpy(node.country, nodev6.country, strlen(nodev6.country));
//       strncpy(node.city, nodev6.city, strlen(nodev6.city));
//       strncpy(node.province, nodev6.province, strlen(nodev6.province));
//       strncpy(node.isp, nodev6.isp, strlen(nodev6.isp));
//     }
//   } else {
//     RPC_DLOG("ipv4:%ld", ipv4);
//     ipblock_api_.Find(ipv4, &node);
//   }

//   AreaGbk2Utf8(node);
//   return area_code_;
// }

}  // namespace comm_access
