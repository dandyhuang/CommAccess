/*
 *
 * Copyright 2020 Tencent authors.
 *
 * docker_env
 *
 */

#pragma once

#include <map>
#include <string>
#include <unordered_map>

#include "spp_rpc/common/logger/logger_interface.h"
#include "util/tc_singleton.h"

namespace comm_access {

enum RetCode {
  RetOk = 0,
  RetGetEnvFail = 1,  // deocker_env 获取环境变量失败
};

// 环境变量名称
const char kEnvDockerEnv[] = "DOCKER_ENV";
const char kEnvSet[] = "SET";

// 环境
const char kEnvTest[] = "test";
const char kEnvPre[] = "pre";
const char kEnvNormal[] = "normal";
const char kNsDevelopment[] = "Development";
const char kNsPreRelease[] = "Development";
const char kNsProduction[] = "Production";

inline std::string EnvToNamespace(const std::string& dockerenv) {
  if (dockerenv == kEnvTest) return kNsDevelopment;
  if (dockerenv == kEnvPre) return kNsPreRelease;
  if (dockerenv == kEnvNormal) return kNsProduction;
  return kNsProduction;
}
class DockerEnv {
 public:
  DockerEnv() { init_ret_ = Init(); }

  int Init() {
    if (is_init_) {
      return init_ret_;
    }
    is_init_ = true;
    char* env = getenv(reinterpret_cast<const char*>(kEnvDockerEnv));
    if (!env) {
      init_ret_ = RetGetEnvFail;
      RPC_LOG_RET(init_ret_, "getenv fail: %s is not exist", kEnvDockerEnv);
    }
    docker_env_ = env;
    namespace_ = EnvToNamespace(docker_env_);

    env = getenv(reinterpret_cast<const char*>(kEnvSet));
    if (!env) {
      RPC_ELOG("getenv fail: %s is not exist", kEnvSet);
    } else {
      docker_set_ = env;
    }
    init_ret_ = RetOk;
    if (docker_env_ == kEnvTest || docker_env_ == kEnvPre) {
      is_formal_ = false;
    } else {
      is_formal_ = true;
    }

    return init_ret_;
  }

  const std::string& docker_env() { return docker_env_; }
  // 北极星的 Namespace
  const std::string& namepsace() { return namespace_; }
  const std::string& docker_set() { return docker_set_; }
  const bool& docker_formal() { return is_formal_; }

 protected:
  std::string docker_set_;
  std::string docker_env_;
  std::string namespace_;

 private:
  bool is_init_ = false;
  bool is_formal_ = false;
  int init_ret_ = 0;
};

typedef tars::TC_Singleton<DockerEnv> DockerEnvSingleton;

}  // namespace comm_access
#define INS_DOCKER_ENV comm_access::DockerEnvSingleton::getInstance()