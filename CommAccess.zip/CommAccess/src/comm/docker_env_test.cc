// Copyright 2020 Tencent authors.
#include "docker_env.h"

#include <iostream>
#include <vector>

#include "gmock/gmock.h"
#include "gtest/gtest.h"

TEST(DOCKER_ENV, Production_Test) {
  std::vector<std::string> env_vars = {
      "DOCKER_ENV=test",
      "APP_NAME=CommAcc",
      "SET=comm_access.sz.http2trpc",
      "http_acc_port=10058",
      "trpc_port=10064",
      "main_port=10062",
      "wuji_port=10073",
      "trpc_acc_port=10063",
      "CONTAINER_NAME=normal.CommAcc.CommAccess.TSZ23",
      "HOME=/usr/local/app",
      "SERVER_NAME=CommAccess",
      "CRON_AGENT_PORT=10056",
      "http2trpc_port=10057",
  };

  int ret;
  for (auto var : env_vars) {
    ret = putenv(const_cast<char*>(var.c_str()));
    ASSERT_EQ(ret, 0);
  }
  comm_access::DockerEnv docker_env;
  ret = docker_env.Init();
  EXPECT_EQ(ret, 0);

  EXPECT_EQ(docker_env.docker_env(), "test");
  EXPECT_EQ(docker_env.docker_set(), "comm_access.sz.http2trpc");
  EXPECT_EQ(docker_env.namepsace(), "Development");
}
