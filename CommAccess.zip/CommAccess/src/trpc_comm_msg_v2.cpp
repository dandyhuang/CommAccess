/*
 *
 * Copyright 2019 Tencent authors.
 *
 * trpc msg.
 *
 */

#include "src/trpc_comm_msg_v2.h"

#include <string>
#include <vector>

#include "spp_rpc/client/binary_proxy.h"
#include "spp_rpc/client/trpc_servant_proxy.h"
#include "spp_rpc/codec/trpc/trpc_protocol.h"
#include "spp_rpc/spp_rpc.h"
#include "src/access_err.h"
#include "src/attr_report.h"
#include "src/comm/tools.h"
#include "src/config_frame/config_factory.h"
#include "token_api.h"

namespace comm_access {
using com::tencent::qqlive::protocol::pb::LoginToken;

using com::tencent::qqlive::protocol::pb::BackEndRequestHead;

spp_rpc::SppRpcBaseMsg* TpcCommMsgV2Creater() { return new (std::nothrow) TrpcCommMsgV2; }

void TrpcCommMsgV2::ParseLoginToken() {
  int token_size = GetVideoMutableReqHead()->login_token_size();
  std::string v_openid;
  bool has_qq_openid{false};
  uint64_t qq{0};
  std::vector<LoginToken> v_token_v2;
  for (int i = 0; i < token_size; ++i) {
    const auto& item_v2 = GetVideoMutableReqHead()->login_token(i);
    switch (item_v2.type()) {
      case 1:
      case 7:
        qq_ = item_v2.account();
        break;
      case 9:
        vuid_ = item_v2.account();
        v_openid = item_v2.token();
        if (GetQQFromToken(v_openid, qq)) {
          qq = 0;
        }
        qq_ = std::to_string(qq);
        break;
      case 10:
        qq_openid_ = item_v2.account();
        has_qq_openid = true;
        break;
      case 100:
        wechat_openid_ = item_v2.account();
        break;
    }
    v_token_v2.push_back(item_v2);
  }
  if (has_qq_openid) {
    if (!GetQQFromToken(v_openid, qq)) {
      SPAN_TLOG(context_->msg(), "v_openid:%s|qq_:%lu", v_openid.c_str(), qq);
      qq_ = std::to_string(qq);
      LoginToken token_v2;
      token_v2.set_app_id("350001");
      token_v2.set_type(1);
      token_v2.set_account(qq_);
      token_v2.set_token(v_openid);
      token_v2.set_is_main_login(false);
      v_token_v2.push_back(token_v2);
    }
  }
  GetVideoMutableReqHead()->clear_login_token();
  for (auto& v : v_token_v2) {
    LoginToken* token = GetVideoMutableReqHead()->add_login_token();
    *token = v;
  }
  RPC_TLOG("qq:%s vuid:%s qq_openid:%s wechat_openid:%s token.size:%d", qq_.c_str(), vuid_.c_str(),
           qq_openid_.c_str(), wechat_openid_.c_str(),
           GetVideoMutableReqHead()->login_token_size());
  EncodeQQlive();
}

void TrpcCommMsgV2::ResponseImp(int frame_code, int logic_code) {
  if (!rsp_buf_ || !rsp_size_) {
    spp_rpc::TrpcResponseProtocol rsp;
    static std::vector<char> rsp_buf;
    rsp.logic_header.set_ret(frame_code);
    rsp.logic_header.set_func_ret(logic_code);
    rsp.Encode(&rsp_buf);
    this->Response(rsp_buf.data(), rsp_buf.size());
    return;
  }

  RPC_TLOG("response|rsp:%p|rsp_size:%lu", rsp_buf_, rsp_size_);
  this->Response(rsp_buf_, rsp_size_);
  INS_CONFIG_MGR->UpdateConfig();
  AttaReport(frame_code, logic_code);
}

void TrpcCommMsgV2::AttaReport(int frame_code, int logic_code) {
  pcg_attr::STAttrReport report_v2;
  report_v2.callee = req_.logic_header.callee();
  report_v2.func = req_.logic_header.func();
  report_v2.appid = GetVideoMutableReqHead()->version_info().app_id();
  report_v2.version = GetVideoMutableReqHead()->version_info().version_name();
  auto pf = std::to_string(GetVideoMutableReqHead()->version_info().platform());
  report_v2.platform = pf;

  report_v2.active_ip = context_->GetLocalIp();
  report_v2.passive_ip = busi_remote_ip_;
  report_v2.calltype = "active";

  // Dimension
  report_v2.total = 1;
  if (rsp_.logic_header.func_ret() == 0) {
    report_v2.success = 1;
  } else {
    report_v2.failed = 1;
  }

  report_v2.cost = context_->msg()->GetMsgCost();
  report_v2.ret = rsp_.logic_header.ret();
  report_v2.func_ret = rsp_.logic_header.func_ret();

  RPC_TLOG("report_v2 callee:%s, func:%s ,cost:%d", report_v2.callee.c_str(),
           report_v2.func.c_str(), report_v2.cost);
  INS_TOOLS_ATTR->CustomItemAttr(report_v2);

  report_v2.active_ip = remote_ip_;
  report_v2.passive_ip = context_->GetLocalIp();
  report_v2.calltype = "passive";
  INS_TOOLS_ATTR->CustomItemAttr(report_v2);
}

void TrpcCommMsgV2::EncodeQQlive() {
  auto& qqlive_head = (*req_.logic_header.mutable_trans_info())["qqlive_head"];
  GetVideoMutableReqHead()->SerializeToString(&qqlive_head);
  auto& q_backend_head = (*req_.logic_header.mutable_trans_info())["qqlive_backend_head"];
  GetVideoMutableReqBackendHead()->SerializeToString(&q_backend_head);
  RPC_DLOG("req:%s", req_.logic_header.DebugString().c_str());
#if SPP_RPC_DEBUG
  std::vector<char> buf;
  buf.assign(qqlive_head.begin(), qqlive_head.end());
  INS_TOOLS->PrintPbBody(&buf);
  buf.clear();
  buf.assign(q_backend_head.begin(), q_backend_head.end());
  INS_TOOLS->PrintPbBody(&buf);
  // 业务具体参数
  INS_TOOLS->PrintPbBody(&(req().body));
#endif
}

}  // namespace comm_access
