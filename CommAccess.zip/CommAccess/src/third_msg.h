/*
 *
 * Copyright 2020 Tencent authors.
 *
 * third msg
 *
 */

#pragma once

#include <memory>
#include <string>

#include "spp_rpc/client/http_proxy.h"
#include "spp_rpc/msg/http_msg.h"
#include "src/comm/config.h"
#include "src/comm/util.h"

namespace comm_access {

class ThirdMsg : public spp_rpc::HttpMsg {
 public:
  ThirdMsg() { context_->set_msg(this); }
  ~ThirdMsg() = default;

 protected:
  int CheckParams() override;
  int ProcessServant() override;
  void ResponseImp(int frame_code, int logic_code) override;
  const std::string& GetTracerServantName() const override {
    static std::string name = "normal.CommAcc.CommAccess";
    return name;
  }
  int PackResponse(int frame_code, int logic_code);
  int Code2StatusCode(int errcode);

  void AttaReport(int frame_code, int logic_code);

 protected:
  std::shared_ptr<WuJiConfig> config_ = nullptr;
  RouteInfo r_info_;
  std::string busi_remote_ip_;
  spp_rpc::HttpRpcProxyPtr proxy_;
  tars::TC_HttpRequest busi_req_;
  tars::TC_HttpResponse busi_rsp_;
};

spp_rpc::SppRpcBaseMsg* ThirdMsgCreater();

}  // namespace comm_access
