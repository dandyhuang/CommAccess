//  Copyright 2020 Tencent authors.

#define private public
#define protected public

#include <map>

#include "gmock/gmock.h"
#include "gtest/gtest.h"
#include "src/config_frame/config_factory.h"

class ConfigParserTest : public comm_access::ConfigParser {
 public:
  comm_access::ConfigRecordPtr Parse(const std::map<std::string, std::string>& m) override {
    return nullptr;
  };
};

TEST(ConfigParser, Case1_ConfigParser_P0) {
  ConfigParserTest parser;
  EXPECT_FALSE(parser.Filter(nullptr));
  EXPECT_TRUE(parser.Filter(std::make_shared<comm_access::ConfigRecord>()));
}