/*
 * @Author: your name
 * @Date: 2020-06-08 12:11:39
 * @Copyright: 2020-06-10 11:53:13
 * @LastEditors: Please set LastEditors
 * @Description:
 * @FilePath:
 */

#include "src/config_frame/config_factory.h"

#include <arpa/inet.h>
#include <netdb.h>
#include <netinet/in.h>

#include <vector>

#include "spp_rpc/common/logger/logger_interface.h"
#include "tinyxml2.h"

namespace comm_access {

int ConfigApiManager::Init() {
  std::vector<uint64_t> vec_config_id;
  for (const auto& tp : register_config_map_) {
    if (tp.second) {
      ConfigUpdaterPtr ptr = ConfigUpdaterPtr(reinterpret_cast<ConfigUpdater*>(tp.second()));
      RPC_LOG_RET(ptr->Init(), "config id %d init", tp.first);
      vec_config_id.push_back(ptr->wuji_config_id());
      AddConfigUpdater(tp.first, ptr);
    } else {
      RPC_LOG_RET(-1, "register is null|config[%d]", tp.first);
    }
  }
  RPC_DLOG("regster_config_size:%zd", register_config_map_.size());

  for (auto i : vec_config_id) {
    RPC_DLOG("id:%ld", i);
  }
  RPC_LOG_RET(config_wuji_mult()->Init(&vec_config_id), "wuji init error:%s",
              config_wuji_mult()->GetErrorMsg().c_str());
  UpdateConfig();

  appid_ = spp_rpc::GetConfParams("v_appid");
  return 0;
}

int ConfigApiManager::UpdateConfig() {
  for (const auto& it : config_updaters()) {
    if (!it.second) {
      // TODO(oliverlli): 正常逻辑不应该走到这里来, 直接报错
      RPC_LOG_RET(-1, "register is null");
    }

    if (it.second->UpdateConfig(config_wuji_mult())) {
      spp_rpc::AttrApi("config:" + std::to_string(it.first), 1);
      RPC_ELOG("config update %d", it.first);
    }
  }
  return 0;
}

}  // namespace comm_access
