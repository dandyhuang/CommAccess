// Copyright 2019 Tencent authors.

#pragma once

#include <netinet/in.h>
#include <sys/ioctl.h>

#include <map>
#include <memory>
#include <set>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

#include "spp_rpc/spp_rpc.h"
#include "unified_config_wuji.h"
#include "util/tc_autoptr.h"
#include "util/tc_common.h"
#include "util/tc_singleton.h"

namespace comm_access {

enum ConfigErrorCode {
  GET_WUJI_CONFIGID_FAIL = -1000,
};

inline std::string GetOrElse(const std::map<std::string, std::string>& m, const std::string& k,
                             const std::string& d) {
  auto it = m.find(k);
  if (it == m.end()) {
    return d;
  }
  return it->second;
}

inline std::string GetWujiConfigKey(const std::string& appid, const std::string& callee,
                                    const std::string& func) {
  std::string key = appid + callee + func;
  return key;
}

template <typename T>
inline std::string GetWujiConfigKey(T msg, const std::string& default_appid) {
  const std::string& appid = msg->GetCallerId() != "" ? msg->GetCallerId() : default_appid;
  const std::string& callee = msg->GetServantName();
  const std::string& func = msg->GetFuncName();
  return GetWujiConfigKey(appid, callee, func);
}

class ConfigRecord {
 public:
  uint32_t proto_type_{0};
  std::string appid_;
  std::string callee_;
  std::string func_;
  virtual const std::string key() const {
    return comm_access::GetWujiConfigKey(appid_, callee_, func_);
  }
};

typedef std::shared_ptr<ConfigRecord> ConfigRecordPtr;

class ConfigParser {
 public:
  virtual ConfigRecordPtr Parse(const std::map<std::string, std::string>& m) = 0;
  // filter 控制数据是否需要被丢弃, return false 表示数据需要被丢弃
  virtual bool Filter(ConfigRecordPtr ptr) { return nullptr != ptr; }
};

typedef std::shared_ptr<ConfigParser> ConfigParserPtr;

class ConfigUpdater {
 public:
  ConfigUpdater(ConfigParserPtr parser, ConfigRecordPtr default_config,
                const std::string& wuji_config_id)
      : parser_(parser), default_config_(default_config) {
    wuji_config_id_ = atoi(spp_rpc::GetConfParams(wuji_config_id).c_str());
  }
  virtual ~ConfigUpdater() {}
  virtual int Init() {
    // wuji_config_id_ 为 0 代表初始化失败
    if (wuji_config_id_ == 0) {
      return GET_WUJI_CONFIGID_FAIL;
    }
    return 0;
  }
  virtual int UpdateConfig(UnifiedConfigWujiMult* config_wuji_mult);
  virtual ConfigRecordPtr config(const std::string& key) const;
  const uint32_t wuji_config_id() const { return wuji_config_id_; }

  ConfigRecordPtr default_config_info() const { return default_config_; }

 private:
  std::unordered_map<std::string, ConfigRecordPtr> wuji_m_;
  uint64_t last_update_time_ = 0;
  uint32_t wuji_config_id_ = 0;

  ConfigParserPtr parser_;
  ConfigRecordPtr default_config_;
};

typedef std::shared_ptr<ConfigUpdater> ConfigUpdaterPtr;

template <class TParser, class TConfig>
ConfigUpdater* NewConfigUpdater(const std::string& wuji_config_id) {
  auto parser = new TParser;
  auto defualt_config = new TConfig;
  return new ConfigUpdater(ConfigParserPtr(parser), ConfigRecordPtr(defualt_config),
                           wuji_config_id);
}

}  // namespace comm_access
