// Copyright 2019 Tencent authors.

#pragma once

#include "src/config_frame/config_interface.h"

#include <netinet/in.h>
#include <sys/ioctl.h>

#include <map>
#include <memory>
#include <set>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

#include "util/tc_autoptr.h"
#include "util/tc_common.h"
#include "util/tc_singleton.h"

namespace comm_access {

int ConfigUpdater::UpdateConfig(UnifiedConfigWujiMult* config_wuji_mult) {
  if (!config_wuji_mult) {
    return -1;
  }
  uint64_t update_time = config_wuji_mult->GetLastUpdateTimestamp();
  RPC_DLOG("now:%ld, last:%ld", update_time, last_update_time_);
  if (update_time <= last_update_time_) return 0;

  std::vector<std::string> keys;
  int ret = config_wuji_mult->GetKeys(wuji_config_id_, &keys);
  RPC_LOG_RET(ret, "wuji.GetKeys failed err:%s", config_wuji_mult->GetErrorMsg().c_str());
  std::unordered_map<std::string, ConfigRecordPtr> wuji_m_tmp;
  for (auto& k : keys) {
    std::vector<std::map<std::string, std::string>> vecValue;
    int ret = config_wuji_mult->Get(wuji_config_id_, k, &vecValue);
    if (ret == 0) {
      for (auto m : vecValue) {
        ConfigRecordPtr ptr = parser_->Parse(m);
        if (ptr && parser_->Filter(ptr)) {
          std::string c_key = ptr->key();
          wuji_m_tmp.insert(std::make_pair(c_key, ptr));
          RPC_DLOG("update config:key[%s]", c_key.c_str());
        }
      }
    } else {
      return -2;
    }
  }
  swap(wuji_m_tmp, wuji_m_);
  last_update_time_ = update_time;
  return 0;
}

ConfigRecordPtr ConfigUpdater::config(const std::string& key) const {
  auto it = wuji_m_.find(key);
  if (it != wuji_m_.end()) {
    return it->second;
  }
  return nullptr;
}

}  // namespace comm_access
