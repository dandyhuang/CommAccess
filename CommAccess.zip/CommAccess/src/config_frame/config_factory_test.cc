//  Copyright 2020 Tencent authors.

#define private public
#define protected public

#include "src/config_frame/config_factory.h"

#include "config_frame_test_helper.h"

TEST(ConfigFrame, Case1_FakeWuji_P0) {
  FakeUnifiedConfigWujiMult fake_config_wuji_mult;
  fake_config_wuji_mult.add_datafile(1, "./src/config_frame/testdata/t_trpc_routeconf.csv",
                                     {"appid", "callee", "func"});

  std::vector<uint64_t> vec_config_id{1};
  ASSERT_EQ(fake_config_wuji_mult.Init(&vec_config_id), 0);
  std::vector<std::string> keys;
  EXPECT_EQ(fake_config_wuji_mult.GetKeys(1, &keys), 0);
  EXPECT_NE(keys.size(), 0);
  std::vector<std::map<std::string, std::string>> data;
  EXPECT_EQ(fake_config_wuji_mult.Get(1, "test_no_key", &data), 493939);
  EXPECT_EQ(fake_config_wuji_mult.Get(1, keys[0], &data), 0);
  EXPECT_EQ(data.size(), 1);
  EXPECT_EQ(data[0]["func"], "/activity/ReceiveAward");
}

TEST(ConfigFrameTest, Case2_Init_Succ_P0) {
  LOAD_CONFIG("./src/config_frame/testdata/CommAccessTest.xml");
  SETUP_CONFIG_MGR(fake_config_wuji_mult);
  fake_config_wuji_mult->add_datafile(1, "./src/config_frame/testdata/t_trpc_routeconf.csv",
                                      {"appid", "callee", "func"});
  ON_CALL(*fake_config_wuji_mult, GetLastUpdateTimestamp()).WillByDefault(::testing::Return(1));
  ASSERT_EQ(INS_CONFIG_MGR->Init(), 0);
}

TEST(ConfigFrameTest, Case2_Init_Fail_P0) {
  LOAD_CONFIG("./src/config_frame/testdata/CommAccessTest.xml");
  SETUP_CONFIG_MGR(fake_config_wuji_mult);
  ASSERT_EQ(INS_CONFIG_MGR->Init(), 493939);
}

TEST(ConfigFrameTest, Case3_GetCofig_P0) {
  LOAD_CONFIG("./src/config_frame/testdata/CommAccessTest.xml");
  SETUP_CONFIG_MGR(fake_config_wuji_mult);
  fake_config_wuji_mult->add_datafile(1, "./src/config_frame/testdata/t_trpc_routeconf.csv",
                                      {"appid", "callee", "func"});
  ON_CALL(*fake_config_wuji_mult, GetLastUpdateTimestamp()).WillByDefault(::testing::Return(1));

  ASSERT_EQ(INS_CONFIG_MGR->Init(), 0);
  std::string key =
      "1000005com.tencent.qqlive.modules.vb.pbdata.ChannelListService/"
      "com.tencent.qqlive.modules.vb.pbdata.ChannelListService/getChannelList";
  RPC_DLOG("%s", key.c_str());

  // config 不存在
  EXPECT_EQ(INS_CONFIG_MGR->config(999, "", false), nullptr);
  EXPECT_EQ(INS_CONFIG_MGR->config(comm_access::kDemoConfig, "", false), nullptr);
  EXPECT_NE(INS_CONFIG_MGR->config(comm_access::kDemoConfig, "", true), nullptr);
  auto base_config = INS_CONFIG_MGR->config(comm_access::kDemoConfig, key, false);
  ASSERT_NE(base_config, nullptr);
  EXPECT_EQ(base_config->key(), key);
  auto plugin_config =
      INS_CONFIG_MGR->config<comm_access::DemoConfig>(comm_access::kDemoConfig, key, false);
  ASSERT_NE(plugin_config, nullptr);
  EXPECT_EQ(plugin_config->key(), key);
  EXPECT_EQ(plugin_config->demo_, "demo_test");
  INS_CONFIG_MGR->SetConfigWujiMult(nullptr);
}
