// Copyright 2020 Tencent authors.

#pragma once

// #include "nameapi2.h"
#include <netinet/in.h>
#include <sys/ioctl.h>
#include <unified_config_wuji.h>
#include <util/tc_autoptr.h>
#include <util/tc_common.h>
#include <util/tc_singleton.h>

#include <map>
#include <memory>
#include <set>
#include <string>
#include <unordered_map>
#include <utility>

#include "spp_rpc/spp_rpc.h"
#include "src/config_frame/config_interface.h"
#include "unified_config_wuji.h"  // NOLINT

namespace comm_access {

enum ConfigId {
  kDemoConfig = 0,
  kTrpcRouteConfigId = 1,
  kThirdRouteConfigId = 2,
  kUserTypeConfigId = 3,
  kLimitConfigId = 4,
  kDyeFlagConfigId = 5,
  kSecurityConfigId = 6,
  kPluginConfigId = 7,
  kAuthConfigId = 8,
};

typedef void* (*ObjCreaterConfigFunc)();

class ConfigApiManager {
 public:
  int Init();
  ConfigApiManager() { config_wuji_mult_ = new UnifiedConfigWujiMult(); }
  ~ConfigApiManager() {
    if (config_wuji_mult_) {
      delete config_wuji_mult_;
      config_wuji_mult_ = nullptr;
    }
  }
  template <class TConfig>
  std::shared_ptr<TConfig> config(uint32_t id, const std::string& key,
                                  bool use_default = true) const {
    return std::dynamic_pointer_cast<TConfig>(config(id, key, use_default));
  }

  ConfigRecordPtr config(uint32_t id, const std::string& key, bool use_default = true) const {
    auto config_updater_ptr = config_updater(id);
    if (!config_updater_ptr) {
      printf("not exist|config_id:%u\n", id);
      return nullptr;
    }
    auto config_ptr = config_updater_ptr->config(key);

    if (use_default && !config_ptr) {
      return config_updater_ptr->default_config_info();
    }
    return config_ptr;
  }

  int UpdateConfig();

  // 这段代码应该需要隔离出来
  int RegisterObjCreaterConfigFunc(const uint32_t id, ObjCreaterConfigFunc func) {
    int ret =
        register_config_map_.insert(std::pair<uint32_t, ObjCreaterConfigFunc>(id, func)).second;
    if (!ret) {
      printf("exist|config_id:%u\n", id);
      exit(1);
    } else {
      printf("register ObjCreaterConfigFunc|%u:%p\n", id, func);
    }
    return 0;
  }

  UnifiedConfigWujiMult* config_wuji_mult() { return config_wuji_mult_; }

  const std::string& appid() { return appid_; }

 protected:
  std::unordered_map<uint32_t, ConfigUpdaterPtr> config_updaters_;
  std::unordered_map<uint32_t, ObjCreaterConfigFunc> register_config_map_;
  UnifiedConfigWujiMult* config_wuji_mult_;

 private:
  ConfigUpdaterPtr config_updater(const uint32_t id) const {
    auto it = config_updaters().find(id);
    if (it == config_updaters().end()) return nullptr;
    return it->second;
  }

  void SetConfigWujiMult(UnifiedConfigWujiMult* wjm) {
    if (config_wuji_mult_) {
      delete config_wuji_mult_;
      config_wuji_mult_ = nullptr;
    }
    config_wuji_mult_ = wjm;
  }

  void AddConfigUpdater(const uint32_t id, ConfigUpdaterPtr ptr) {
    config_updaters_.insert(std::make_pair(id, ptr));
  }
  const std::unordered_map<uint32_t, ConfigUpdaterPtr>& config_updaters() const {
    return config_updaters_;
  }

  std::string appid_;
};

typedef tars::TC_Singleton<comm_access::ConfigApiManager> ConfigApiManagerSingleton;
#define INS_CONFIG_MGR comm_access::ConfigApiManagerSingleton::getInstance()

#define COMM_ACCESS_REGISTER_CONFIG_FUNC(id, func) \
  static const bool g_register_##id##func = INS_CONFIG_MGR->RegisterObjCreaterConfigFunc(id, func)

}  // namespace comm_access
