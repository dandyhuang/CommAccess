//  Copyright 2020 Tencent authors.
#pragma once

#define private public
#define protected public

#include <fstream>
#include <map>
#include <vector>

#include "gmock/gmock.h"
#include "gtest/gtest.h"
#include "src/config_frame/config_factory.h"
#include "src/configs/demo/demo_config.h"
#include "unified_config_wuji_mock.h"

#define LOAD_CONFIG(configfile)                                                    \
  do {                                                                             \
    spp_rpc::ConfigManager* conf = spp_rpc::ConfigManagerSingleton::getInstance(); \
    int ret = conf->Init("./src/config_frame/testdata/CommAccessTest.xml");        \
    EXPECT_EQ(ret, 0);                                                             \
  } while (0);

#define SETUP_CONFIG_MGR(fake_config_wuji_mult)                                     \
  FakeUnifiedConfigWujiMult* fake_config_wuji_mult = new FakeUnifiedConfigWujiMult; \
  INS_CONFIG_MGR->SetConfigWujiMult(fake_config_wuji_mult);

std::vector<std::string> readOneLineFromCSV(std::ifstream& infile) {
  std::string line, val;
  std::vector<std::string> result;
  if (!infile.eof()) {
    getline(infile, line, '\n');
    std::stringstream input(line);
    if (line != "\0") {
      while (getline(input, val, ',')) {
        result.push_back(val.c_str());
      }
    }
  }
  return result;
}

class FakeUnifiedConfigWujiMult : public UnifiedConfigWujiMultMock {
 public:
  int add_datafile(uint64_t config_id, const std::string& datafile,
                   const std::vector<std::string>& keycols) {
    datafiles_[config_id] = std::make_pair(datafile, keycols);
    return 0;
  }
  int Init(const std::vector<uint64_t>* pst_vec_config_id, bool block = true) override {
    for (auto it = datafiles_.begin(); it != datafiles_.end(); it++) {
      int ret = load_data_from_csv(it->first, it->second.first, it->second.second);
      if (ret) {
        return E_CONFIG_ID_NOT_FOUND;
      }
    }
    for (uint64_t config_id : *pst_vec_config_id) {
      auto it = data_.find(config_id);
      if (it == data_.end()) {
        return E_CONFIG_ID_NOT_FOUND;
      }
    }
    return 0;
  };

  int GetKeys(uint64_t config_id, std::vector<std::string>* pst_vec) {
    auto it = data_.find(config_id);
    if (it == data_.end()) {
      return UnifiedConfigWujiMult::E_CONFIG_ID_NOT_FOUND;
    }
    for (auto& tp : it->second) {
      pst_vec->emplace_back(tp.first);
    }
    return 0;
  }

  int Get(uint64_t config_id, const std::string& key,
          std::vector<std::map<std::string, std::string>>* pst_value) {
    auto it = data_.find(config_id);
    if (it == data_.end()) {
      return UnifiedConfigWujiMult::E_CONFIG_ID_NOT_FOUND;
    }
    auto it_val = it->second.find(key);
    if (it_val == it->second.end()) {
      return UnifiedConfigWujiMult::E_CONFIG_ID_NOT_FOUND;
    }
    pst_value->insert(pst_value->end(), it_val->second.begin(), it_val->second.end());
    return 0;
  }

  void DebugInfo() {
    for (auto tp_c : data_) {
      for (auto tp_k : tp_c.second) {
        RPC_DLOG("config_id|%ld,key|%s", tp_c.first, tp_k.first.c_str());
      }
    }
  }

 private:
  int load_data_from_csv(uint32_t config_id, const std::string& filename,
                         const std::vector<std::string>& key_cols) {
    std::ifstream infile;
    infile.open(filename);
    if (!infile) return -1;
    std::vector<std::string> header = std::move(readOneLineFromCSV(infile));
    std::map<std::string, int> col_index;
    for (size_t i = 0; i < header.size(); i++) {
      col_index[header[i]] = i;
    }
    auto getKey = [&](std::vector<std::string>& cols) {
      std::string key;
      for (size_t i = 0; i != key_cols.size(); i++) {
        if (i != 0) {
          key += '&';
        }
        key += cols[col_index[key_cols[i]]];
      }
      return key;
    };
    while (!infile.eof()) {
      auto dataline = readOneLineFromCSV(infile);
      std::string key = getKey(dataline);
      auto& valmap = data_[config_id][key];
      valmap.resize(valmap.size() + 1);
      for (size_t i = 0; i != dataline.size(); i++) {
        if (i >= header.size()) continue;
        valmap.back()[header[i]] = dataline[i];
      }
    }
    infile.close();
    return 0;
  }
  std::map<uint64_t, std::pair<std::string, std::vector<std::string>>> datafiles_;
  std::map<uint64_t, std::map<std::string, std::vector<std::map<std::string, std::string>>>> data_;
};
