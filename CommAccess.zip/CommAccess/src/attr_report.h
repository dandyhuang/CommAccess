
/*
 *
 * Copyright 2019 Tencent authors.
 *
 * report
 *
 */

#ifndef SRC_ATTR_REPORT_H_
#define SRC_ATTR_REPORT_H_

#include <iostream>
#include <string>

#include "Attr_API_WRAP.h"

namespace pcg_attr {

typedef struct STPcgAttrReport {
  STPcgAttrReport() {
    total = 0;
    success = 0;
    failed = 0;
    cost = 0;
    ret = 0;
    func_ret = 0;
    auto_retry_flag = 0;

    callee = "";
    func = "";
    active_ip = "";
    passive_ip = "";
    appid = "";
    version = "";
    platform = "";
    calltype = "";
    proto_type = "";
  }

  std::string callee;
  std::string func;
  std::string active_ip;
  std::string passive_ip;
  std::string appid;
  std::string version;
  std::string platform;
  std::string calltype;
  std::string proto_type;

  // Dimension
  int total;
  int success;
  int failed;
  int cost;
  int ret;
  int func_ret;
  int auto_retry_flag;
} STAttrReport;

class AttrReport {
 public:
  void attr_demo();
  int Init();
  void CustomItemAttr(const STAttrReport& req);

 private:
  string custom_name_;
};
}  // namespace pcg_attr

#endif  // SRC_ATTR_REPORT_H_
