/*
 *
 * Copyright 2020 Tencent authors.
 *
 * third msg
 *
 */

#pragma once
#include <memory>
#include <string>

#include "backend_header.pb.h"
#include "request_base.pb.h"
#include "spp_rpc/client/http_proxy.h"
#include "spp_rpc/msg/http_msg.h"
#include "src/comm/config.h"
#include "src/comm/util.h"
#include "video_packet/video_packet.h"

namespace comm_access {

using com::tencent::qqlive::protocol::pb::BackEndRequestHead;
using com::tencent::qqlive::protocol::pb::RequestHead;

class HttpCommMsg : public spp_rpc::HttpMsg {
 public:
  HttpCommMsg() { context_->set_msg(this); }
  ~HttpCommMsg() = default;

  void set_rsp(const tars::TC_HttpResponse& rsp) { rsp_ = rsp; }
  std::shared_ptr<const WuJiConfig> config() const {
    if (config_ == nullptr) {
      static std::shared_ptr<WuJiConfig> empty = std::make_shared<WuJiConfig>();
      return empty;
    }
    return config_;
  }
  RouteInfo& GetRouteInfo() { return r_info_; }
  void SetBusiIp(string ip) { busi_remote_ip_ = ip; }
  bool GetThirdAuth() { return third_auth_; }
  const std::string& GetThirdParam() const { return third_param_; }
  const RequestHead& ReqHead() const { return head_; }
  RequestHead* ReqMutablHead() { return &head_; }
  void InitVideoPacket();
  std::shared_ptr<CVideoPacket> packet() const { return packet_; }

  const std::string& GetHttpCallee() const { return callee_; }
  const std::string& GetHttpFunc() const { return func_; }
  const std::string& GetHttpAppid() const { return appid_; }
  void set_config(const WuJiConfig wuji) { config_ = std::make_shared<WuJiConfig>(wuji); }

 protected:
  int CheckParams() override;
  int ProcessServant() override;
  void ResponseImp(int frame_code, int logic_code) override;
  const std::string& GetTracerServantName() const {
    static std::string name = "normal.CommAcc.HttpCommMsg";
    return name;
  }
  int PackResponse(int frame_code, int logic_code);
  void SetCommRspHeader();
  int Code2StatusCode(int errcode);
  void AttaReport(int frame_code, int logic_code);
  int CheckValidation();
  virtual void UpdateConfig();
  const spp_rpc::ProtoType GetProto() const override { return spp_rpc::PROTO_TYPE_HTTP; }
  std::string GetAppid();

  const std::string& main_login() {
    if (!is_parse_main_login_) {
      main_login_ = GetCookie("main_login");
      is_parse_main_login_ = true;
    }
    return main_login_;
  }

  const std::string& vusession() {
    if (!vusession_.empty()) return vusession_;
    if (main_login() == "qq") {
      vusession_ = GetCookie("vqq_vusession");
    } else {  //  main_login() == "wx" + 海外版
      vusession_ = GetCookie("vusession");
    }
    return vusession_;
  }

  const std::string& skey() {
    if (!skey_.empty()) return skey_;
    skey_ = GetParam("skey");
    if (skey_.empty()) {
      skey_ = GetParam("lskey");
    }
    return skey_;
  }

  const std::string& vusession_old() {
    if (!vusession_old_.empty()) return vusession_old_;
    vusession_old_ = GetCookie("vqq_vusession");
    if (vusession_old_.empty()) {
      vusession_old_ = GetCookie("vusession");
    }
    return vusession_old_;
  }

  const std::string& accesstoken() {
    if (!accesstoken_.empty()) return accesstoken_;
    if (main_login() == "qq") {
      accesstoken_ = GetCookie("vqq_access_token");
    } else if (main_login() == "wx") {
      accesstoken_ = GetCookie("access_token");
    }
    return accesstoken_;
  }

  const std::string& accesstoken_old() {
    if (!accesstoken_old_.empty()) return accesstoken_old_;
    accesstoken_old_ = GetCookie("vqq_access_token");
    if (accesstoken_old_.empty()) {
      accesstoken_old_ = GetCookie("access_token");
    }
    return accesstoken_old_;
  }

  int64_t GetAntiCSRFToken(const string& skey) {
    int64_t hash = 5381;
    for (size_t i = 0; i < skey.length(); i++) {
      hash += (hash << 5) + skey[i];
    }

    return hash & 0x7fffffff;
  }

 private:
  void ParseUinToken();
  void ParseThirdToken();
  void ParseQqAuthToken();
  void ParseWxToken();
  void ParseVideoToken();
  void SetTransInfo();
  void SetCommHead();
  int CheckBasicInfo();
  string TeaDecrypt(const string& pwd, const string& encrypted);
  bool CheckCSRFToken(const std::string& tk, const std::string& skey);

 protected:
  bool qq_auth_ = false;     // qq 互联登录
  bool third_auth_ = false;  // 第三方登陆
  bool is_parse_main_login_ = false;
  std::string skey_ = "";
  std::string vusession_;
  std::string vusession_old_;
  std::string accesstoken_;
  std::string accesstoken_old_;
  std::string main_login_;
  std::string third_param_;
  std::shared_ptr<WuJiConfig> config_ = nullptr;
  RouteInfo r_info_;
  std::string busi_remote_ip_;
  std::string callee_;
  std::string appid_;
  std::string func_;
  std::shared_ptr<CVideoPacket> packet_;
  spp_rpc::HttpRpcProxyPtr proxy_;
  RequestHead head_;
  BackEndRequestHead backend_head_;
  string set_info_;    //  tv业务，回包不做任何封装
  int http_type_ = 0;  // 0:json 1 trpc
};

spp_rpc::SppRpcBaseMsg* HttpCommMsgCreater();

}  // namespace comm_access
