//  Copyright 2020 Tencent authors.

#include "src/plugins/check_teen_guard/qmf_check_teen_guard_plugin.h"

#include <string>

#include "gmock/gmock.h"
#include "gtest/gtest.h"
#include "jce/teen_guardian_flag.h"
#include "jce/videotoken.h"
#include "spp_rpc/client/jce_proxy2.h"
#include "spp_rpc/client/jce_proxy2_mock.h"
#include "spp_rpc/client/servant_proxy_factory.h"
#include "src/comm/config.h"
#include "src/plugin_frame/plugin.h"
#include "src/qmf_msg.h"

typedef ::spp_rpc::MockJceRpcProxy2<ns_teen_guardian_flag::GetTeenGuardianFlagReq,
                                    ns_teen_guardian_flag::GetTeenGuardianFlagRsp>
    MockJceTeenGuardRpcProxy2;

/**
 * @case_name QmfCheckTeenGuardPlugin.Case1_CheckTeenGuard_P0
 * @priority P0
 * @brief video_flag非1场景，不调用后端青少年api
 */
TEST(QmfCheckTeenGuardPlugin, Case1_CheckTeenGuard_P0) {
  auto plugin = reinterpret_cast<comm_access::QmfCheckTeenGuardPlugin*>(
      comm_access::qmf_check_teen_guard_plugin());
  auto qmf_msg = dynamic_cast<comm_access::QmfMsg*>(comm_access::QmfMsgCreater());
  comm_access::WuJiConfig config;
  qmf_msg->set_config(config);
  plugin->set_msg(qmf_msg);
  qmf_msg->mutable_video_req()->logic_header.mutable_user_status_info()->set_session_code(
      "D07B1890330EB7FFE93F7EE0A71F673A9779FE4E78CDE718FD0791BA38F29142E97C4B34969B75060A6BC628DC28"
      "EBD156C63F59F57B66E91A1AC16D");  // NOLINT
  EXPECT_EQ(plugin->Invoke(), comm_access::kOk);
  EXPECT_EQ(qmf_msg->GetVideoMutableReqBackendHead()->user_info().video_flag(), 7);
}

/**
 * @case_name QmfCheckTeenGuardPlugin.Case2_CheckTeenGuard_P0
 * @priority P0
 * @brief 调用青少年服务，把返回的flag打到包头里
 */
TEST(QmfCheckTeenGuardPlugin, Case2_CheckTeenGuard_P0) {
  auto mock_teen_guard_proxy = new MockJceTeenGuardRpcProxy2;
  EXPECT_CALL(*mock_teen_guard_proxy, Exec(::testing::_, ::testing::_, ::testing::_))
      .Times(1)
      .WillOnce([&](const ns_teen_guardian_flag::GetTeenGuardianFlagReq& req,
                    ns_teen_guardian_flag::GetTeenGuardianFlagRsp* rsp,
                    ::spp_rpc::ServantContextPtr context) {
        rsp->flag = 1;
        return 0;
      });
  ::testing::MockFunction<::spp_rpc::ServantProxy*(const std::string&, uint32_t set_id)> mock_func;
  // 当获取com.tencent.spp_rpc2.RpcHello2的proxy时，mock这个proxy
  EXPECT_CALL(mock_func, Call("TeenGuard", 0)).WillOnce(::testing::Return(mock_teen_guard_proxy));
  spp_rpc::ServantProxyFactorySingleton::getInstance()->set_func(mock_func.AsStdFunction());
  auto plugin = reinterpret_cast<comm_access::QmfCheckTeenGuardPlugin*>(
      comm_access::qmf_check_teen_guard_plugin());
  auto qmf_msg = dynamic_cast<comm_access::QmfMsg*>(comm_access::QmfMsgCreater());
  comm_access::WuJiConfig config;
  config.video_flag = 1;
  qmf_msg->set_config(config);
  plugin->set_msg(qmf_msg);
  EXPECT_EQ(plugin->Invoke(), comm_access::kOk);
  EXPECT_EQ(qmf_msg->GetVideoMutableReqBackendHead()->user_info().video_flag(), 1);
}