/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 青少年插件。
 *
 */

#pragma once

#include <memory>

#include "src/plugin_frame/plugin.h"
#include "src/qmf_msg.h"

namespace comm_access {

class QmfCheckTeenGuardPlugin : public Plugin {
 public:
  explicit QmfCheckTeenGuardPlugin(const PluginParam& param) : Plugin(param) {}
  virtual ~QmfCheckTeenGuardPlugin() = default;
  virtual int Invoke();
  void InitVideoPacket(QmfMsg* qmf_msg);
  std::shared_ptr<CVideoPacket> packet() const { return packet_; }

 private:
  std::shared_ptr<CVideoPacket> packet_ = nullptr;
};

extern "C" void* qmf_check_teen_guard_plugin();

}  // namespace comm_access
