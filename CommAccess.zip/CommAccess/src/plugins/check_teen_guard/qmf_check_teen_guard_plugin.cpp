/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 青少年插件。
 *
 */

#include "src/plugins/check_teen_guard/qmf_check_teen_guard_plugin.h"

#include <string>
#include <utility>
#include <vector>

#include "jce/teen_guardian_flag.h"
#include "spp_rpc/client/jce_proxy.h"
#include "spp_rpc/client/jce_proxy2.h"
#include "spp_rpc/client/servant_proxy_factory.h"
#include "spp_rpc/common/logger/logger_interface.h"
#include "src/comm/config.h"
#include "src/comm/taskdec.h"
#include "src/comm/util.h"
#include "src/plugin_frame/plugin_factory.h"
#include "src/plugin_frame/plugin_id.h"
#include "src/qmf_msg.h"

namespace comm_access {

typedef ::spp_rpc::JceRpcProxy2<ns_teen_guardian_flag::GetTeenGuardianFlagReq,
                                ns_teen_guardian_flag::GetTeenGuardianFlagRsp>
    JceTeenGuardRpcProxy2;
typedef tars::TC_AutoPtr<JceTeenGuardRpcProxy2> JceTeenGuardRpcProxyPtr2;

extern "C" void* qmf_check_teen_guard_plugin() {
  PluginParam param;
  param.id = kQmfCheckTeenGuardPluginId;
  param.name = __FUNCTION__;
  param.priority = kQmfCheckTeenGuardPluginPriority;
  param.proto = spp_rpc::PROTO_TYPE_QMF;
  param.enable = GetPluginStatus(__FUNCTION__);
  auto plugin = new comm_access::QmfCheckTeenGuardPlugin(param);
  return plugin;
}

COMM_ACCESS_REGISTER_PLUGIN_FUNC(kQmfCheckTeenGuardPluginId, qmf_check_teen_guard_plugin);

int QmfCheckTeenGuardPlugin::Invoke() {
  SPAN_LOG_FUNCTION_START(msg());
  auto qmf_msg = dynamic_cast<QmfMsg*>(msg());
  if (!qmf_msg) {
    SPAN_ELOG(msg(), "dynamic_cast qmf_msg is null");
    return kFailedContinue;
  }
  auto s_code = qmf_msg->video_req().logic_header.user_status_info().session_code();
  if (!s_code.empty()) {
    task_dec::stTask st_task;
    int ret = task_dec::task_decrypt(s_code, 0, st_task);
    if (ret != 0) {
      SPAN_ELOG(msg(), "teenSessionCode key:[%s], ERROR:[%d]", s_code.c_str(), ret);
      return kOk;
    }
    SPAN_DLOG(msg(), "video_flag:%d", st_task.type);
    qmf_msg->GetVideoMutableReqBackendHead()->mutable_user_info()->set_video_flag(st_task.type);
  }

  if (qmf_msg->config()->video_flag == 1) {
    ns_teen_guardian_flag::GetTeenGuardianFlagReq req;
    ns_teen_guardian_flag::GetTeenGuardianFlagRsp rsp;
    InitVideoPacket(qmf_msg);
    JceTeenGuardRpcProxyPtr2 ptr = spp_rpc::GetServantProxy<JceTeenGuardRpcProxyPtr2>("TeenGuard");
    ptr->set_force_video_packet(this->packet().get());
    RPC_LOG_RET(ptr->Exec(req, &rsp, qmf_msg->context()), "err teen guard");
    SPAN_DLOG(msg(), "video_flag:%d", rsp.flag);
    qmf_msg->GetVideoMutableReqBackendHead()->mutable_user_info()->set_video_flag(rsp.flag);
  }
  SPAN_LOG_FUNCTION_END(msg());
  return kOk;
}

void QmfCheckTeenGuardPlugin::InitVideoPacket(QmfMsg* qmf_msg) {
  if (packet_ == nullptr) {
    packet_ = std::make_shared<CVideoPacket>();
    spp_rpc::CommonHeadUtil::PbHeadReq2Jce(qmf_msg->video_req().logic_header,
                                           &packet_->getVideoCommHeader());
  }
}

}  // namespace comm_access
