/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 鉴权插件。
 *
 */

#pragma once

#include <memory>

#include "src/plugin_frame/plugin.h"
#include "src/qmf_msg.h"

namespace comm_access {

class QmfCheckAuthPlugin : public Plugin {
 public:
  explicit QmfCheckAuthPlugin(const PluginParam &param) : Plugin(param) {}
  virtual ~QmfCheckAuthPlugin() = default;
  void InitVideoPacket(QmfMsg *qmf_msg);
  virtual int Invoke();
  std::shared_ptr<CVideoPacket> packet() const { return packet_; }

 private:
  std::shared_ptr<CVideoPacket> packet_ = nullptr;
};

extern "C" void *qmf_check_auth_plugin();

}  // namespace comm_access
