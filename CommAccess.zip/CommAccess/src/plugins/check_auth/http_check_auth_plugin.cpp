/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 鉴权插件。
 *
 */

#include "src/plugins/check_auth/http_check_auth_plugin.h"

#include <string>
#include <utility>
#include <vector>

#include "spp_rpc/common/logger/logger_interface.h"
#include "src/access_err.h"
#include "src/comm/config.h"
#include "src/comm/util.h"
#include "src/http_comm_msg.h"
#include "src/plugin_frame/plugin_factory.h"
#include "src/plugin_frame/plugin_id.h"
#include "src/plugins/check_auth/check_auth_server.h"

namespace comm_access {

extern "C" void *http_check_auth_plugin() {
  PluginParam param;
  param.id = kHttpCheckAuthPluginId;
  param.name = __FUNCTION__;
  param.priority = kHttpCheckAuthPluginPriority;
  param.proto = spp_rpc::PROTO_TYPE_HTTP;
  param.enable = GetPluginStatus(__FUNCTION__);
  auto plugin = new comm_access::HttpCheckAuthPlugin(param);
  return plugin;
}

// 把插件注册函数注册到框架
COMM_ACCESS_REGISTER_PLUGIN_FUNC(kHttpCheckAuthPluginId, http_check_auth_plugin);

int HttpCheckAuthPlugin::Invoke() {
  SPAN_LOG_FUNCTION_START(msg());
  auto http_msg = dynamic_cast<HttpCommMsg *>(msg());
  if (!http_msg) {
    SPAN_ELOG(msg(), "dynamic_cast http_msg is null");
    return kFailedContinue;
  }
  AuthServer auth(msg()->context());
  // 第三方鉴权走该逻辑
  if (http_msg->GetThirdAuth()) {
    http_msg->InitVideoPacket();
    int ret = auth.ThirdAuth(http_msg->packet().get(), http_msg->ReqMutablHead(),
                             &(http_msg->GetThirdParam()));
    if (ret) {
      SPAN_ELOG(msg(), "http_msg third auth fail[%d]", ret);
      msg()->set_frame_error_code(E_QMF_AUTH_FAILED);
      return kFailedEnd;
    }
    return kOk;
  }

  if (http_msg->config()->auth_flag == 1 || http_msg->config()->auth_flag == 2) {
    bool is_token = false;
    if (http_msg->ReqHead().login_token_size() > 0) {
      is_token = true;
    } else {
      // 登陆态校验不通过，也透传`
      if (http_msg->config()->auth_flag == 2) {
        SPAN_DLOG(msg(), "return kOk|flags:%u", http_msg->config()->auth_flag);
        return kOk;
      }
      SPAN_DLOG(msg(), "check_failed return kFailedEnd|flags:%u|err:%d",
                http_msg->config()->auth_flag, E_QMF_AUTH_FAILED);
      msg()->set_frame_error_code(E_QMF_AUTH_FAILED);
      return kFailedEnd;
    }
    http_msg->InitVideoPacket();
    int ret =
        auth.HandleProcess(http_msg->packet().get(), http_msg->ReqHead().version_info().app_id(),
                           http_msg->ReqHead().login_token());
    // 登陆态校验不通过，也透传
    if (http_msg->config()->auth_flag == 2) {
      SPAN_DLOG(msg(), "return kOk|flags:%u|ret:%d|is_token:%d", http_msg->config()->auth_flag, ret,
                is_token);
      return kOk;
    } else if (ret || !is_token) {
      SPAN_DLOG(msg(),
                "check_failed return kFailedEnd|flag:%u|ret:%d|"
                "is_token:%d|err_code:%d",
                http_msg->config()->auth_flag, ret, is_token, E_QMF_AUTH_FAILED);
      msg()->set_frame_error_code(E_QMF_AUTH_FAILED);
      return kFailedEnd;
    }
  }
  SPAN_DLOG(msg(), "return kOk");
  SPAN_LOG_FUNCTION_END(msg());
  return kOk;
}

}  // namespace comm_access
