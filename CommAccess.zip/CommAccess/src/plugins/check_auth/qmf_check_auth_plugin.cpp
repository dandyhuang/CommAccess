/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 鉴权插件。
 *
 */

#include "src/plugins/check_auth/qmf_check_auth_plugin.h"

#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "spp_rpc/common/logger/logger_interface.h"
#include "src/access_err.h"
#include "src/comm/config.h"
#include "src/comm/util.h"
#include "src/plugin_frame/plugin_factory.h"
#include "src/plugin_frame/plugin_id.h"
#include "src/plugins/check_auth/check_auth_server.h"
#include "src/qmf_msg.h"

namespace comm_access {

extern "C" void *qmf_check_auth_plugin() {
  PluginParam param;
  param.id = kQmfCheckAuthPluginId;
  param.name = __FUNCTION__;
  param.priority = kQmfCheckAuthPluginPriority;
  param.proto = spp_rpc::PROTO_TYPE_QMF;
  param.enable = GetPluginStatus(__FUNCTION__);
  auto plugin = new comm_access::QmfCheckAuthPlugin(param);
  return plugin;
}

// 把插件注册函数注册到框架
COMM_ACCESS_REGISTER_PLUGIN_FUNC(kQmfCheckAuthPluginId, qmf_check_auth_plugin);

int QmfCheckAuthPlugin::Invoke() {
  SPAN_LOG_FUNCTION_START(msg());
  auto qmf_msg = dynamic_cast<QmfMsg *>(msg());
  if (!qmf_msg) {
    SPAN_ELOG(msg(), "dynamic_cast qmf_msg is null");
    return kFailedContinue;
  }
  AuthServer auth(msg()->context());
  // auth.TokenConvert(qmf_msg->GetVideoMutableReqHead().get());
  if (qmf_msg->config()->auth_flag == 1 || qmf_msg->config()->auth_flag == 2) {
    bool is_token = false;
    if (qmf_msg->video_req().logic_header.login_token_size() > 0) {
      is_token = true;
    } else {
      // 登陆态校验不通过，也透传
      if (qmf_msg->config()->auth_flag == 2) {
        SPAN_DLOG(msg(), "return kOk|flags:%u", qmf_msg->config()->auth_flag);
        return kOk;
      }
      SPAN_DLOG(msg(), "check_failed return kFailedEnd|flags:%u|err:%d",
                qmf_msg->config()->auth_flag, E_QMF_AUTH_FAILED);
      msg()->set_frame_error_code(E_QMF_AUTH_FAILED);
      return kFailedEnd;
    }
    InitVideoPacket(qmf_msg);
    int ret = auth.HandleProcess(this->packet().get(),
                                 qmf_msg->video_req().logic_header.version_info().app_id(),
                                 qmf_msg->video_req().logic_header.login_token());
    // 登陆态校验不通过，也透传
    if (qmf_msg->config()->auth_flag == 2) {
      SPAN_DLOG(msg(), "return kOk|flags:%u|ret:%d|is_token:%d", qmf_msg->config()->auth_flag, ret,
                is_token);
      return kOk;
    } else if (ret || !is_token) {
      SPAN_DLOG(msg(),
                "check_failed return kFailedEnd|flag:%u|ret:%d|"
                "is_token:%d|err_code:%d",
                qmf_msg->config()->auth_flag, ret, is_token, E_QMF_AUTH_FAILED);
      msg()->set_frame_error_code(E_QMF_AUTH_FAILED);
      return kFailedEnd;
    }
  }
  SPAN_DLOG(msg(), "return kOk");
  SPAN_LOG_FUNCTION_END(msg());
  return kOk;
}

void QmfCheckAuthPlugin::InitVideoPacket(QmfMsg *qmf_msg) {
  if (packet_ == nullptr) {
    packet_ = std::make_shared<CVideoPacket>();
    spp_rpc::CommonHeadUtil::PbHeadReq2Jce(qmf_msg->video_req().logic_header,
                                           &packet_->getVideoCommHeader());
  }
}

}  // namespace comm_access
