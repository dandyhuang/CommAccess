//  Copyright 2020 Tencent authors.

#include "src/plugins/check_auth/qmf_check_auth_plugin.h"

#include <string>

#include "gmock/gmock.h"
#include "gtest/gtest.h"
#include "jce/videotoken.h"
#include "spp_rpc/client/jce_proxy2.h"
#include "spp_rpc/client/jce_proxy2_mock.h"
#include "src/comm/config.h"
#include "src/plugin_frame/plugin.h"
#include "src/plugins/check_auth/check_auth_server.h"

typedef ::spp_rpc::MockJceRpcProxy2<videoToken::STReqCheckToken, videoToken::STRspCheckToken>
    MockJceVideoUserVerifyRpcProxy2;

/**
 * @case_name QmfCheckAuthPlugin.Case1_CheckAuth_P0
 * @priority P0
 * @brief 登陆态校验不通过也透传
 */
TEST(QmfCheckAuthPlugin, Case1_CheckAuth_P0) {
  auto plugin =
      reinterpret_cast<comm_access::QmfCheckAuthPlugin *>(comm_access::qmf_check_auth_plugin());
  auto qmf_msg = dynamic_cast<comm_access::QmfMsg *>(comm_access::QmfMsgCreater());
  comm_access::WuJiConfig config;
  config.auth_flag = 2;
  qmf_msg->set_config(config);
  plugin->set_msg(qmf_msg);
  EXPECT_EQ(plugin->Invoke(), comm_access::kOk);
}

/**
 * @case_name QmfCheckAuthPlugin.Case2_CheckAuth_P0
 * @priority P0
 * @brief 不带登录态失败
 */
TEST(QmfCheckAuthPlugin, Case2_CheckAuth_P0) {
  auto plugin =
      reinterpret_cast<comm_access::QmfCheckAuthPlugin *>(comm_access::qmf_check_auth_plugin());
  auto qmf_msg = dynamic_cast<comm_access::QmfMsg *>(comm_access::QmfMsgCreater());
  comm_access::WuJiConfig config;
  config.auth_flag = 1;
  qmf_msg->set_config(config);
  plugin->set_msg(qmf_msg);
  EXPECT_EQ(plugin->Invoke(), comm_access::kFailedEnd);
}

void CreateAuthReq(comm_access::QmfMsg *qmf_msg) {
  comm_access::WuJiConfig config;
  config.auth_flag = 1;
  qmf_msg->set_config(config);
  // qq
  auto token = qmf_msg->mutable_video_req()->logic_header.add_login_token();
  token->set_type(1);
  token->set_account("12345678");
  // vuid
  token = qmf_msg->mutable_video_req()->logic_header.add_login_token();
  token->set_type(9);
  token->set_account("87654321");
  // qq openid
  token = qmf_msg->mutable_video_req()->logic_header.add_login_token();
  token->set_type(10);
  token->set_account("90D8FFD43E9DEFDXXXXXXC7B7B797371");
  // wechat openid
  token = qmf_msg->mutable_video_req()->logic_header.add_login_token();
  token->set_type(100);
  token->set_account("90D8FFD43E9DEFDYYYYYYC7B7B797371");
}

void MockVideoUserVerify(MockJceVideoUserVerifyRpcProxy2 *mock_proxy, const int ret) {
  EXPECT_CALL(*mock_proxy, Exec(::testing::_, ::testing::_, ::testing::_))
      .Times(1)
      .WillOnce([ret](const videoToken::STReqCheckToken &req, videoToken::STRspCheckToken *rsp,
                      ::spp_rpc::ServantContextPtr context) {
        rsp->cResult = ret;
        return 0;
      });
  static ::testing::MockFunction<::spp_rpc::ServantProxy *(const std::string &, uint32_t set_id)>
      mock_func;
  // 当获取com.tencent.spp_rpc2.RpcHello2的proxy时，mock这个proxy
  EXPECT_CALL(mock_func, Call("VideoUserVerify", 0)).WillOnce(::testing::Return(mock_proxy));
  spp_rpc::ServantProxyFactorySingleton::getInstance()->set_func(mock_func.AsStdFunction());
}

/**
 * @case_name QmfCheckAuthPlugin.Case2_CheckAuth_P0
 * @priority P0
 * @brief 带登录态返回成功
 */
TEST(QmfCheckAuthPlugin, Case3_CheckAuth_P0) {
  auto mock_video_user_verify_proxy = new MockJceVideoUserVerifyRpcProxy2;
  MockVideoUserVerify(mock_video_user_verify_proxy, 0);
  auto plugin =
      reinterpret_cast<comm_access::QmfCheckAuthPlugin *>(comm_access::qmf_check_auth_plugin());
  auto qmf_msg = dynamic_cast<comm_access::QmfMsg *>(comm_access::QmfMsgCreater());
  CreateAuthReq(qmf_msg);
  plugin->set_msg(qmf_msg);
  EXPECT_EQ(plugin->Invoke(), comm_access::kOk);
}

/**
 * @case_name QmfCheckAuthPlugin.Case4_CheckAuth_P0
 * @priority P0
 * @brief 带登录态mock返回失败校验不通过场景
 */
TEST(QmfCheckAuthPlugin, Case4_CheckAuth_P0) {
  auto mock_video_user_verify_proxy = new MockJceVideoUserVerifyRpcProxy2;
  MockVideoUserVerify(mock_video_user_verify_proxy, 1);
  auto plugin =
      reinterpret_cast<comm_access::QmfCheckAuthPlugin *>(comm_access::qmf_check_auth_plugin());
  auto qmf_msg = dynamic_cast<comm_access::QmfMsg *>(comm_access::QmfMsgCreater());
  CreateAuthReq(qmf_msg);
  plugin->set_msg(qmf_msg);
  EXPECT_EQ(plugin->Invoke(), comm_access::kFailedEnd);
}