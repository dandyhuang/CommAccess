/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 鉴权插件。
 *
 */

#pragma once

#include "src/http_comm_msg.h"
#include "src/plugin_frame/plugin.h"

namespace comm_access {

class HttpCheckAuthPlugin : public Plugin {
 public:
  explicit HttpCheckAuthPlugin(const PluginParam& param) : Plugin(param) {}
  virtual ~HttpCheckAuthPlugin() = default;
  virtual int Invoke();
};

extern "C" void* http_check_auth_plugin();

}  // namespace comm_access
