/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 鉴权api
 *
 */

#pragma once
#include <google/protobuf/repeated_field.h>

#include <string>

#include "spp_rpc/client/trpc_servant_proxy.h"
#include "spp_rpc/spp_rpc.h"
#include "src/codec/qmf_protocol.h"

namespace comm_access {
using com::tencent::qqlive::protocol::pb::LoginToken;
using com::tencent::qqlive::protocol::pb::RequestHead;
class AuthServer {
 public:
  explicit AuthServer(spp_rpc::ServantContextPtr context) { context_ = context; }
  void TokenConvert(RequestHead *head);
  int HandleProcess(CVideoPacket *packet, string appid,
                    google::protobuf::RepeatedPtrField<LoginToken> tokens);
  int ThirdAuth(CVideoPacket *packet, RequestHead *head, const std::string *param);

 private:
  int VerifyVideoUserId(spp_rpc::ServantContextPtr context, const string &TokenUin,
                        const string &TokenValue, const string &appid);
  int VerifyThirdLogin(spp_rpc::ServantContextPtr context, const LoginToken *token,
                       RequestHead *head, const std::string *param);

 private:
  uint64_t ddwPtUin_ = 0;        // 老qq号
  uint64_t ddwInnerUserId_ = 0;  // 视频账号
  uint64_t ddwinnerUin_ = 0;     // 互联登录qq号
  string w_openid_;              // 微信登录
  uint32_t result_ = -1;         // token鉴权结果
  RequestHead *head_ = nullptr;
  spp_rpc::ServantContextPtr context_ = nullptr;
  CVideoPacket *packet_ = nullptr;
};

}  // namespace comm_access
