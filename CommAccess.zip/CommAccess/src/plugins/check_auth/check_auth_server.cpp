/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 鉴权api
 *
 */

#include "src/plugins/check_auth/check_auth_server.h"

#include <vector>

#include "jce/third_login.h"
#include "jce/videotoken.h"
#include "spp_rpc/client/jce_proxy.h"
#include "spp_rpc/client/jce_proxy2.h"
#include "spp_rpc/task_flow.h"
#include "src/access_err.h"
#include "token_api.h"

namespace comm_access {

using com::tencent::qqlive::protocol::pb::LoginToken;

typedef ::spp_rpc::JceRpcProxy2<videoToken::STReqCheckToken, videoToken::STRspCheckToken>
    JceVideoUserVerifyRpcProxy2;

typedef tars::TC_AutoPtr<JceVideoUserVerifyRpcProxy2> JceVideoUserVerifyRpcProxyPtr2;

void AuthServer::TokenConvert(RequestHead *head) {
  head_ = head;
  if (!head_) {
    return;
  }
  int qq_openid = 0;
  string v_openid = "";
  std::vector<LoginToken> v_token;
  SPAN_TLOG(context_->msg(), "token_size:%d", head_->login_token_size());
  for (int32_t i = 0; i < head_->login_token_size(); ++i) {  // NOLINT
    LoginToken &token = (LoginToken &)head_->login_token(i);
    // todo需要加个resutl字段，填充接入层的鉴权结果
    // qq登录
    if (token.type() == 1 || token.type() == 7) {
      if (token.account().length() > 0) {
        ddwPtUin_ = strtoll(token.account().c_str(), NULL, 10);
        SPAN_TLOG(context_->msg(), "ddwPtUin_:%lu", ddwPtUin_);
      }
    }
    // 视频登录
    if (token.type() == 9) {
      if (token.account().length() > 0) {
        ddwInnerUserId_ = strtoll(token.account().c_str(), NULL, 10);
        SPAN_TLOG(context_->msg(), "ddwInnerUserId_:%lu", ddwInnerUserId_);
      }

      v_openid = token.token();
      int error = GetQQFromToken(v_openid, ddwinnerUin_);
      if (error != 0) {
        ddwinnerUin_ = 0;
      }
    }
    // 互联登录
    if (token.type() == 10) {
      qq_openid = 1;
    }
    // 微信登录
    if (token.type() == 100) {
      if (token.account().length() > 0) {
        w_openid_ = token.account();
      }
    }
    v_token.push_back(token);
  }

  if (qq_openid == 1) {
    int error = GetQQFromToken(v_openid, ddwinnerUin_);
    if (error == 0) {
      SPAN_TLOG(context_->msg(), "v_openid:%s|ddwPtUin_:%lu", v_openid.c_str(), ddwinnerUin_);
      LoginToken token;
      token.set_app_id("350001");
      token.set_type(1);
      token.set_account(to_string(ddwinnerUin_));
      token.set_token(v_openid);
      token.set_is_main_login(false);
      v_token.push_back(token);
    }
  }

  // todo: 暂时这样处理，后续需要优化
  head_->clear_login_token();
  SPAN_TLOG(context_->msg(), "token clear size:%d", head_->login_token_size());
  for (auto v : v_token) {
    LoginToken *token = head_->add_login_token();
    *token = v;
  }
  SPAN_TLOG(context_->msg(), "token append size:%d", head_->login_token_size());
}

// 调用提供JCE的服务
int AuthServer::VerifyVideoUserId(spp_rpc::ServantContextPtr context, const string &token_uin,
                                  const string &token_value, const string &appid) {
  SPAN_LOG_FUNCTION_START(context_->msg());
  videoToken::STReqCheckToken req;
  req.ddwUserid = atol(token_uin.c_str());
  req.strSessionKey = token_value;
  req.cVersion = 1;
  videoToken::STRspCheckToken rsp;
  string user_config = "VideoUserVerify";
  if (appid == "1200004" || "1200009" == appid) {
    req.cModuleFrom = videoToken::E_FROM_OVERSEA;
    req.dwBaseId = 10008;
    req.strBaseKey = "a7e63fd649a3871c64e324da59776296";
    user_config = "VideoSeaUserVerify";
  }

  JceVideoUserVerifyRpcProxyPtr2 ptr =
      spp_rpc::GetServantProxy<JceVideoUserVerifyRpcProxyPtr2>(user_config);

  ptr->set_force_video_packet(packet_);
  // RPC_LOG_RET(ptr->Exec(req, &rsp, context),
  // "jce VideoUserVerify exec err");
  ptr->Exec(req, &rsp, context);
  if (rsp.cResult != 0) {
    result_ = 3;
    SPAN_DLOG(context_->msg(), "error msg:%s", rsp.strErrMsg.c_str());
    return -1;
  } else {
    SPAN_DLOG(context_->msg(), "error msg:%s", rsp.strErrMsg.c_str());
    result_ = 0;
  }

  SPAN_LOG_FUNCTION_END(context_->msg());
  return 0;
}

int AuthServer::HandleProcess(CVideoPacket *packet, string appid,
                              google::protobuf::RepeatedPtrField<LoginToken> tokens) {
  packet_ = packet;
  spp_rpc::LamTaskList task_list;
  int32_t size = tokens.size();
  for (int32_t i = 0; i < size; i++) {
    const LoginToken &token = tokens.Get(i);
    // 只校验vuid票价了
    if (token.type() == 9) {
      task_list += [&]() {
        return VerifyVideoUserId(context_, token.account(), token.token(), appid);  // NOLINT
      };
    }
  }

  // 最后，执行Sync函数，就会基于微线程并发执行前面的所有任务。
  SPAN_LOG_RET(context_->msg(), task_list.Sync(), "lam task list sync err");

  // 基于之前关联的唯一标记，来获取对应LamTask的错误码。
  SPAN_DLOG(context_->msg(), "result:%d", result_);

  return result_;
}

int AuthServer::VerifyThirdLogin(spp_rpc::ServantContextPtr context, const LoginToken *token,
                                 RequestHead *head, const std::string *param) {
  thirdLogin::STReqCheckOpenToken req;
  req.strVideoThirdOpenid = token->account();
  req.strOpenSessionKey = token->token();
  req.strAppid = token->app_id();
  req.strExtInfo = *param;
  SPAN_DLOG(context_->msg(), "param:%s", (*param).c_str());
  auto ptr = spp_rpc::GetServantProxy<thirdLogin::ThirdAccountLoginProxyPtr>("ThirdAuthProxy");
  thirdLogin::STRspCheckOpenToken rsp;

  ptr->CheckOpenToken(req, &rsp, context);

  if (rsp.retCode != 0) {
    SPAN_DLOG(context_->msg(), "Error:%d", rsp.retCode);
    result_ = 3;
    return -1;
  } else {
    result_ = 0;
  }

  LoginToken t;
  t.set_app_id(token->app_id());
  t.set_type(9);
  t.set_account(std::to_string(rsp.vuid));
  t.set_token(token->token());
  t.set_is_main_login(false);
  LoginToken *tokens = head->add_login_token();
  *tokens = t;

  return 0;
}

int AuthServer::ThirdAuth(CVideoPacket *packet, RequestHead *head, const std::string *param) {
  packet_ = packet;
  spp_rpc::LamTaskList task_list;
  int32_t size = head->login_token_size();
  for (int32_t i = 0; i < size; i++) {
    const LoginToken &token = head->login_token(i);
    if (token.type() == 50) {
      task_list += [&]() {
        return VerifyThirdLogin(context_, &token, head, param);  // NOLINT
      };
    }
  }

  // 最后，执行Sync函数，就会基于微线程并发执行前面的所有任务。
  SPAN_LOG_RET(context_->msg(), task_list.Sync(), "lam task list sync err");
  SPAN_DLOG(context_->msg(), "token size:%d", head->login_token_size());

  // 基于之前关联的唯一标记，来获取对应LamTask的错误码。
  SPAN_DLOG(context_->msg(), "result:%d", result_);

  return result_;
}

}  // namespace comm_access
