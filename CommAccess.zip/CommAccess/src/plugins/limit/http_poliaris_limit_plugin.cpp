/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 身份标识插件。
 *
 */

#include "src/plugins/limit/http_poliaris_limit_plugin.h"

#include <map>
#include <string>
#include <utility>
#include <vector>

#include "spp_rpc/client/servant_proxy_factory.h"
#include "spp_rpc/common/logger/logger_interface.h"
#include "src/access_err.h"
#include "src/comm/docker_env.h"
#include "src/comm/util.h"
#include "src/http_comm_msg.h"
#include "src/plugin_frame/plugin_factory.h"
#include "src/plugin_frame/plugin_id.h"

namespace comm_access {

extern "C" void *http_poliaris_limit_plugin() {
  PluginParam param;
  param.id = kHttpLimitPoliarisPluginId;
  param.name = __FUNCTION__;
  param.priority = kHttpLimitPoliarisPlugin;
  param.proto = spp_rpc::PROTO_TYPE_HTTP;
  param.enable = GetPluginStatus(__FUNCTION__);
  auto plugin = new comm_access::HttpLimitPoliarisPlugin(param);
  return plugin;
}

COMM_ACCESS_REGISTER_PLUGIN_FUNC(kHttpLimitPoliarisPluginId, http_poliaris_limit_plugin);

int HttpLimitPoliarisPlugin::Invoke() {
  SPAN_LOG_FUNCTION_START(msg());
  auto http_msg = dynamic_cast<HttpCommMsg *>(msg());
  if (!http_msg) {
    SPAN_ELOG(msg(), "dynamic_cast http_msg is null");
    return kFailedContinue;
  }
  int ret = CheckLimit(http_msg->config().get(), http_msg->GetHttpAppid(),
                       http_msg->GetHttpCallee(), http_msg->GetHttpFunc(), HTTP_TYPE);
  if (ret != 0) {
    http_msg->set_frame_error_code(E_DISPATCH_LIMIT_FAIL);
    return kFailedEnd;
  }

  SPAN_LOG_FUNCTION_END(msg());
  return kOk;
}

}  // namespace comm_access
