/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 身份标识插件。
 *
 */

#pragma once

#include <string>

#include "src/comm/config.h"
#include "src/plugin_frame/plugin.h"

namespace comm_access {

class LimitPoliarisPlugin : public Plugin {
 public:
  explicit LimitPoliarisPlugin(const PluginParam& param) : Plugin(param) {}
  virtual ~LimitPoliarisPlugin() = default;
  virtual int CheckLimit(const WuJiConfig* config, const std::string& appid,
                         const std::string& callee, const std::string& func, int type);
  virtual int Invoke() { return 0; }
};

extern "C" void* poliaris_limit_plugin();

}  // namespace comm_access
