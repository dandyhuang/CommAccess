/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 身份标识插件。
 *
 */

#include "src/plugins/limit/poliaris_limit_plugin.h"

#include <map>
#include <string>
#include <utility>
#include <vector>

#include "flow_sdk.h"
#include "spp_rpc/common/logger/logger_interface.h"
#include "spp_rpc/spp_rpc.h"
#include "src/comm/docker_env.h"
#include "src/plugin_frame/plugin_factory.h"
#include "src/plugin_frame/plugin_id.h"

namespace comm_access {

// 这个config要初始化绑定到trpc插件
extern "C" int limit_poliaris_plugin_init(void* arg1, void* arg2) {
  RPC_LOG_FUNCTION_START;
  static int flow_init_ = 0;
  if (flow_init_) return 0;
  // 初始化限流
  std::string flow_conf_path = spp_rpc::GetConfParams("flow_conf_path");
  int ret = flow_ctrl::FlowSdk::getInstance()->Init(flow_conf_path);
  if (ret) {
    RPC_ELOG("limit_poliaris_plugin_init error:%d", ret);
  } else {
    flow_init_ = 1;
  }
  return 0;
}

// 如果需要Init则要注册Init函数
COMM_ACCESS_REGISTER_PLUGIN_INIT_FUNC(kQmfLimitPoliarisPluginId, limit_poliaris_plugin_init);
COMM_ACCESS_REGISTER_PLUGIN_INIT_FUNC(kHttpLimitPoliarisPluginId, limit_poliaris_plugin_init);
COMM_ACCESS_REGISTER_PLUGIN_INIT_FUNC(kTrpcLimitPoliarisPluginId, limit_poliaris_plugin_init);

int LimitPoliarisPlugin::CheckLimit(const WuJiConfig* config, const std::string& appid,
                                    const std::string& callee, const std::string& func, int type) {
  if (config->limit_flag == CLOSE_FLAG_TYPE) return 0;

  static std::string name_space = INS_DOCKER_ENV->namepsace();
  static std::string service_name = "trpc.commaccess.polaris.limit";

  std::map<std::string, std::string> resource_map;
  std::string key = appid + "|" + callee + "|" + func + "|" + std::to_string(type);
  resource_map.insert(make_pair(key, "query_limit"));
  RPC_TLOG("CheckLimit key %s|%s", key.c_str(), msg()->GetFuncName().c_str());
  // 自定义名字空间和服务名
  int ret =
      flow_ctrl::FlowSdk::getInstance()->CheckPolarisLable(resource_map, name_space, service_name);
  RPC_TLOG("flow ret = %d", ret);
  return ret;
}

}  // namespace comm_access
