/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 身份标识插件。
 *
 */

#include "src/plugins/limit/trpc_poliaris_limit_plugin.h"

#include <map>
#include <string>
#include <utility>
#include <vector>

#include "spp_rpc/client/servant_proxy_factory.h"
#include "spp_rpc/common/logger/logger_interface.h"
#include "src/access_err.h"
#include "src/comm/docker_env.h"
#include "src/comm/util.h"
#include "src/plugin_frame/plugin_factory.h"
#include "src/plugin_frame/plugin_id.h"
#include "src/trpc_comm_msg.h"

namespace comm_access {

extern "C" void *trpc_poliaris_limit_plugin() {
  PluginParam param;
  param.id = kTrpcLimitPoliarisPluginId;
  param.name = __FUNCTION__;
  param.priority = kTrpcLimitPoliarisPlugin;
  param.proto = spp_rpc::PROTO_TYPE_TRPC;
  param.enable = GetPluginStatus(__FUNCTION__);
  auto plugin = new comm_access::TrpcLimitPoliarisPlugin(param);
  return plugin;
}

COMM_ACCESS_REGISTER_PLUGIN_FUNC(kTrpcLimitPoliarisPluginId, trpc_poliaris_limit_plugin);

int TrpcLimitPoliarisPlugin::Invoke() {
  SPAN_LOG_FUNCTION_START(msg());
  auto trpc_msg = dynamic_cast<TrpcCommMsg *>(msg());
  if (!trpc_msg) {
    SPAN_ELOG(msg(), "dynamic_cast trpc_msg is null");
    return kFailedContinue;
  }
  int ret =
      CheckLimit(trpc_msg->config().get(), trpc_msg->appid(), trpc_msg->req().logic_header.callee(),
                 trpc_msg->req().logic_header.func(), QMF_TYPE);
  if (ret != 0) {
    trpc_msg->set_frame_error_code(E_DISPATCH_LIMIT_FAIL);
    return kFailedEnd;
  }

  SPAN_LOG_FUNCTION_END(msg());
  return kOk;
}

}  // namespace comm_access
