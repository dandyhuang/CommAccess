/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 身份标识插件。
 *
 */

#pragma once

#include <string>

#include "src/plugins/limit/poliaris_limit_plugin.h"

namespace comm_access {

class HttpLimitPoliarisPlugin : public LimitPoliarisPlugin {
 public:
  explicit HttpLimitPoliarisPlugin(const PluginParam &param) : LimitPoliarisPlugin(param) {}
  virtual ~HttpLimitPoliarisPlugin() = default;
  virtual int Invoke();
};

}  // namespace comm_access
