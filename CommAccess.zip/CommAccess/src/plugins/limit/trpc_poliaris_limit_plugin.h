/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 身份标识插件。
 *
 */

#pragma once

#include <string>

#include "src/plugins/limit/poliaris_limit_plugin.h"

namespace comm_access {

class TrpcLimitPoliarisPlugin : public LimitPoliarisPlugin {
 public:
  explicit TrpcLimitPoliarisPlugin(const PluginParam &param) : LimitPoliarisPlugin(param) {}
  virtual ~TrpcLimitPoliarisPlugin() = default;
  virtual int Invoke();
};

extern "C" void *trpc_poliaris_limit_plugin();

}  // namespace comm_access
