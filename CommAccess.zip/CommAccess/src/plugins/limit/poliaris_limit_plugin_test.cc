//  Copyright 2020 Tencent authors.

#include "src/plugins/limit/poliaris_limit_plugin.h"

#include "gmock/gmock.h"
#include "gtest/gtest.h"
#include "src/comm/config.h"
#include "src/plugin_frame/plugin.h"
#include "src/plugin_frame/plugin_id.h"
#include "src/qmf_msg.h"

namespace comm_access {

class MockPoliarisPlugin : public LimitPoliarisPlugin {
 public:
  explicit MockPoliarisPlugin(const PluginParam &param) : LimitPoliarisPlugin(param) {}
  virtual int CheckLimit(const WuJiConfig *config, const std::string &appid,
                         const std::string &callee, const std::string &func, int type) {
    if (config->limit_flag == CLOSE_FLAG_TYPE) {
      return 0;
    } else if (config->limit_flag == START_FLAG_TYPE) {
      return -1;
    }
  }
};

extern "C" void *mock_poliaris_limit_plugin() {
  PluginParam param;
  param.id = comm_access::kLimitPoliarisPluginId;
  param.name = __FUNCTION__;
  param.priority = comm_access::kLimitPoliarisPlugin;
  param.proto = spp_rpc::PROTO_TYPE_ALL;  // 所有协议都走限流
  param.enable = GetPluginStatus(__FUNCTION__);
  auto plugin = new comm_access::MockPoliarisPlugin(param);
  return plugin;
}

}  //  namespace comm_access

TEST(MockPoliarisPlugin, Case1_GetUserType_P0) {
  auto plugin = reinterpret_cast<comm_access::MockPoliarisPlugin *>(
      comm_access::mock_poliaris_limit_plugin());
  auto qmf_msg = dynamic_cast<comm_access::QmfMsg *>(comm_access::QmfMsgCreater());
  comm_access::WuJiConfig config;
  config.limit_flag = comm_access::CLOSE_FLAG_TYPE;
  qmf_msg->set_config(config);
  plugin->set_msg(qmf_msg);

  RPC_DLOG("req proto:%d", qmf_msg->GetProto());
  EXPECT_EQ(plugin->Invoke(), comm_access::kOk);
  config.limit_flag = comm_access::START_FLAG_TYPE;
  qmf_msg->set_config(config);
  plugin->set_msg(qmf_msg);
  EXPECT_EQ(plugin->Invoke(), comm_access::kFailedEnd);
}