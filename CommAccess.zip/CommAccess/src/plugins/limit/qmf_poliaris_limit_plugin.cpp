/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 身份标识插件。
 *
 */

#include "src/plugins/limit/qmf_poliaris_limit_plugin.h"

#include <map>
#include <string>
#include <utility>
#include <vector>

#include "spp_rpc/client/servant_proxy_factory.h"
#include "spp_rpc/common/logger/logger_interface.h"
#include "src/access_err.h"
#include "src/comm/docker_env.h"
#include "src/comm/util.h"
#include "src/plugin_frame/plugin_factory.h"
#include "src/plugin_frame/plugin_id.h"
#include "src/qmf_msg.h"

namespace comm_access {

extern "C" void *qmf_poliaris_limit_plugin() {
  PluginParam param;
  param.id = kQmfLimitPoliarisPluginId;
  param.name = __FUNCTION__;
  param.priority = kQmfLimitPoliarisPlugin;
  param.proto = spp_rpc::PROTO_TYPE_QMF;
  param.enable = GetPluginStatus(__FUNCTION__);
  auto plugin = new comm_access::QmfLimitPoliarisPlugin(param);
  return plugin;
}

COMM_ACCESS_REGISTER_PLUGIN_FUNC(kQmfLimitPoliarisPluginId, qmf_poliaris_limit_plugin);

int QmfLimitPoliarisPlugin::Invoke() {
  SPAN_LOG_FUNCTION_START(msg());
  auto qmf_msg = dynamic_cast<QmfMsg *>(msg());
  if (!qmf_msg) {
    SPAN_ELOG(msg(), "dynamic_cast qmf_msg is null");
    return kFailedContinue;
  }

  int ret = CheckLimit(qmf_msg->config().get(),
                       qmf_msg->GetVideoMutableReqHead()->version_info().app_id(),
                       qmf_msg->GetVideoMutableReqHead()->callee(),
                       qmf_msg->GetVideoMutableReqHead()->func(), QMF_TYPE);
  if (ret != 0) {
    qmf_msg->mutable_rsp()->logic_header.set_ret(E_DISPATCH_LIMIT_FAIL);
    return kFailedEnd;
  }

  SPAN_LOG_FUNCTION_END(msg());
  return kOk;
}

}  // namespace comm_access
