/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 身份标识插件。
 *
 */

#pragma once

#include <string>

#include "include/union_proxy_v2.h"
#include "include/util/url_util.h"
#include "src/plugin_frame/plugin.h"
#include "src/qmf_msg.h"

namespace comm_access {

struct CUnionItem {
  std::string vuid;
  std::string cp_special;
  template <typename SS>
  void Serialize(SS &&ss) {
    _SERIALIZE_KEY_(ss, vuid);  // _SERIALZIE_KEY_ union特定的用于解析key值得
    _SERIALIZE_(ss, cp_special);
  }
};

class QmfGetUserTypePlugin : public Plugin {
 public:
  explicit QmfGetUserTypePlugin(const PluginParam &param) : Plugin(param) {}
  virtual ~QmfGetUserTypePlugin() = default;
  virtual int Invoke();
};

extern "C" void *qmf_get_user_type_plugin();

}  // namespace comm_access
