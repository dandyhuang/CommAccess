/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 身份标识插件。
 *
 */

#include "src/plugins/get_user_type/qmf_get_user_type_plugin.h"

#include <string>
#include <vector>

#include "gmock/gmock.h"
#include "gtest/gtest.h"
#include "spp_rpc/client/servant_proxy_factory.h"
#include "spp_rpc_union/union_proxy.h"
#include "spp_rpc_union/union_proxy_mock.h"
#include "src/comm/config.h"
#include "src/plugin_frame/plugin.h"
#include "src/qmf_msg.h"

using ::testing::_;
/**
 * @case_name QmfGetUserTypePlugin.Case1_GetUserType_P0
 * @priority P0
 * @brief
 */
TEST(QmfGetUserTypePlugin, Case1_GetUserType_P0) {
  auto plugin =
      reinterpret_cast<comm_access::QmfGetUserTypePlugin*>(comm_access::qmf_get_user_type_plugin());
  auto qmf_msg = dynamic_cast<comm_access::QmfMsg*>(comm_access::QmfMsgCreater());
  comm_access::WuJiConfig config;
  config.user_flag = 0;
  qmf_msg->set_config(config);
  plugin->set_msg(qmf_msg);
  EXPECT_EQ(plugin->Invoke(), comm_access::kOk);
}

/**
 * @case_name QmfGetUserTypePlugin.Case1_GetUserType_P0
 * @priority P0
 * @brief
 */
TEST(QmfGetUserTypePlugin, Case2_GetUserType_P0) {
  spp_rpc::MockUnionRpcProxy mock_proxy;
  EXPECT_CALL(mock_proxy, AccessUnion(_, _, _, _, _, _, _)).WillRepeatedly(::testing::Return(-1));
  static std::vector<std::string> vec_field{"c_title", "score"};
  std::vector<std::string> vec_vid{"tqrcx71evgmlcvx"};
  EXPECT_EQ(mock_proxy.AccessUnion(INS_CONFIG->GetUAppid(), INS_CONFIG->GetUAppkey(), 2071, vec_vid,
                                   vec_field, NULL, NULL),
            -1);

  auto plugin =
      reinterpret_cast<comm_access::QmfGetUserTypePlugin*>(comm_access::qmf_get_user_type_plugin());
  auto qmf_msg = dynamic_cast<comm_access::QmfMsg*>(comm_access::QmfMsgCreater());
  comm_access::WuJiConfig config;
  config.user_flag = 0;
  qmf_msg->set_config(config);
  plugin->set_msg(qmf_msg);
  EXPECT_EQ(plugin->Invoke(), comm_access::kOk);
}