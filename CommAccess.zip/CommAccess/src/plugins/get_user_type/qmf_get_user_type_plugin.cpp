/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 身份标识插件。
 *
 */

#include "src/plugins/get_user_type/qmf_get_user_type_plugin.h"

#include <string>
#include <utility>
#include <vector>

#include "spp_rpc/client/servant_proxy_factory.h"
#include "spp_rpc/common/logger/logger_interface.h"
#include "src/comm/config.h"
#include "src/comm/taskdec.h"
#include "src/comm/util.h"
#include "src/plugin_frame/plugin_factory.h"
#include "src/plugin_frame/plugin_id.h"
#include "src/qmf_msg.h"

namespace comm_access {

extern "C" void *qmf_get_user_type_plugin() {
  PluginParam param;
  param.id = kQmfGetUserTypePluginId;
  param.name = __FUNCTION__;
  param.priority = kQmfGetUserTypePluginPriority;
  param.proto = spp_rpc::PROTO_TYPE_QMF;
  param.enable = GetPluginStatus(__FUNCTION__);
  auto plugin = new comm_access::QmfGetUserTypePlugin(param);
  return plugin;
}

COMM_ACCESS_REGISTER_PLUGIN_FUNC(kQmfGetUserTypePluginId, qmf_get_user_type_plugin);

int QmfGetUserTypePlugin::Invoke() {
  SPAN_LOG_FUNCTION_START(msg());
  auto qmf_msg = dynamic_cast<QmfMsg *>(msg());
  if (!qmf_msg) {
    SPAN_ELOG(msg(), "dynamic_cast qmf_msg is null");
    return kFailedContinue;
  }

  // 用户身份回给终端上报
  std::string user_status_key = qmf_msg->vuid() + "&" + qmf_msg->GetOmgId();
  int64_t now_time = mt_time_ms();
  if ((user_status_key !=
       qmf_msg->GetVideoMutableReqHead()->user_status_info().user_status_key()) ||
      (now_time > qmf_msg->GetVideoMutableReqHead()->user_status_info().timestamp()) ||
      qmf_msg->config()->user_flag == START_FLAG_TYPE) {
    // union请求失败也赋值回包
    int special_user = qmf_msg->GetVideoMutableReqHead()->user_status_info().special_user();
    if (user_status_key !=
        qmf_msg->GetVideoMutableReqHead()->user_status_info().user_status_key()) {
      special_user = 0;
    }
    qmf_msg->GetVideoMutableReqHead()->mutable_user_status_info()->set_special_user(special_user);
    uint64_t expire_ms = now_time + INS_CONFIG->GetExpireMs();
    qmf_msg->GetVideoMutableReqHead()->mutable_user_status_info()->set_timestamp(expire_ms);

    qmf_msg->mutable_video_rsp()->logic_header.mutable_user_status_info()->set_special_user(
        special_user);
    qmf_msg->mutable_video_rsp()->logic_header.mutable_user_status_info()->set_timestamp(expire_ms);
    qmf_msg->mutable_video_rsp()->logic_header.mutable_user_status_info()->set_user_status_key(
        user_status_key);

    // 为空不请求
    if (qmf_msg->vuid().empty()) return kOk;
    std::vector<std::string> vuid;
    std::vector<CUnionItem> vec_union;
    vuid.push_back(qmf_msg->vuid());
    auto proxy = spp_rpc::GetServantProxy<spp_rpc::UnionRpcProxyV2Ptr>("union.2071.usertype");
    int ret = proxy->Exec(INS_CONFIG->GetUAppid(), INS_CONFIG->GetUAppkey(), 2071, vuid, vec_union,
                          qmf_msg->context());
    if (ret) {
      RPC_DLOG("GetUserTypePlugin error %d", ret);
      return kOk;
    }
    RPC_DLOG("%s, vuid:%s", DUMP_OBJ(vec_union), qmf_msg->vuid().c_str());

    if (vec_union.size() == 1) {
      if (vec_union[0].cp_special == "1") {
        special_user = 1;
        qmf_msg->GetVideoMutableReqHead()->mutable_user_status_info()->set_special_user(
            special_user);
        qmf_msg->mutable_video_rsp()->logic_header.mutable_user_status_info()->set_special_user(
            special_user);
      }
    }
  }
  SPAN_LOG_FUNCTION_END(msg());
  return kOk;
}

}  // namespace comm_access
