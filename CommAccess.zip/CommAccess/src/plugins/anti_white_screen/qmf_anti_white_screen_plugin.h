/*
 *
 * Copyright 2020 Tencent authors.
 *
 * qmf on trpc 协议防白屏插件。
 *
 */

#pragma once

#include <string>

#include "spp_rpc/codec/trpc/trpc_protocol.h"
#include "src/plugins/anti_white_screen/anti_white_screen_plugin.h"

namespace comm_access {

class QmfAntiWhiteScreenPlugin : public AntiWhiteScreenPlugin {
 public:
  explicit QmfAntiWhiteScreenPlugin(const PluginParam& param) : AntiWhiteScreenPlugin(param) {}
  virtual ~QmfAntiWhiteScreenPlugin() = default;
  CacheMode GetCacheMode() override;
  // 防白屏兜底 读缓存 转发方式 L5路由
  int ReadCache(spp_rpc::Status* frame_status, int* logic_code) override;
  // 防白屏更新 写缓存 接口方式
  int WriteCache(spp_rpc::Status* frame_status, int* logic_code) override;
  void OverrideRsp() override;
  const spp_rpc::TrpcResponseProtocol& cache_rsp() const { return cache_rsp_; }
  spp_rpc::TrpcResponseProtocol* mutable_cache_rsp() { return &cache_rsp_; }

 protected:
  spp_rpc::TrpcResponseProtocol cache_rsp_;
};

extern "C" void* qmf_anti_white_screen_plugin();

}  // namespace comm_access
