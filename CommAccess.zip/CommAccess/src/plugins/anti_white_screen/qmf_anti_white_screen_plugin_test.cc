/*
 *
 * Copyright 2020 Tencent authors.
 *
 * qmf on trpc 协议防白屏插件单元测试。
 *
 */

#include "src/plugins/anti_white_screen/qmf_anti_white_screen_plugin.h"

#include <string>
#include <vector>

#include "gmock/gmock.h"
#include "gtest/gtest.h"
#include "proto/complex_object.pb.h"
#include "spp_rpc/client/servant_proxy_factory.h"
#include "spp_rpc/client/trpc_servant_proxy_mock.h"
#include "src/comm/config.h"
#include "src/interface/common_cache_mock.spp_rpc.pb.h"
#include "src/plugin_frame/plugin.h"
#include "src/qmf_msg.h"

namespace comm_access {

class MockQmfMsg : public QmfMsg {
 public:
  int DecodeReq() { return QmfMsg::DecodeReq(); }
  int ProcessServant() { return QmfMsg::ProcessServant(); }
  void ResponseImp(int frame, int logic) { return; }
};

}  // namespace comm_access

// 被调服务mock 逻辑和现有被调服务一模一样
void MockSetComplexObj(spp_rpc::MockTrpcServantProxy* mock_proxy) {
  if (!mock_proxy) {
    return;
  }
  EXPECT_CALL(*mock_proxy, InvokeTrpc2(::testing::_, ::testing::_, ::testing::_))
      .Times(testing::AtLeast(0))
      .WillRepeatedly([&](spp_rpc::TrpcRequestProtocol& req_proto,
                          spp_rpc::TrpcResponseProtocol* rsp_proto,
                          const ::spp_rpc::ServantContextPtr& context) {
        com::tencent::spp_rpc::ComplexObjectRequest obj_req;
        int ret{0};
        req_proto.DecodeBody<com::tencent::spp_rpc::ComplexObjectRequest>(&obj_req);
        RPC_DLOG("req name:%s", obj_req.name().c_str());
        if (obj_req.name() == "read_cache_fail") {
          ret = -1;
        }
        return ::spp_rpc::Status(ret);
      });
  static ::testing::MockFunction<::spp_rpc::ServantProxy*(const std::string&, uint32_t set_id)>
      mock_func;
  EXPECT_CALL(mock_func, Call("com.tencent.spp_rpc.CommCacheTest", 0))
      .WillRepeatedly(::testing::Return(mock_proxy));
  spp_rpc::ServantProxyFactorySingleton::getInstance()->set_func(mock_func.AsStdFunction());
}

void MockWriteCacheNoCacheKey(com::tencent::comm_cache::MockCommCacheProxy* mock_proxy) {
  if (!mock_proxy) {
    return;
  }
  EXPECT_CALL(*mock_proxy, WriteCacheNoCacheKey(::testing::_, ::testing::_, ::testing::_))
      .Times(testing::AtLeast(0))
      .WillRepeatedly([&](const com::tencent::comm_cache::WriteCacheNoCacheKeyRequest& req,
                          com::tencent::comm_cache::WriteCacheNoCacheKeyResponse* rsp,
                          ::spp_rpc::ServantContextPtr context) {
        spp_rpc::TrpcRequestProtocol req_proto;
        com::tencent::spp_rpc::ComplexObjectRequest obj_req;
        int ret{0};
        std::string request_buf = req.request();
        req_proto.Decode(request_buf.data(), request_buf.size());
        req_proto.DecodeBody<com::tencent::spp_rpc::ComplexObjectRequest>(&obj_req);
        RPC_DLOG("req name:%s", obj_req.name().c_str());
        if (obj_req.name() == "write_cache_fail") {
          ret = -1;
        }
        return ::spp_rpc::Status(ret);
      });
  static ::testing::MockFunction<::spp_rpc::ServantProxy*(const std::string&, uint32_t set_id)>
      mock_func;
  EXPECT_CALL(mock_func, Call("com.tencent.comm_cache.CommCache", 0))
      .WillRepeatedly(::testing::Return(mock_proxy));
  spp_rpc::ServantProxyFactorySingleton::getInstance()->set_func(mock_func.AsStdFunction());
}

int AssembleRequest(comm_access::MockQmfMsg* msg, const std::string& name) {
  if (!msg) {
    return -1;
  }
  auto req = msg->mutable_req();
  req->logic_header.set_callee("com.tencent.spp_rpc.CommCacheTest");
  req->logic_header.set_func("/com.tencent.spp_rpc.CommCacheTest/SetComplexObj");
  com::tencent::spp_rpc::ComplexObjectRequest obj_req;
  obj_req.set_name(name);
  req->EncodeBody(obj_req);
  std::vector<char> buf;
  req->Encode(&buf);
  msg->SetReqPkg(&buf.at(0), buf.size());
  return 0;
}

/**
 * @case_name QmfAntiWhiteScreenPlugin.Case1_ReadCache_P0
 * @priority P0
 * @brief 防白屏读缓存成功
 */
TEST(QmfAntiWhiteScreenPlugin, Case1_ReadCache_P0) {
  auto plugin = reinterpret_cast<comm_access::QmfAntiWhiteScreenPlugin*>(
      comm_access::qmf_anti_white_screen_plugin());
  comm_access::MockQmfMsg qmf_msg;
  comm_access::WuJiConfig config;
  config.cache_type = comm_access::kAntiWhiteScreenMode;
  qmf_msg.set_config(config);
  EXPECT_EQ(AssembleRequest(&qmf_msg, "read_cache"), 0);
  qmf_msg.set_logic_error_code(1);
  plugin->set_msg(&qmf_msg);
  // 设置mock缓存读转发
  auto mock_trpc_servant_proxy = new spp_rpc::MockTrpcServantProxy;
  MockSetComplexObj(mock_trpc_servant_proxy);
  EXPECT_EQ(plugin->Invoke(), comm_access::kOk);
}

/**
 * @case_name QmfAntiWhiteScreenPlugin.Case2_ReadCacheFail_P0
 * @priority P0
 * @brief 防白屏读缓存失败
 */
TEST(QmfAntiWhiteScreenPlugin, Case2_ReadCacheFail_P0) {
  auto plugin = reinterpret_cast<comm_access::QmfAntiWhiteScreenPlugin*>(
      comm_access::qmf_anti_white_screen_plugin());
  comm_access::MockQmfMsg qmf_msg;
  comm_access::WuJiConfig config;
  config.cache_type = comm_access::kAntiWhiteScreenMode;
  qmf_msg.set_config(config);
  EXPECT_EQ(AssembleRequest(&qmf_msg, "read_cache_fail"), 0);
  qmf_msg.set_logic_error_code(1);
  plugin->set_msg(&qmf_msg);
  // 设置mock缓存读转发
  auto mock_trpc_servant_proxy = new spp_rpc::MockTrpcServantProxy;
  MockSetComplexObj(mock_trpc_servant_proxy);
  EXPECT_EQ(plugin->Invoke(), comm_access::kFailedContinue);
}

/**
 * @case_name QmfAntiWhiteScreenPlugin.Case3_WriteCache_P0
 * @priority P0
 * @brief 防白屏写缓存成功
 */
TEST(QmfAntiWhiteScreenPlugin, Case3_WriteCache_P0) {
  auto plugin = reinterpret_cast<comm_access::QmfAntiWhiteScreenPlugin*>(
      comm_access::qmf_anti_white_screen_plugin());
  comm_access::MockQmfMsg qmf_msg;
  comm_access::WuJiConfig config;
  config.cache_type = comm_access::kAntiWhiteScreenMode;
  qmf_msg.set_config(config);
  EXPECT_EQ(AssembleRequest(&qmf_msg, "write_cache"), 0);
  plugin->set_msg(&qmf_msg);
  // 设置mock缓存写接口
  auto mock_servant_proxy = new com::tencent::comm_cache::MockCommCacheProxy;
  MockWriteCacheNoCacheKey(mock_servant_proxy);
  EXPECT_EQ(plugin->Invoke(), comm_access::kOk);
}

/**
 * @case_name QmfAntiWhiteScreenPlugin.Case4_WriteCacheFail_P0
 * @priority P0
 * @brief 防白屏写缓存失败
 */
TEST(QmfAntiWhiteScreenPlugin, Case4_WriteCacheFail_P0) {
  auto plugin = reinterpret_cast<comm_access::QmfAntiWhiteScreenPlugin*>(
      comm_access::qmf_anti_white_screen_plugin());
  comm_access::MockQmfMsg qmf_msg;
  comm_access::WuJiConfig config;
  config.cache_type = comm_access::kAntiWhiteScreenMode;
  qmf_msg.set_config(config);
  EXPECT_EQ(AssembleRequest(&qmf_msg, "write_cache_fail"), 0);
  plugin->set_msg(&qmf_msg);
  // 设置mock缓存写接口
  auto mock_servant_proxy = new com::tencent::comm_cache::MockCommCacheProxy;
  MockWriteCacheNoCacheKey(mock_servant_proxy);
  EXPECT_EQ(plugin->Invoke(), comm_access::kFailedContinue);
}
