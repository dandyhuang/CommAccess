/*
 *
 * Copyright 2020 Tencent authors.
 *
 * qmf on trpc 协议防白屏插件。
 *
 */

#include "src/plugins/anti_white_screen/qmf_anti_white_screen_plugin.h"

#include <string>
#include <utility>
#include <vector>

#include "spp_rpc/client/servant_proxy_factory.h"
#include "spp_rpc/common/logger/logger_interface.h"
#include "src/comm/config.h"
#include "src/comm/util.h"
#include "src/interface/common_cache.spp_rpc.pb.h"
#include "src/plugin_frame/plugin_factory.h"
#include "src/plugin_frame/plugin_id.h"
#include "src/qmf_msg.h"

namespace comm_access {

using WriteProxyPtr = com::tencent::comm_cache::CommCacheProxyPtr;
using WriteRequest = com::tencent::comm_cache::WriteCacheNoCacheKeyRequest;
using WriteResponse = com::tencent::comm_cache::WriteCacheNoCacheKeyResponse;

extern "C" void* qmf_anti_white_screen_plugin() {
  PluginParam param;
  param.id = kQmfAntiWhiteScreenPluginId;
  param.name = __FUNCTION__;
  param.priority = kQmfAntiWhiteScreenPluginPriority;
  param.proto = spp_rpc::PROTO_TYPE_QMF;
  param.enable = GetPluginStatus(__FUNCTION__);
  auto plugin = new comm_access::QmfAntiWhiteScreenPlugin(param);
  return plugin;
}

COMM_ACCESS_REGISTER_PLUGIN_FUNC(kQmfAntiWhiteScreenPluginId, qmf_anti_white_screen_plugin);

CacheMode QmfAntiWhiteScreenPlugin::GetCacheMode() {
  auto qmf_msg = dynamic_cast<QmfMsg*>(msg());
  if (!qmf_msg) {
    SPAN_ELOG(msg(), "dynamic_cast qmf_msg is null");
    return kNotCacheMode;
  }
  if (!qmf_msg->config()) {
    SPAN_ELOG(msg(), "qmf_msg config is null");
    return kNotCacheMode;
  }
  SPAN_DLOG(msg(), "cache_type:%d", qmf_msg->config()->cache_type);
  return qmf_msg->config()->cache_type;
}

int QmfAntiWhiteScreenPlugin::ReadCache(spp_rpc::Status* frame_status, int* logic_code) {
  SPAN_LOG_FUNCTION_START(msg());
  auto qmf_msg = dynamic_cast<QmfMsg*>(msg());
  SPAN_LOG_RET(msg(), !qmf_msg, "dynamic_cast qmf_msg is null");
  SPAN_LOG_RET(msg(), !qmf_msg->config(), "qmf_msg->config is null");
  SPAN_LOG_RET(msg(), !frame_status || !logic_code, "frame_status or logic_code is null");
  // 转发 L5路由
  auto prx = spp_rpc::GetServantProxy<spp_rpc::TrpcServantProxyPtr>(qmf_msg->GetServantName());
  prx->set_cur_func_name(qmf_msg->GetFuncName());
  SPAN_DLOG(msg(), "CommCache Read Server L5 modid:%d cmdid:%d cache_type:%d",
            qmf_msg->config()->cache_mod_id, qmf_msg->config()->cache_cmd_id,
            qmf_msg->config()->cache_type);
  prx->mutable_route_point()->SetL5(qmf_msg->config()->cache_mod_id,
                                    qmf_msg->config()->cache_cmd_id);
  prx->mutable_route_point()->SetTimeout(50);
  *frame_status =
      prx->InvokeTrpc2(*qmf_msg->mutable_req(), mutable_cache_rsp(), qmf_msg->context());
  *logic_code = cache_rsp().logic_header.ret() ? cache_rsp().logic_header.ret()
                                               : cache_rsp().logic_header.func_ret();
  SPAN_TLOG(msg(), "read cache proxy %s%s, frame_status:%d, logic_code:%d",
            qmf_msg->GetServantName().c_str(), qmf_msg->GetFuncName().c_str(),
            frame_status->GetOneCode(), *logic_code);
  SPAN_LOG_FUNCTION_END(msg());
  return 0;
}

int QmfAntiWhiteScreenPlugin::WriteCache(spp_rpc::Status* frame_status, int* logic_code) {
  SPAN_LOG_FUNCTION_START(msg());
  auto qmf_msg = dynamic_cast<QmfMsg*>(msg());
  SPAN_LOG_RET(msg(), !qmf_msg, "dynamic_cast qmf_msg is null");
  SPAN_LOG_RET(msg(), !qmf_msg->config(), "qmf_msg->config is null");
  SPAN_LOG_RET(msg(), !frame_status || !logic_code, "frame_status or logic_code is null");
  // 数据准备
  std::vector<char> request_buf;
  request_buf.clear();
  qmf_msg->req().Encode(&request_buf);
  std::vector<char> response_buf;
  response_buf.clear();
  qmf_msg->rsp().Encode(&response_buf);
  SPAN_TLOG(msg(), "request_buf size:%zd response_buf size:%zd", request_buf.size(),
            response_buf.size());
  // 调用写缓存接口
  auto prx = spp_rpc::GetServantProxy<WriteProxyPtr>("com.tencent.comm_cache.CommCache");
  SPAN_DLOG(msg(), "CommCache Write Server L5 modid:%d cmdid:%d cache_type:%d",
            qmf_msg->config()->cache_write_mod_id, qmf_msg->config()->cache_write_cmd_id,
            qmf_msg->config()->cache_type);
  prx->mutable_route_point()->SetL5(qmf_msg->config()->cache_write_mod_id,
                                    qmf_msg->config()->cache_write_cmd_id);
  prx->mutable_route_point()->SetTimeout(50);
  WriteRequest req;
  req.set_request(std::string(request_buf.begin(), request_buf.end()));
  req.set_response(std::string(response_buf.begin(), response_buf.end()));
  WriteResponse rsp;
  *frame_status = prx->WriteCacheNoCacheKey(req, &rsp, qmf_msg->context());
  *logic_code = rsp.result();
  SPAN_TLOG(msg(), "write cache proxy %s%s, frame_status:%d, logic_code:%d",
            qmf_msg->GetServantName().c_str(), qmf_msg->GetFuncName().c_str(),
            frame_status->GetOneCode(), *logic_code);
  SPAN_LOG_FUNCTION_END(msg());
  return 0;
}

void QmfAntiWhiteScreenPlugin::OverrideRsp() {
  auto qmf_msg = dynamic_cast<QmfMsg*>(msg());
  if (!qmf_msg || !qmf_msg->mutable_rsp()) {
    SPAN_ELOG(msg(), "qms_msg or rsp is null");
    return;
  }
  *qmf_msg->mutable_rsp() = cache_rsp();
}

}  // namespace comm_access
