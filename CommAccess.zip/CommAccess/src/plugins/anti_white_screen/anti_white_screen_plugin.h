/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 防白屏插件抽象类。
 *
 */

#pragma once

#include <string>

#include "spp_rpc/status.h"
#include "src/comm/config.h"
#include "src/plugin_frame/plugin.h"

namespace comm_access {

class AntiWhiteScreenPlugin : public Plugin {
 public:
  explicit AntiWhiteScreenPlugin(const PluginParam& param) : Plugin(param) {}
  virtual ~AntiWhiteScreenPlugin() = default;
  virtual int Invoke();
  virtual CacheMode GetCacheMode() { return kNotCacheMode; }
  virtual int ReadCache(spp_rpc::Status* frame_status, int* logic_code) = 0;
  virtual int WriteCache(spp_rpc::Status* frame_status, int* logic_code) = 0;
  virtual void OverrideRsp() = 0;

 protected:
  spp_rpc::SppRpcBaseMsg* msg_{nullptr};
};

}  // namespace comm_access
