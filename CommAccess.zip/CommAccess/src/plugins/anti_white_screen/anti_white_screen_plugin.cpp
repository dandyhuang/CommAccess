/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 防白屏插件抽象类。
 *
 */

#include "src/plugins/anti_white_screen/anti_white_screen_plugin.h"

#include <string>
#include <utility>

#include "spp_rpc/common/logger/logger_interface.h"

namespace comm_access {

int AntiWhiteScreenPlugin::Invoke() {
  SPAN_LOG_FUNCTION_START(msg());
  auto cache_mode = GetCacheMode();
  SPAN_DLOG(msg(), "GetCacheMode ret:%d", cache_mode);
  // 此callee+func没配置兜底不需要往下走
  if (cache_mode != kAntiWhiteScreenMode) {
    return kOk;
  }

  spp_rpc::Status frame_status;
  int logic_code{0};
  SPAN_TLOG(msg(), "Proxy frame_error_code:%d logic_error_code:%d", msg()->frame_error_code(),
            msg()->logic_error_code());
  if (msg()->frame_error_code() || msg()->logic_error_code()) {
    // 前面proxy插件返回失败且从cache获取成功则把返回码改成正确和回包覆盖一下
    if (ReadCache(&frame_status, &logic_code)) {
      SPAN_ELOG(msg(), "ReadCache err");
      return kFailedContinue;
    }
    if (frame_status.GetOneCode() || logic_code) {
      SPAN_ELOG(msg(), "ReadCache err frame_code:%d logic_code:%d", frame_status.GetOneCode(),
                logic_code);
      return kFailedContinue;
    } else {
      msg()->set_frame_error_code(frame_status.GetOneCode());
      msg()->set_logic_error_code(logic_code);
      OverrideRsp();
    }
    SPAN_TLOG(msg(), "Invoke read cache");
  } else {
    // 前面proxy插件返回成功则提前回包再回写cache
    msg()->ResponseImp(msg()->frame_error_code(), msg()->logic_error_code());
    if (WriteCache(&frame_status, &logic_code)) {
      SPAN_ELOG(msg(), "WriteCache err");
      return kFailedContinue;
    }
    if (frame_status.GetOneCode() || logic_code) {
      SPAN_ELOG(msg(), "WriteCache err frame_code:%d logic_code:%d", frame_status.GetOneCode(),
                logic_code);
      return kFailedContinue;
    }
    SPAN_TLOG(msg(), "Invoke write cache");
  }

  SPAN_DLOG(msg(), "Invoke frame_error_code:%d logic_error_code:%d", msg()->frame_error_code(),
            msg()->logic_error_code());
  SPAN_LOG_FUNCTION_END(msg());
  return kOk;
}

}  // namespace comm_access
