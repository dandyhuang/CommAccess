// Copyright 2020 Tencent authors.

#pragma once

#include "src/plugin_frame/plugin.h"
#include "src/qmf_msg.h"

namespace comm_access {

extern "C" void* qmf_check_security_plugin();

class QmfCheckSecurityPlugin : public Plugin {
 public:
  explicit QmfCheckSecurityPlugin(const PluginParam& param) : Plugin(param) {}
  virtual ~QmfCheckSecurityPlugin() = default;
  virtual int Invoke();
};
}  // namespace comm_access
