//  Copyright 2020 Tencent authors.

#include "src/plugins/check_security/qmf_check_security_plugin.h"

#include <string>

#include "common_security_pb/proto/comm_security_mock.spp_rpc.pb.h"
#include "gmock/gmock.h"
#include "gtest/gtest.h"
#include "spp_rpc/client/servant_proxy_factory.h"
#include "src/comm/config.h"
#include "src/plugin_frame/plugin.h"
#include "src/qmf_msg.h"

using com::tencent::spp_rpc::CommAcc::common_security_pb::CheckUserSecurityReply;    // NOLINT
using com::tencent::spp_rpc::CommAcc::common_security_pb::CheckUserSecurityRequest;  // NOLINT
using com::tencent::spp_rpc::CommAcc::common_security_pb::MockSecurityProxy;         // NOLINT
using com::tencent::spp_rpc::CommAcc::common_security_pb::SecurityProxy;

/**
 * 1. 未打开防水墙开关 -> 返回ok, 不改变框架错误码 frame_error_code
 * 2. 打开防水墙开关 -> 请求防水墙
 * 3. 打开防水墙开关, 防水墙请求正常(status(0)), 返回对应错误码段(ret :
 * 15026-15031) -> ret, safe_result, user_info
 * 4. 打开防水墙开关, 防水墙请求异常(status(-3), status(-4) 等) -> 插件返回ok,
 * 不设置错误码, 继续下游逻辑
 */

/**
 * @case_name QmfCheckSecurityPlugin.Case1_NoConfig_CheckSecurity_P0
 * @priority P0
 * @brief water_flag != 1场景，不调用后端防水墙api
 */
TEST(QmfCheckSecurityPlugin, Case1_NoConfig_CheckSecurity_P0) {
  auto plugin = reinterpret_cast<comm_access::QmfCheckSecurityPlugin*>(
      comm_access::qmf_check_security_plugin());
  auto qmf_msg = dynamic_cast<comm_access::QmfMsg*>(comm_access::QmfMsgCreater());
  comm_access::WuJiConfig config;
  qmf_msg->set_config(config);
  plugin->set_msg(qmf_msg);

  ::testing::MockFunction<::spp_rpc::ServantProxy*(const std::string&, uint32_t set_id)> mock_func;
  spp_rpc::ServantProxyFactorySingleton::getInstance()->set_func(mock_func.AsStdFunction());
  EXPECT_CALL(mock_func, Call(::testing::_, 0)).Times(0);
  EXPECT_EQ(plugin->Invoke(), comm_access::kOk);
  EXPECT_EQ(qmf_msg->frame_error_code(), 0);
}

void CheckSecurityRetNoZero(const com::tencent::qqlive::protocol::pb::RequestHead& qqlive_head,
                            int error_code, int user_safe_type, std::string safe_result, int result,
                            int invoke_ret, int frame_error_code) {
  auto mock_security_proxy = new MockSecurityProxy;
  EXPECT_CALL(*mock_security_proxy,
              CheckUserSecurity(::testing::An<const CheckUserSecurityRequest&>(),
                                ::testing::An<CheckUserSecurityReply*>(),
                                ::testing::An<::spp_rpc::ServantContextPtr>()))
      .Times(1)
      .WillOnce([&](const CheckUserSecurityRequest& request, CheckUserSecurityReply* response,
                    ::spp_rpc::ServantContextPtr context) {
        auto trpc_msg = dynamic_cast<::spp_rpc::TrpcMsg*>(context->msg());
        if (!trpc_msg->GetVideoMutableReqHead()->has_safe_info()) {
          response->set_ret(15032);
        } else {
          response->set_safe_result(safe_result);
          response->set_ret(error_code);
          response->set_user_safe_type(user_safe_type);
        }
        mock_security_proxy->SetResult(result);
        return ::spp_rpc::Status(0);
      });
  ::testing::MockFunction<::spp_rpc::ServantProxy*(const std::string&, uint32_t set_id)> mock_func;
  spp_rpc::ServantProxyFactorySingleton::getInstance()->set_func(mock_func.AsStdFunction());
  // 当获取com.tencent.spp_rpc2.RpcHello2的proxy时，mock这个proxy
  EXPECT_CALL(mock_func, Call(mock_security_proxy->GetDefaultServantName(), 0))
      .WillOnce(::testing::Return(mock_security_proxy));

  auto plugin = reinterpret_cast<comm_access::QmfCheckSecurityPlugin*>(
      comm_access::qmf_check_security_plugin());
  auto qmf_msg = dynamic_cast<comm_access::QmfMsg*>(comm_access::QmfMsgCreater());
  comm_access::WuJiConfig config;
  config.water_flag = 1;
  qmf_msg->set_config(config);
  qmf_msg->mutable_video_req()->logic_header = qqlive_head;
  plugin->set_msg(qmf_msg);
  EXPECT_EQ(plugin->Invoke(), invoke_ret);
  EXPECT_EQ(qmf_msg->security_rsp().safe_result(), safe_result);
  EXPECT_EQ(qmf_msg->security_rsp().user_safe_type(), user_safe_type);
  EXPECT_EQ(qmf_msg->frame_error_code(), frame_error_code);
  EXPECT_EQ(qmf_msg->security_rsp().ret(), error_code);

  if (!result) {
    auto extra_request_head = qmf_msg->GetVideoMutableReqHead()->mutable_extra_request_head();
    ASSERT_NE(extra_request_head, nullptr);
    EXPECT_EQ((*extra_request_head)["user_safe_type"], std::to_string(user_safe_type));
  }
}

void CheckSecurityRetNoZero(int error_code, int user_safe_type, std::string safe_result, int result,
                            int invoke_ret, int frame_error_code) {
  com::tencent::qqlive::protocol::pb::RequestHead qqlive_head;
  qqlive_head.mutable_safe_info()->set_type(3);
  qqlive_head.mutable_safe_info()->set_safe_key("safe_key_test");
  CheckSecurityRetNoZero(qqlive_head, error_code, user_safe_type, safe_result, result, invoke_ret,
                         frame_error_code);
}

/**
 * @case_name QmfCheckSecurityPlugin.Case2_CheckSecurity_P0
 * @priority P0
 * @brief water_flag == 1场景，调用后端防水墙api, 返回错误码非0
 */
TEST(QmfCheckSecurityPlugin, Case2_CheckSecurity_P0) {
  int error_code = 15030;
  CheckSecurityRetNoZero(error_code, 8, "safe_result_mock", 0, comm_access::kFailedEnd, error_code);
}

/**
 * @case_name QmfCheckSecurityPlugin.Case3_CheckSecurity_P0
 * @priority P0
 * @brief water_flag == 1场景，调用后端防水墙api, 返回15030, 透传safe_result
 */
TEST(QmfCheckSecurityPlugin, Case3_CheckSecurity_P0) {
  int error_code = 15030;
  CheckSecurityRetNoZero(error_code, 8, "safe_result_mock", 0, comm_access::kFailedEnd, error_code);
}

/**
 * @case_name QmfCheckSecurityPlugin.Case4_CheckSecurity_P0
 * @priority P0
 * @brief water_flag == 1场景，调用后端防水墙api,
 *  请求失败, 返回ok, 透传字段
 */
TEST(QmfCheckSecurityPlugin, Case4_CheckSecurity_P0) {
  CheckSecurityRetNoZero(100, 8, "safe_result_mock", -3, comm_access::kFailedContinue, 0);
}

/**
 * @case_name QmfCheckSecurityPlugin.Case5_CheckSecurity_P0
 * @priority P0
 * @brief water_flag == 1场景，调用后端防水墙api,
 *  没有带qqlive_head中的safe_info, 返回15032, 不透传
 */
TEST(QmfCheckSecurityPlugin, Case5_CheckSecurity_P0) {
  com::tencent::qqlive::protocol::pb::RequestHead qqlive_head;
  CheckSecurityRetNoZero(qqlive_head, 15032, 0, "", 0, comm_access::kFailedEnd, 15032);
}

/**
 * @case_name QmfCheckSecurityPlugin.Case6_CheckSecurity_P0
 * @priority P0
 * @brief water_flag == 1场景，调用后端防水墙api, 返回错误码非0
 */
TEST(QmfCheckSecurityPlugin, Case6_CheckSecurity_P0) {
  int error_code = 15030;
  CheckSecurityRetNoZero(error_code, 8, "safe_result_mock", 0, comm_access::kFailedEnd, error_code);
}

/**
 * @case_name QmfCheckSecurityPlugin.Case7_CheckSecurity_P0
 * @priority P0
 * @brief water_flag == 1场景，调用后端防水墙api, 返回错误码为0
 */
TEST(QmfCheckSecurityPlugin, Case7_CheckSecurity_P0) {
  int error_code = 0;
  CheckSecurityRetNoZero(error_code, 8, "safe_result_mock", 0, comm_access::kOk, error_code);
}
