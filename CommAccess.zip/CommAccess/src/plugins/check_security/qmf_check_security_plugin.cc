/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 青少年插件。
 *
 */

#include "src/plugins/check_security/qmf_check_security_plugin.h"

#include <string>
#include <utility>
#include <vector>

#include "common_security_pb/proto/comm_security.spp_rpc.pb.h"
#include "spp_rpc/client/servant_proxy_factory.h"
#include "spp_rpc/common/logger/logger_interface.h"
#include "src/comm/config.h"
#include "src/plugin_frame/plugin_factory.h"
#include "src/plugin_frame/plugin_id.h"
#include "src/qmf_msg.h"
using com::tencent::spp_rpc::CommAcc::common_security_pb::SecurityProxyPtr;

namespace comm_access {

extern "C" void* qmf_check_security_plugin() {
  PluginParam param;
  param.id = kQmfCheckSecurityPluginId;
  param.name = __FUNCTION__;
  param.priority = kQmfCheckSecurityPluginPriority;
  param.proto = spp_rpc::PROTO_TYPE_QMF;
  param.enable = GetPluginStatus(__FUNCTION__);
  auto plugin = new comm_access::QmfCheckSecurityPlugin(param);
  return plugin;
}

COMM_ACCESS_REGISTER_PLUGIN_FUNC(kQmfCheckSecurityPluginId, qmf_check_security_plugin);

int QmfCheckSecurityPlugin::Invoke() {
  SPAN_LOG_FUNCTION_START(msg());
  auto qmf_msg = dynamic_cast<QmfMsg*>(msg());
  if (!qmf_msg) {
    SPAN_ELOG(msg(), "dynamic_cast qmf_msg is null");
    return kFailedContinue;
  }
  if (qmf_msg->config() && qmf_msg->config()->water_flag == 1) {
    com::tencent::spp_rpc::CommAcc ::common_security_pb::CheckUserSecurityRequest req;
    spp_rpc::TrpcMsg trpc_msg;
    std::string& qqlive_head =
        (*trpc_msg.mutable_req()->logic_header.mutable_trans_info())["qqlive_head"];
    qmf_msg->GetVideoMutableReqHead()->SerializeToString(&qqlive_head);
    auto prx = spp_rpc::GetServantProxy<SecurityProxyPtr>();
    auto status = prx->CheckUserSecurity(req, qmf_msg->mutable_security_rsp(), trpc_msg.context());
    if (prx->GetResult()) {
      // 请求防水墙失败, 不作拦截
      SPAN_ELOG(msg(), "check security error:%d", prx->GetResult());
      return kFailedContinue;
    }
    RPC_DLOG("req:%s", req.DebugString().c_str());
    RPC_DLOG("rsp:%s", qmf_msg->security_rsp().DebugString().c_str());

    qmf_msg->GetVideoMutableReqHead()->mutable_extra_request_head()->insert(
        {"user_safe_type", std::to_string(qmf_msg->mutable_security_rsp()->user_safe_type())});
    if (qmf_msg->security_rsp().ret() != 0) {
      qmf_msg->set_frame_error_code(qmf_msg->security_rsp().ret());
      return kFailedEnd;
    }
  }

  SPAN_LOG_FUNCTION_END(msg());
  return kOk;
}

}  // namespace comm_access
