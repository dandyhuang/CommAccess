//  Copyright 2020 Tencent authors.

#define private public
#define protected public
#include "src/plugins/proxy/trpc_proxy_plugin_v2.h"

#include <string>

#include "gmock/gmock.h"
#include "gtest/gtest.h"
#include "spp_rpc/client/servant_proxy_factory.h"
#include "spp_rpc/client/trpc_servant_proxy.h"
#include "spp_rpc/client/trpc_servant_proxy_mock.h"
#include "src/config_frame/config_factory.h"
#include "src/configs/route/route_config.h"
#include "src/plugin_frame/plugin.h"
#include "src/trpc_comm_msg_v2.h"

void MockTrpcProxy(spp_rpc::MockTrpcServantProxy* mock_proxy, const int ret) {
  EXPECT_CALL(*mock_proxy, InvokeTrpc2(::testing::_, ::testing::_, ::testing::_))
      .Times(1)
      .WillOnce([ret](spp_rpc::TrpcRequestProtocol& req_proto,  // NOLINT
                      spp_rpc::TrpcResponseProtocol* rsp_proto,
                      const ::spp_rpc::ServantContextPtr& context) {
        spp_rpc::Status status;
        status.set_frame_error_code(ret);
        return status;
      });

  static ::testing::MockFunction<::spp_rpc::ServantProxy*(const std::string&, uint32_t set_id)>
      mock_func;
  // 当获取com.tencent.spp_rpc2.RpcHello2的proxy时，mock这个proxy
  EXPECT_CALL(mock_func, Call("callee_xxxxxx", 0)).WillOnce(::testing::Return(mock_proxy));
  spp_rpc::ServantProxyFactorySingleton::getInstance()->set_func(mock_func.AsStdFunction());
}

/**
 * @case_name QmfProxyPlugin.Case1_Proxy_P0
 * @priority P0
 * @brief 代理返回成功
 */
TEST(TrpcProxyPluginV2, Case1_Proxy_P0) {
  auto updater =
      comm_access::NewConfigUpdater<comm_access::TrpcRouteConfigParser, comm_access::RouteConfig>(
          "route_config_id");
  auto updater_ptr =
      comm_access::ConfigUpdaterPtr(reinterpret_cast<comm_access::ConfigUpdater*>(updater));
  INS_CONFIG_MGR->AddConfigUpdater(1, updater_ptr);
  auto mock_trpc_servant_proxy = new spp_rpc::MockTrpcServantProxy;
  MockTrpcProxy(mock_trpc_servant_proxy, 0);
  auto plugin =
      reinterpret_cast<comm_access::TrpcProxyPluginV2*>(comm_access::trpc_proxy_plugin_v2());
  auto trpc_msg = dynamic_cast<comm_access::TrpcCommMsgV2*>(comm_access::TpcCommMsgV2Creater());
  trpc_msg->mutable_req()->logic_header.set_callee("callee_xxxxxx");
  plugin->set_msg(trpc_msg);
  EXPECT_EQ(plugin->Invoke(), comm_access::kOk);
  delete (mock_trpc_servant_proxy);
}

/**
 * @case_name QmfProxyPlugin.Case2_Proxy_P0
 * @priority P0
 * @brief 代理返回失败
 */
TEST(TrpcProxyPluginV2, Case2_Proxy_P0) {
  auto updater =
      comm_access::NewConfigUpdater<comm_access::TrpcRouteConfigParser, comm_access::RouteConfig>(
          "route_config_id");
  auto updater_ptr =
      comm_access::ConfigUpdaterPtr(reinterpret_cast<comm_access::ConfigUpdater*>(updater));
  INS_CONFIG_MGR->AddConfigUpdater(1, updater_ptr);
  auto mock_trpc_servant_proxy = new spp_rpc::MockTrpcServantProxy;
  MockTrpcProxy(mock_trpc_servant_proxy, 1);
  auto plugin =
      reinterpret_cast<comm_access::TrpcProxyPluginV2*>(comm_access::trpc_proxy_plugin_v2());
  auto qmf_msg = dynamic_cast<comm_access::TrpcCommMsgV2*>(comm_access::TpcCommMsgV2Creater());
  qmf_msg->mutable_req()->logic_header.set_callee("callee_xxxxxx");
  plugin->set_msg(qmf_msg);
  EXPECT_EQ(plugin->Invoke(), comm_access::kFailedContinue);
}
