//  Copyright 2020 Tencent authors.

#include "src/plugins/proxy/trpc_proxy_plugin.h"

#include <string>

#include "gmock/gmock.h"
#include "gtest/gtest.h"
#include "spp_rpc/client/binary_proxy_mock.h"
#include "spp_rpc/client/servant_proxy_factory.h"
#include "src/comm/config.h"
#include "src/plugin_frame/plugin.h"
#include "src/trpc_comm_msg.h"

void MockBianryProxy(spp_rpc::MockBianryRpcProxy* mock_proxy, const int ret) {
  if (!mock_proxy) {
    return;
  }
  EXPECT_CALL(*mock_proxy, Exec(::testing::_, ::testing::_, ::testing::_, ::testing::_,
                                ::testing::_, ::testing::_))
      .Times(1)
      .WillRepeatedly(::testing::Return(ret));
  static ::testing::MockFunction<::spp_rpc::ServantProxy*(const std::string&, uint32_t set_id)>
      mock_func;
  // 当获取com.tencent.spp_rpc2.RpcHello2的proxy时，mock这个proxy
  EXPECT_CALL(mock_func, Call("callee_xxxxxx", 0)).WillOnce(::testing::Return(mock_proxy));
  spp_rpc::ServantProxyFactorySingleton::getInstance()->set_func(mock_func.AsStdFunction());
}

/**
 * @case_name TrpcProxyPlugin.Case1_Proxy_P0
 * @priority P0
 * @brief 代理返回成功
 */
TEST(TrpcProxyPlugin, Case1_Proxy_P0) {
  auto mock_binary_rpc_proxy = new spp_rpc::MockBianryRpcProxy;
  MockBianryProxy(mock_binary_rpc_proxy, 0);
  auto plugin = reinterpret_cast<comm_access::TrpcProxyPlugin*>(comm_access::trpc_proxy_plugin());
  auto trpc_msg = dynamic_cast<comm_access::TrpcCommMsg*>(comm_access::TpcCommMsgCreater());
  trpc_msg->mutable_req()->logic_header.set_callee("callee_xxxxxx");
  plugin->set_msg(trpc_msg);
  EXPECT_EQ(plugin->Invoke(), comm_access::kOk);
  delete (mock_binary_rpc_proxy);
}

/**
 * @case_name TrpcProxyPlugin.Case2_Proxy_P0
 * @priority P0
 * @brief 代理返回失败
 */
TEST(TrpcProxyPlugin, Case2_Proxy_P0) {
  auto mock_binary_rpc_proxy = new spp_rpc::MockBianryRpcProxy;
  MockBianryProxy(mock_binary_rpc_proxy, 1);
  auto plugin = reinterpret_cast<comm_access::TrpcProxyPlugin*>(comm_access::trpc_proxy_plugin());
  auto trpc_msg = dynamic_cast<comm_access::TrpcCommMsg*>(comm_access::TpcCommMsgCreater());
  trpc_msg->mutable_req()->logic_header.set_callee("callee_xxxxxx");
  plugin->set_msg(trpc_msg);
  EXPECT_EQ(plugin->Invoke(), comm_access::kFailedContinue);
}