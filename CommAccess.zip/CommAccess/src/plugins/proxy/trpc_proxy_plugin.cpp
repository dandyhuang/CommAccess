/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 转发插件。
 *
 */

#include "src/plugins/proxy/trpc_proxy_plugin.h"

#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "spp_rpc/client/binary_proxy.h"
#include "spp_rpc/client/trpc_servant_proxy.h"
#include "spp_rpc/common/env.h"
#include "spp_rpc/common/logger/logger_interface.h"
#include "spp_rpc/spp_rpc.h"
#include "src/comm/config.h"
#include "src/comm/util.h"
#include "src/config_frame/config_factory.h"
#include "src/configs/route/route_config.h"
#include "src/plugin_frame/plugin_factory.h"
#include "src/plugin_frame/plugin_id.h"
#include "src/trpc_comm_msg.h"

namespace comm_access {

extern "C" void* trpc_proxy_plugin() {
  PluginParam param;
  param.id = kTrpcProxyPluginId;
  param.name = __FUNCTION__;
  param.priority = kTrpcProxyPluginPriority;
  param.proto = spp_rpc::PROTO_TYPE_TRPC;
  param.enable = GetPluginStatus(__FUNCTION__);
  auto plugin = new comm_access::TrpcProxyPlugin(param);
  return plugin;
}

// 把插件注册函数注册到框架
COMM_ACCESS_REGISTER_PLUGIN_FUNC(kTrpcProxyPluginId, trpc_proxy_plugin);

int TrpcProxyPlugin::Invoke() {
  SPAN_LOG_FUNCTION_START(msg());
  auto trpc_msg = dynamic_cast<TrpcCommMsg*>(msg());
  if (!trpc_msg) {
    SPAN_ELOG(msg(), "dynamic_cast trpc_msg is null");
    return kFailedContinue;
  }

  auto ptr =
      spp_rpc::GetServantProxy<spp_rpc::BinaryRpcProxyPtr>(trpc_msg->req().logic_header.callee());
  if (INS_TOOLS->refactor_version()) {
    const std::string& appid =
        trpc_msg->GetCallerId() != "" ? trpc_msg->GetCallerId() : INS_CONFIG_MGR->appid();
    std::string c_key =
        GetRouteConfigKey(ACCESS_TRPC_TYPE, appid, trpc_msg->req().logic_header.callee(),
                          trpc_msg->req().logic_header.func());
    RPC_DLOG("key:%s", c_key.c_str());

    auto route_info = INS_CONFIG_MGR->config<RouteConfig>(kTrpcRouteConfigId, c_key, true);
    SetRouteInfo(ptr, *route_info, trpc_msg->req().logic_header.callee());
  } else {
    RouteInfo r_info;
    if (trpc_msg && trpc_msg->config()) {
      SPAN_DLOG(trpc_msg, "route_flag:%d,", trpc_msg->config()->route_flag);
      comm_access::GetRoute(*trpc_msg->config(), &r_info, trpc_msg->req().logic_header.callee(),
                            ptr);
      SPAN_DLOG(trpc_msg, "r_info:type[%d],name[%s],service_name[%s],namespace[%s],meta:[%zd]",
                r_info.type, r_info.name.c_str(), r_info.service_name.c_str(),
                r_info.service_namespace.c_str(), r_info.metadata.size());
      SetRoute(ptr, r_info);
    }
  }
  if (!spp_rpc::IsOnline()) {
    auto it = trpc_msg->req().logic_header.trans_info().find("trpc-env");
    if (it != trpc_msg->req().logic_header.trans_info().end()) {
      RPC_TLOG("set polaris env trans_info: %s", it->second.c_str());
      ptr->mutable_route_point()->SetPolarisEnvTransInfo(it->second);
    }
  }

  ptr->set_cur_func_name(trpc_msg->req().logic_header.func());
  std::vector<char> req_buff;
  spp_rpc::EncodeTrpcProtocol(&req_buff, trpc_msg->req().frame_header, trpc_msg->req().logic_header,
                              trpc_msg->body(), trpc_msg->body_len());
  char* rsp = nullptr;
  size_t rsp_size = 0;
  int frame_error_code =
      ptr->Exec(req_buff.data(), req_buff.size(), &rsp, &rsp_size, spp_rpc::CheckTrpcPacket);
  if (frame_error_code) {
    SPAN_ELOG(msg(), "ptr error|ret:%d", frame_error_code);
    return kFailedContinue;
  }
  trpc_msg->set_proxy_ptr(ptr);
  trpc_msg->set_rsp(rsp);
  trpc_msg->set_rsp_size(rsp_size);
  SPAN_LOG_FUNCTION_END(msg());
  return kOk;
}

}  // namespace comm_access
