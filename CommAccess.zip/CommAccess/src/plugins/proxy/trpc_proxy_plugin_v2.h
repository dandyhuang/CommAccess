/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 转发插件。
 *
 */

#pragma once

#include "src/plugin_frame/plugin.h"

namespace comm_access {

class TrpcProxyPluginV2 : public Plugin {
 public:
  explicit TrpcProxyPluginV2(const PluginParam& param) : Plugin(param) {}
  virtual ~TrpcProxyPluginV2() = default;
  virtual int Invoke();
};

extern "C" void* trpc_proxy_plugin_v2();

}  // namespace comm_access
