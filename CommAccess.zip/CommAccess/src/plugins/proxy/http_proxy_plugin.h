/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 转发插件。
 *
 */

#pragma once

#include "src/http_comm_msg.h"
#include "src/plugin_frame/plugin.h"

namespace comm_access {
class HttpProxyPlugin : public Plugin {
 public:
  explicit HttpProxyPlugin(const PluginParam &param) : Plugin(param) {}
  virtual ~HttpProxyPlugin() = default;
  virtual int Invoke();
};
extern "C" void *http_proxy_plugin();
}  // namespace comm_access
