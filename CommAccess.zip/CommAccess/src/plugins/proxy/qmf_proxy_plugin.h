/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 转发插件。
 *
 */

#pragma once

#include "spp_rpc/client/trpc_servant_proxy.h"
#include "src/plugin_frame/plugin.h"
#include "src/qmf_msg.h"

namespace comm_access {

class QmfProxyPlugin : public Plugin {
 public:
  explicit QmfProxyPlugin(const PluginParam& param) : Plugin(param) {}
  virtual ~QmfProxyPlugin() = default;
  virtual int Invoke();

 private:
  void EncodeQQlive(QmfMsg* qmf_msg);
  void SetPoliarisMeta(QmfMsg* qmf_msg, spp_rpc::TrpcServantProxyPtr proxy);
};

extern "C" void* qmf_proxy_plugin();

}  // namespace comm_access
