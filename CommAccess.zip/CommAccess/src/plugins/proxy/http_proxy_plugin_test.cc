

//

//  Copyright 2020 Tencent authors.

#include "src/plugins/proxy/http_proxy_plugin.h"

#include <string>

#include "gmock/gmock.h"
#include "gtest/gtest.h"
#include "spp_rpc/client/http_proxy_mock.h"
#include "spp_rpc/client/servant_proxy_factory.h"
#include "src/comm/config.h"
#include "src/http_comm_msg.h"
#include "src/plugin_frame/plugin.h"

void MockBianryProxy(spp_rpc::MockHttpRpcProxy* mock_proxy, const int ret) {
  if (!mock_proxy) {
    return;
  }
  EXPECT_CALL(*mock_proxy, AccessHttp(::testing::_, ::testing::_, ::testing::_))
      .Times(1)
      .WillRepeatedly(::testing::Return(ret));
  static ::testing::MockFunction<::spp_rpc::ServantProxy*(const std::string&, uint32_t set_id)>
      mock_func;
  // 当获取com.tencent.spp_rpc2.RpcHello2的proxy时，mock这个proxy
  EXPECT_CALL(mock_func, Call(::testing::_, 0)).WillRepeatedly(::testing::Return(mock_proxy));
  spp_rpc::ServantProxyFactorySingleton::getInstance()->set_func(mock_func.AsStdFunction());
}

/**
 * @case_name HttpProxyPlugin.Case1_Proxy_P0
 * @priority P0
 * @brief 代理返回成功
 */
TEST(HttpProxyPlugin, Case1_Http_Plugin_Proxy_Test_P0) {
  auto mock_binary_rpc_proxy = new spp_rpc::MockHttpRpcProxy;
  MockBianryProxy(mock_binary_rpc_proxy, 0);
  auto plugin = reinterpret_cast<comm_access::HttpProxyPlugin*>(comm_access::http_proxy_plugin());
  auto http_msg = dynamic_cast<comm_access::HttpCommMsg*>(comm_access::HttpCommMsgCreater());
  plugin->set_msg(http_msg);
  comm_access::WuJiConfig config;
  http_msg->set_config(config);
  EXPECT_EQ(plugin->Invoke(), comm_access::kOk);
}

/**
 * @case_name HttpProxyPlugin.Case2_Proxy_P0
 * @priority P0
 * @brief 代理返回失败
 */
TEST(HttpProxyPlugin, Case2_Http_Plugin_Proxy_Test_P0) {
  auto mock_binary_rpc_proxy = new spp_rpc::MockHttpRpcProxy;
  MockBianryProxy(mock_binary_rpc_proxy, 1);
  auto plugin = reinterpret_cast<comm_access::HttpProxyPlugin*>(comm_access::http_proxy_plugin());
  auto http_msg = dynamic_cast<comm_access::HttpCommMsg*>(comm_access::HttpCommMsgCreater());
  plugin->set_msg(http_msg);
  comm_access::WuJiConfig config;
  http_msg->set_config(config);
  EXPECT_EQ(plugin->Invoke(), comm_access::kFailedEnd);
}
