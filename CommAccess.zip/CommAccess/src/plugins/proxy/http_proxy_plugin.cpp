/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 转发插件。
 *
 */

#include "src/plugins/proxy/http_proxy_plugin.h"

#include <string>
#include <utility>
#include <vector>

#include "spp_rpc/client/binary_proxy.h"
#include "spp_rpc/client/trpc_servant_proxy.h"
#include "spp_rpc/common/logger/logger_interface.h"
#include "spp_rpc/spp_rpc.h"
#include "src/comm/config.h"
#include "src/comm/util.h"
#include "src/http_comm_msg.h"
#include "src/plugin_frame/plugin_factory.h"
#include "src/plugin_frame/plugin_id.h"

namespace comm_access {

extern "C" void* http_proxy_plugin() {
  PluginParam param;
  param.id = kHttpProxyPluginId;
  param.name = __FUNCTION__;
  param.priority = kHttpProxyPluginPriority;
  param.proto = spp_rpc::PROTO_TYPE_HTTP;
  param.enable = GetPluginStatus(__FUNCTION__);
  auto plugin = new comm_access::HttpProxyPlugin(param);
  return plugin;
}

// 把插件注册函数注册到框架
COMM_ACCESS_REGISTER_PLUGIN_FUNC(kHttpProxyPluginId, http_proxy_plugin);

int HttpProxyPlugin::Invoke() {
  SPAN_LOG_FUNCTION_START(msg());
  auto http_msg = dynamic_cast<HttpCommMsg*>(msg());
  if (!http_msg) {
    SPAN_ELOG(msg(), "dynamic_cast http_msg is null");
    return kFailedEnd;
  }

  const std::string& callee = http_msg->GetHttpCallee();
  auto proxy = spp_rpc::GetServantProxy<spp_rpc::HttpRpcProxyPtr>(callee);

  GetRoute(*http_msg->config(), &http_msg->GetRouteInfo(), callee, proxy);
  SetRoute(proxy, http_msg->GetRouteInfo(), "Http");

  tars::TC_HttpResponse* rsp = NULL;
  auto req = const_cast<tars::TC_HttpRequest*>(&(http_msg->req()));
  if (!http_msg->GetParam("origin").empty()) {
    proxy->set_check_status(false);
  }

  int frame_error_code = proxy->AccessHttp(*req, &rsp, http_msg->context());

  http_msg->set_frame_error_code(frame_error_code);
  http_msg->SetBusiIp(proxy->route_point().GetIp());
  if (rsp) {
    http_msg->set_rsp(*rsp);
  }

  if (frame_error_code) {
    SPAN_ELOG(msg(), "access http err:%d", frame_error_code);
    return kFailedEnd;
  }
  http_msg->set_frame_error_code(proxy->GetResult());
  http_msg->set_logic_error_code(0);
  return kOk;
}

}  // namespace comm_access
