/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 转发插件。
 *
 */

#include "src/plugins/proxy/trpc_proxy_plugin_v2.h"

#include <memory>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

#include "spp_rpc/client/binary_proxy.h"
#include "spp_rpc/client/trpc_servant_proxy.h"
#include "spp_rpc/common/logger/logger_interface.h"
#include "spp_rpc/spp_rpc.h"
#include "src/comm/util.h"
#include "src/config_frame/config_factory.h"
#include "src/configs/route/route_config.h"
#include "src/plugin_frame/plugin_factory.h"
#include "src/plugin_frame/plugin_id.h"
#include "src/trpc_comm_msg_v2.h"

namespace comm_access {

extern "C" void* trpc_proxy_plugin_v2() {
  PluginParam param;
  param.id = kTrpcProxyPluginIdV2;
  param.name = __FUNCTION__;
  param.priority = kTrpcProxyPluginPriority;
  param.proto = spp_rpc::PROTO_TYPE_TRPC_V2 | spp_rpc::PROTO_TYPE_QMF_V2;
  param.enable = GetPluginStatus(__FUNCTION__);
  auto plugin = new comm_access::TrpcProxyPluginV2(param);
  return plugin;
}

// 把插件注册函数注册到框架
COMM_ACCESS_REGISTER_PLUGIN_FUNC(kTrpcProxyPluginIdV2, trpc_proxy_plugin_v2);

int TrpcProxyPluginV2::Invoke() {
  SPAN_LOG_FUNCTION_START(msg());
  auto trpc_msg = dynamic_cast<TrpcCommMsgV2*>(msg());
  if (!trpc_msg) {
    SPAN_ELOG(msg(), "dynamic_cast trpc_msg is null");
    return kFailedContinue;
  }
  auto prx =
      spp_rpc::GetServantProxy<spp_rpc::TrpcServantProxyPtr>(trpc_msg->req().logic_header.callee());
  const std::string& appid =
      trpc_msg->GetCallerId() != "" ? trpc_msg->GetCallerId() : INS_CONFIG_MGR->appid();
  const std::string callee = trpc_msg->req().logic_header.callee();
  const std::string func = trpc_msg->req().logic_header.func();
  std::string c_key = GetRouteConfigKey(ACCESS_TRPC_TYPE, appid, callee, func);
  RPC_DLOG("key:%s", c_key.c_str());

  auto route_info_v2 = INS_CONFIG_MGR->config<RouteConfig>(kTrpcRouteConfigId, c_key, true);
  SetRouteInfo(prx, *route_info_v2, trpc_msg->req().logic_header.callee());
  prx->set_cur_func_name(func);

  if (!spp_rpc::IsOnline()) {
    auto it = trpc_msg->req().logic_header.trans_info().find("trpc-env");
    if (it != trpc_msg->req().logic_header.trans_info().end()) {
      RPC_TLOG("set polaris env trans_info: %s", it->second.c_str());
      prx->mutable_route_point()->SetPolarisEnvTransInfo(it->second);
    }
  }

  auto status =
      prx->InvokeTrpc2(*trpc_msg->mutable_req(), trpc_msg->mutable_rsp(), trpc_msg->context());

  trpc_msg->set_frame_error_code(status.GetOneCode());
  if (status.GetOneCode()) {
    SPAN_ELOG(msg(), "InvokeTrpc2 err|err_code:%d", status.GetOneCode());
    return kFailedContinue;
  }

  trpc_msg->set_busi_remote_ip(prx->route_point().GetIp());
  trpc_msg->set_proxy_ptr(prx);
  trpc_msg->set_rsp_buf(prx->rsp_buf());
  trpc_msg->set_rsp_size(prx->rsp_len());
  SPAN_LOG_FUNCTION_END(msg());
  return kOk;
}
}  //  namespace comm_access
