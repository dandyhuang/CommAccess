//  Copyright 2020 Tencent authors.

#include "src/plugins/proxy/qmf_proxy_plugin.h"

#include <string>

#include "gmock/gmock.h"
#include "gtest/gtest.h"
#include "spp_rpc/client/servant_proxy_factory.h"
#include "spp_rpc/client/trpc_servant_proxy.h"
#include "spp_rpc/client/trpc_servant_proxy_mock.h"
#include "src/comm/config.h"
#include "src/plugin_frame/plugin.h"

void MockTrpcProxy(spp_rpc::MockTrpcServantProxy* mock_proxy, const int ret) {
  EXPECT_CALL(*mock_proxy, InvokeTrpc2(::testing::_, ::testing::_, ::testing::_))
      .Times(1)
      .WillOnce([ret](spp_rpc::TrpcRequestProtocol& req_proto,  // NOLINT
                      spp_rpc::TrpcResponseProtocol* rsp_proto,
                      const ::spp_rpc::ServantContextPtr& context) {
        spp_rpc::Status status;
        status.set_frame_error_code(ret);
        return status;
      });

  static ::testing::MockFunction<::spp_rpc::ServantProxy*(const std::string&, uint32_t set_id)>
      mock_func;
  // 当获取com.tencent.spp_rpc2.RpcHello2的proxy时，mock这个proxy
  EXPECT_CALL(mock_func, Call("callee_xxxxxx", 0)).WillOnce(::testing::Return(mock_proxy));
  spp_rpc::ServantProxyFactorySingleton::getInstance()->set_func(mock_func.AsStdFunction());
}

/**
 * @case_name QmfProxyPlugin.Case1_Proxy_P0
 * @priority P0
 * @brief 代理返回成功
 */
TEST(QmfProxyPlugin, Case1_Proxy_P0) {
  auto mock_trpc_servant_proxy = new spp_rpc::MockTrpcServantProxy;
  MockTrpcProxy(mock_trpc_servant_proxy, 0);
  auto plugin = reinterpret_cast<comm_access::QmfProxyPlugin*>(comm_access::qmf_proxy_plugin());
  auto qmf_msg = dynamic_cast<comm_access::QmfMsg*>(comm_access::QmfMsgCreater());
  comm_access::WuJiConfig config;
  qmf_msg->set_config(config);
  qmf_msg->mutable_req()->logic_header.set_callee("callee_xxxxxx");
  plugin->set_msg(qmf_msg);
  EXPECT_EQ(plugin->Invoke(), comm_access::kOk);
}

/**
 * @case_name QmfProxyPlugin.Case2_Proxy_P0
 * @priority P0
 * @brief 代理返回失败
 */
TEST(QmfProxyPlugin, Case2_Proxy_P0) {
  auto mock_trpc_servant_proxy = new spp_rpc::MockTrpcServantProxy;
  MockTrpcProxy(mock_trpc_servant_proxy, 1);
  auto plugin = reinterpret_cast<comm_access::QmfProxyPlugin*>(comm_access::qmf_proxy_plugin());
  auto qmf_msg = dynamic_cast<comm_access::QmfMsg*>(comm_access::QmfMsgCreater());
  comm_access::WuJiConfig config;
  qmf_msg->set_config(config);
  qmf_msg->mutable_req()->logic_header.set_callee("callee_xxxxxx");
  plugin->set_msg(qmf_msg);
  EXPECT_EQ(plugin->Invoke(), comm_access::kFailedContinue);
}

/**
 * @case_name QmfProxyPlugin.Case3_Proxy_P0
 * @priority P0
 * @brief 为重试请求，且在无极已配置了强制关闭重试
 */
TEST(QmfProxyPlugin, Case3_Proxy_P0) {
  auto plugin = reinterpret_cast<comm_access::QmfProxyPlugin*>(comm_access::qmf_proxy_plugin());
  auto qmf_msg = dynamic_cast<comm_access::QmfMsg*>(comm_access::QmfMsgCreater());
  qmf_msg->mutable_req()->logic_header.set_callee("callee_xxxxxx");

  // 为重试请求
  qmf_msg->mutable_video_req()->logic_header.mutable_flag_info()->set_auto_retry_flag(1);

  // 在无极已配置了强制关闭重试
  comm_access::WuJiConfig config;
  config.close_retry = true;
  qmf_msg->set_config(config);

  plugin->set_msg(qmf_msg);
  EXPECT_EQ(plugin->Invoke(), comm_access::kFailedEnd);
}

/**
 * @case_name QmfProxyPlugin.Case4_Proxy_P0
 * @priority P0
 * @brief 为重试请求，在无极未配置强制关闭重试
 */
TEST(QmfProxyPlugin, Case4_Proxy_P0) {
  auto mock_trpc_servant_proxy = new spp_rpc::MockTrpcServantProxy;
  MockTrpcProxy(mock_trpc_servant_proxy, 0);

  auto plugin = reinterpret_cast<comm_access::QmfProxyPlugin*>(comm_access::qmf_proxy_plugin());
  auto qmf_msg = dynamic_cast<comm_access::QmfMsg*>(comm_access::QmfMsgCreater());
  qmf_msg->mutable_req()->logic_header.set_callee("callee_xxxxxx");

  // 为重试请求
  qmf_msg->mutable_video_req()->logic_header.mutable_flag_info()->set_auto_retry_flag(1);

  // 在无极未配置强制关闭重试
  comm_access::WuJiConfig config;
  config.close_retry = false;
  qmf_msg->set_config(config);

  plugin->set_msg(qmf_msg);
  EXPECT_EQ(plugin->Invoke(), comm_access::kOk);
}

/**
 * @case_name QmfProxyPlugin.Case5_Proxy_P0
 * @priority P0
 * @brief 下游服务设置了qqlive_rsp_head
 */
TEST(QmfProxyPlugin, Case5_Proxy_P0) {
  auto mock_trpc_servant_proxy = new spp_rpc::MockTrpcServantProxy;
  MockTrpcProxy(mock_trpc_servant_proxy, 0);

  auto plugin = reinterpret_cast<comm_access::QmfProxyPlugin*>(comm_access::qmf_proxy_plugin());
  auto qmf_msg = dynamic_cast<comm_access::QmfMsg*>(comm_access::QmfMsgCreater());
  qmf_msg->mutable_req()->logic_header.set_callee("callee_xxxxxx");

  comm_access::WuJiConfig config;
  qmf_msg->set_config(config);

  // 模拟下游服务设置qqlive_rsp_head
  std::string qqlive_rsp_head = "qqlive_rsp_head example";
  (*qmf_msg->mutable_rsp()->logic_header.mutable_trans_info())["qqlive_rsp_head"] = qqlive_rsp_head;

  plugin->set_msg(qmf_msg);
  EXPECT_EQ(plugin->Invoke(), comm_access::kOk);

  // TODO：这里怎么检查video_rsp中的信息？
  // 检查qqlive_rsp_head是否透传
  // EXPECT_GT(qmf_msg->mutable_video_rsp()->logic_header.field_count(), 0);
  // EXPECT_EQ(qmf_msg->mutable_video_rsp()->logic_header.field(0), qqlive_rsp_head);
}

/**
 * @case_name QmfProxyPlugin.Case6_Proxy_P0
 * @priority P0
 * @brief 请求超时，且在无极未配置强制关闭重试
 */
TEST(QmfProxyPlugin, Case6_Proxy_P0) {
  auto mock_trpc_servant_proxy = new spp_rpc::MockTrpcServantProxy;
  // 请求超时
  MockTrpcProxy(mock_trpc_servant_proxy, -3);

  auto plugin = reinterpret_cast<comm_access::QmfProxyPlugin*>(comm_access::qmf_proxy_plugin());
  auto qmf_msg = dynamic_cast<comm_access::QmfMsg*>(comm_access::QmfMsgCreater());
  qmf_msg->mutable_req()->logic_header.set_callee("callee_xxxxxx");

  comm_access::WuJiConfig config;
  config.close_retry = false;
  qmf_msg->set_config(config);

  plugin->set_msg(qmf_msg);
  EXPECT_EQ(plugin->Invoke(), comm_access::kFailedContinue);

  // 检查回包中是否设置了重试flag
  EXPECT_EQ(qmf_msg->video_rsp().logic_header.flag_info().need_retry_flag(), 1);
}

/**
 * @case_name QmfProxyPlugin.Case7_Proxy_P0
 * @priority P0
 * @brief 请求超时，且在无极已配置了强制关闭重试
 */
TEST(QmfProxyPlugin, Case7_Proxy_P0) {
  auto mock_trpc_servant_proxy = new spp_rpc::MockTrpcServantProxy;
  // 请求超时
  MockTrpcProxy(mock_trpc_servant_proxy, -3);

  auto plugin = reinterpret_cast<comm_access::QmfProxyPlugin*>(comm_access::qmf_proxy_plugin());
  auto qmf_msg = dynamic_cast<comm_access::QmfMsg*>(comm_access::QmfMsgCreater());
  qmf_msg->mutable_req()->logic_header.set_callee("callee_xxxxxx");

  // 在无极已配置了强制关闭重试
  comm_access::WuJiConfig config;
  config.close_retry = true;
  qmf_msg->set_config(config);

  plugin->set_msg(qmf_msg);
  EXPECT_EQ(plugin->Invoke(), comm_access::kFailedContinue);

  // 检查回包中是否设置了重试flag
  EXPECT_EQ(qmf_msg->video_rsp().logic_header.flag_info().need_retry_flag(), 0);
}