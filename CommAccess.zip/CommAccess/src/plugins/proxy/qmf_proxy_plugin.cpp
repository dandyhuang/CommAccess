/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 转发插件。
 *
 */

#include "src/plugins/proxy/qmf_proxy_plugin.h"

#include <string>
#include <utility>
#include <vector>

#include "spp_rpc/client/binary_proxy.h"
#include "spp_rpc/common/env.h"
#include "spp_rpc/common/logger/logger_interface.h"
#include "spp_rpc/spp_rpc.h"
#include "src/access_err.h"
#include "src/comm/config.h"
#include "src/comm/tools.h"
#include "src/comm/util.h"
#include "src/plugin_frame/plugin_factory.h"
#include "src/plugin_frame/plugin_id.h"
#include "src/qmf_msg.h"

namespace comm_access {

extern "C" void* qmf_proxy_plugin() {
  PluginParam param;
  param.id = kQmfProxyPluginId;
  param.name = __FUNCTION__;
  param.priority = kQmfProxyPluginPriority;
  param.proto = spp_rpc::PROTO_TYPE_QMF;
  param.enable = GetPluginStatus(__FUNCTION__);
  auto plugin = new comm_access::QmfProxyPlugin(param);
  return plugin;
}

// 把插件注册函数注册到框架
COMM_ACCESS_REGISTER_PLUGIN_FUNC(kQmfProxyPluginId, qmf_proxy_plugin);

void QmfProxyPlugin::SetPoliarisMeta(QmfMsg* qmf_msg, spp_rpc::TrpcServantProxyPtr proxy) {
  if (ROUTE_POLIARIS != qmf_msg->config()->route_flag) return;

  static bool status = !INS_DOCKER_ENV->docker_formal() || INS_CONFIG->GetFormalFlag();
  if (SPP_RPC_UNLIKELY(status)) {
    const std::string& dockerenv = INS_DOCKER_ENV->docker_env();
    qmf_msg->GetRouteInfo().metadata.insert(std::make_pair("env", dockerenv));
    if (!qmf_msg->qq().empty())
      qmf_msg->GetRouteInfo().metadata.insert(std::make_pair("qq", qmf_msg->qq()));
    if (!qmf_msg->vuid().empty())
      qmf_msg->GetRouteInfo().metadata.insert(std::make_pair("vuid", qmf_msg->vuid()));
    if (!qmf_msg->wechat_openid().empty())
      qmf_msg->GetRouteInfo().metadata.insert(
          std::make_pair("wx_openid", qmf_msg->wechat_openid()));
    const auto& bi = qmf_msg->GetVideoMutableReqHead()->bucket_info().bucket_id();
    if (bi != 0) {
      qmf_msg->GetRouteInfo().metadata.insert(std::make_pair("bucket_id", std::to_string(bi)));
    }
    RPC_DLOG("qq:%s, vuid:%s, wx:%s", qmf_msg->qq().c_str(), qmf_msg->vuid().c_str(),
             qmf_msg->wechat_openid().c_str());
  }
}

void QmfProxyPlugin::EncodeQQlive(QmfMsg* qmf_msg) {
  if (!qmf_msg) {
    return;
  }
  auto& qqlive_head =
      (*qmf_msg->mutable_req()->logic_header.mutable_trans_info())["qqlive_head"];  // NOLINT
  qmf_msg->GetVideoMutableReqHead()->SerializeToString(&qqlive_head);
  auto& q_backend_head =
      (*qmf_msg->mutable_req()
            ->logic_header.mutable_trans_info())["qqlive_backend_head"];  // NOLINT
  qmf_msg->GetVideoMutableReqBackendHead()->SerializeToString(&q_backend_head);
  SPAN_DLOG(qmf_msg, "req:%s", qmf_msg->req().logic_header.DebugString().c_str());
#if SPP_RPC_DEBUG
  std::vector<char> buf;
  buf.assign(qqlive_head.begin(), qqlive_head.end());
  INS_TOOLS->PrintPbBody(&buf);
  buf.clear();
  buf.assign(q_backend_head.begin(), q_backend_head.end());
  INS_TOOLS->PrintPbBody(&buf);
  // 业务具体参数
  INS_TOOLS->PrintPbBody(&(qmf_msg->req().body));
#endif
}

int QmfProxyPlugin::Invoke() {
  SPAN_LOG_FUNCTION_START(msg());
  auto qmf_msg = dynamic_cast<QmfMsg*>(msg());
  if (!qmf_msg || !qmf_msg->config()) {
    SPAN_ELOG(msg(), "dynamic_cast qmf_msg is null");
    return kFailedContinue;
  }

  // 读取重试逻辑开关
  static bool disable_retry = atoi(spp_rpc::GetConfParams("disable_retry").c_str());
  if (!disable_retry) {
    // 检查该请求是否为重试请求，并且无极是否已配置关闭重试
    int auto_retry_flag = qmf_msg->video_req().logic_header.flag_info().auto_retry_flag();
    bool close_retry = qmf_msg->config()->close_retry;

    spp_rpc::AttrApi("auto_retry_flag", auto_retry_flag != 0 ? 1 : 0);
    SPAN_TLOG(qmf_msg, "auto_retry_flag: %d, close_retry: %d", auto_retry_flag, close_retry);

    if (auto_retry_flag != 0 && close_retry) {
      SPAN_ELOG(msg(), "request retry has been closed");
      spp_rpc::AttrApi("illegal_retry", 1);
      qmf_msg->set_frame_error_code(E_DISPATCH_RETRY_FAIL);
      return kFailedEnd;
    }
  }

  // 往transinfo里注入qqlive_head及qqlive_backend_head
  EncodeQQlive(qmf_msg);
  // 设置好路由转发
  auto prx =
      spp_rpc::GetServantProxy<spp_rpc::TrpcServantProxyPtr>(qmf_msg->req().logic_header.callee());
  prx->set_cur_func_name(qmf_msg->req().logic_header.func());

  SPAN_DLOG(qmf_msg, "route_flag:%d", qmf_msg->config()->route_flag);
  const std::string& name = qmf_msg->req().logic_header.callee();
  comm_access::GetRoute(*qmf_msg->config(), &qmf_msg->GetRouteInfo(), name, prx);
  // SetPoliarisMeta(qmf_msg, prx);
  SetRoute(prx, qmf_msg->GetRouteInfo());
  if (qmf_msg->GetRouteInfo().type == ROUTE_POLIARIS && !spp_rpc::IsOnline()) {
    auto it = qmf_msg->req().logic_header.trans_info().find("trpc-env");
    if (it != qmf_msg->req().logic_header.trans_info().end()) {
      SPAN_TLOG(qmf_msg, "set polaris env trans_info: %s", it->second.c_str());
      prx->mutable_route_point()->SetPolarisEnvTransInfo(it->second);
    }
  }
  auto status =
      prx->InvokeTrpc2(*qmf_msg->mutable_req(), qmf_msg->mutable_rsp(), qmf_msg->context());

  // 查询下游服务是否设置了qqlive_rsp_head。若有，则透传
  auto search = qmf_msg->mutable_rsp()->logic_header.mutable_trans_info()->find("qqlive_rsp_head");
  if (search != qmf_msg->mutable_rsp()->logic_header.mutable_trans_info()->end() &&
      !search->second.empty()) {
    qmf_msg->mutable_video_rsp()->logic_header.ParseFromString(search->second);
    SPAN_TLOG(qmf_msg, "qqlive_rsp_head: %s", search->second.c_str());
  }

  qmf_msg->set_frame_error_code(status.GetOneCode());

  if (!disable_retry) {
    // 如果请求超时，则在回包中设置重试flag
    if (qmf_msg->frame_error_code() == spp_rpc::SPP_RPC_SPP_RCV) {
      qmf_msg->mutable_video_rsp()->logic_header.mutable_flag_info()->set_need_retry_flag(1);
      SPAN_TLOG(qmf_msg, "timeout, set_need_retry_flag: 1");
    }
    // 如果无极配置了关闭重试，则在回包中设置不重试flag
    if (qmf_msg->config()->close_retry) {
      qmf_msg->mutable_video_rsp()->logic_header.mutable_flag_info()->set_need_retry_flag(0);
      SPAN_TLOG(qmf_msg, "wuji config retry closed, set_need_retry_flag: 0");
    }
  }

  if (status.GetOneCode()) {
    SPAN_ELOG(msg(), "InvokeTrpc2 err|err_code:%d", status.GetOneCode());
    return kFailedContinue;
  }
  auto logic_code = qmf_msg->rsp().logic_header.ret() ? qmf_msg->rsp().logic_header.ret()
                                                      : qmf_msg->rsp().logic_header.func_ret();
  // 业务返回的错误码放在ResponseHead里
  SPAN_TLOG(msg(), "proxy %s, %s, ret:%d func_ret:%d, ip=%s, port=%d",
            qmf_msg->req().logic_header.callee().c_str(),
            qmf_msg->req().logic_header.func().c_str(), qmf_msg->rsp().logic_header.ret(),
            qmf_msg->rsp().logic_header.func_ret(), prx->route_point().GetIp().c_str(),
            prx->route_point().GetPort());
  qmf_msg->set_logic_error_code(logic_code);
  qmf_msg->set_busi_remote_ip(prx->route_point().GetIp());
  SPAN_LOG_FUNCTION_END(msg());
  return kOk;
}
}  // namespace comm_access
