/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 转发插件。
 *
 */

#pragma once

#include "src/plugin_frame/plugin.h"

namespace comm_access {

class TrpcProxyPlugin : public Plugin {
 public:
  explicit TrpcProxyPlugin(const PluginParam& param) : Plugin(param) {}
  virtual ~TrpcProxyPlugin() = default;
  virtual int Invoke();
};

extern "C" void* trpc_proxy_plugin();

}  // namespace comm_access
