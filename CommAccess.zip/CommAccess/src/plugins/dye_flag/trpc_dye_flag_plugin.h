/*
 *
 * Copyright 2020 Tencent authors.
 *
 * trpc打染色标记插件。
 *
 */

#pragma once

#include "src/plugins/dye_flag/dye_flag_plugin.h"

namespace comm_access {

class TrpcDyeFlagPlugin : public DyeFlagPlugin {
 public:
  explicit TrpcDyeFlagPlugin(const PluginParam& param) : DyeFlagPlugin(param) {}
  virtual ~TrpcDyeFlagPlugin() = default;
  int SetDyeFlag(const bool dye_flag) override;
};

extern "C" void* trpc_dye_flag_plugin();

}  // namespace comm_access
