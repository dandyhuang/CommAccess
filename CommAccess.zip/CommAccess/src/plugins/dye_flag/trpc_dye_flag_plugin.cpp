/*
 *
 * Copyright 2020 Tencent authors.
 *
 * trpc打染色标记插件。
 *
 */

#include "src/plugins/dye_flag/trpc_dye_flag_plugin.h"

#include <string>

#include "spp_rpc/common/logger/logger_interface.h"
#include "src/comm/util.h"
#include "src/plugin_frame/plugin_factory.h"
#include "src/plugin_frame/plugin_id.h"
#include "src/trpc_comm_msg.h"

namespace comm_access {

extern "C" void* trpc_dye_flag_plugin() {
  PluginParam param;
  param.id = kTrpcDyeFlagPluginId;
  param.name = __FUNCTION__;
  param.priority = kTrpcDyeFlagPluginPriority;
  param.proto = spp_rpc::PROTO_TYPE_TRPC;
  param.enable = GetPluginStatus(__FUNCTION__);
  auto plugin = new comm_access::TrpcDyeFlagPlugin(param);
  return plugin;
}

// 把插件注册函数注册到框架
COMM_ACCESS_REGISTER_PLUGIN_FUNC(kTrpcDyeFlagPluginId, trpc_dye_flag_plugin);

// 在trace_info中打入_dye_flag标记
int TrpcDyeFlagPlugin::SetDyeFlag(const bool dye_flag) {
  if (SPP_RPC_LIKELY(!dye_flag)) return 0;
  auto trpc_msg = dynamic_cast<TrpcCommMsg*>(msg());
  if (!trpc_msg) {
    SPAN_ELOG(msg(), "dynamic_cast trpc_msg is null");
    return kFailedContinue;
  }
  int flag = atoi(msg()->GetMutableExtraValue(TRPC_DYE_KEY).c_str()) | ::trpc::TRPC_DYEING_MESSAGE;
  msg()->SetExtraValue(TRPC_DYE_KEY, to_string(flag));
  return 0;
}

}  // namespace comm_access
