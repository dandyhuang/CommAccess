/*
 *
 * Copyright 2020 Tencent authors.
 *
 * trpc打染色标记插件。
 *
 */

#include "src/plugins/dye_flag/qmf_dye_flag_plugin.h"

#include <string>

#include "spp_rpc/common/logger/logger_interface.h"
#include "src/comm/util.h"
#include "src/plugin_frame/plugin_factory.h"
#include "src/plugin_frame/plugin_id.h"
#include "src/qmf_msg.h"

namespace comm_access {

extern "C" void* qmf_dye_flag_plugin() {
  PluginParam param;
  param.id = kQmfDyeFlagPluginId;
  param.name = __FUNCTION__;
  param.priority = kQmfDyeFlagPluginPriority;
  param.proto = spp_rpc::PROTO_TYPE_QMF;
  param.enable = GetPluginStatus(__FUNCTION__);
  auto plugin = new comm_access::QmfDyeFlagPlugin(param);
  return plugin;
}

// 把插件注册函数注册到框架
COMM_ACCESS_REGISTER_PLUGIN_FUNC(kQmfDyeFlagPluginId, qmf_dye_flag_plugin);

// 在trans_info中打入trpc-dyeing-key标记
int QmfDyeFlagPlugin::SetDyeFlag(const bool dye_flag) {
  if (SPP_RPC_LIKELY(!dye_flag)) return 0;
  auto qmf_msg = dynamic_cast<QmfMsg*>(msg());
  SPAN_LOG_RET(msg(), !qmf_msg, "dynamic_cast qmf_msg is null");
  int flag = atoi(msg()->GetMutableExtraValue(TRPC_DYE_KEY).c_str()) | ::trpc::TRPC_DYEING_MESSAGE;
  msg()->SetExtraValue(TRPC_DYE_KEY, to_string(flag));
  msg()->SetExtraValue("_dye_flag", "1");  // TODO(booyu) 兼容现有的服务，这个标记还要保留，后续干掉
  return 0;
}
}  // namespace comm_access
