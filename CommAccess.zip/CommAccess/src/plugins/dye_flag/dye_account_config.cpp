/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 无极染色账号配置
 *
 */

#include "src/plugins/dye_flag/dye_account_config.h"

#include <map>
#include <string>
#include <utility>
#include <vector>

#include "spp_rpc/spp_rpc.h"
#include "src/plugin_frame/plugin_factory.h"
#include "src/plugin_frame/plugin_id.h"
#include "unified_config_wuji.h"  // NOLINT

namespace comm_access {

static UnifiedConfigWujiMult s_dye_flag_config_wuji;

// 这个config要初始化绑定到trpc插件
extern "C" int trpc_dye_flag_plugin_init(void* arg1, void* arg2) {
  RPC_LOG_FUNCTION_START;
  uint64_t config_id = strtoul(spp_rpc::GetConfParams("dye_flag_config_id").c_str(), NULL, 10);
  std::vector<uint64_t> vec_config_id;
  vec_config_id.push_back(config_id);
  int ret = s_dye_flag_config_wuji.Init(&vec_config_id);
  RPC_LOG_RET(ret, "trpc_dye_flag_plugin_init init error dye_flag_config_id:%lu", config_id);
  return 0;
}

// 如果需要Init则要注册Init函数
COMM_ACCESS_REGISTER_PLUGIN_INIT_FUNC(kTrpcDyeFlagPluginId, trpc_dye_flag_plugin_init);

bool DyeAccountConfig::GetAccount(const string& account, const int type) {
  switch (type) {
    case kAccountTypeOmgid:
      return omgid_set_.find(account) != omgid_set_.end();
    case kAccountTypeQQ:
      return qq_set_.find(account) != qq_set_.end();
    case kAccountTypeVuserid:
      return vuser_id_set_.find(account) != vuser_id_set_.end();
    case kAccountTypeGuid:
      return guid_set_.find(account) != guid_set_.end();
    default:
      break;
  }
  return false;
}

int DyeAccountConfig::UpdateAccountConfig() {
  uint64_t config_id = strtoul(spp_rpc::GetConfParams("dye_flag_config_id").c_str(), NULL, 10);
  auto update_time = s_dye_flag_config_wuji.GetLastUpdateTimestamp(config_id);
  RPC_DLOG("id:%lu last_update_timestamp:%lu get wuji update_time:%lu qq_set_:%lu", config_id,
           last_update_timestamp_, update_time, qq_set_.size());
  if (update_time <= last_update_timestamp_) {
    return 0;
  }

  std::vector<std::string> keys;
  int wuji_ret = s_dye_flag_config_wuji.GetKeys(config_id, &keys);
  RPC_LOG_RET(wuji_ret, "s_dye_flag_config_wuji.GetKeys failed err:%s",
              s_dye_flag_config_wuji.GetErrorMsg().c_str());
  std::unordered_set<std::string> new_omgid_set;
  std::unordered_set<std::string> new_qq_set;
  std::unordered_set<std::string> new_vuser_id_set;
  std::unordered_set<std::string> new_guid_set;
  RPC_TLOG("wuji id:%lu key.size:%lu", config_id, keys.size());
  bool wuji_has_failed = false;
  for (auto& key : keys) {
    std::vector<std::map<std::string, std::string> > vecValue;
    int ret = s_dye_flag_config_wuji.Get(config_id, key, &vecValue);
    if (ret == 0) {
      for (auto m : vecValue) {
        int account_type = strtoul(m["status"].c_str(), NULL, 10);
        switch (account_type) {
          case kAccountTypeOmgid:
            new_omgid_set.insert(m["skey"]);
            break;
          case kAccountTypeQQ:
            new_qq_set.insert(m["skey"]);
            break;
          case kAccountTypeVuserid:
            new_vuser_id_set.insert(m["skey"]);
            break;
          case kAccountTypeGuid:
            new_guid_set.insert(m["skey"]);
            break;
          default:
            RPC_ELOG("type:%d not support", account_type);
            break;
        }
      }
    } else {
      wuji_has_failed = true;
      RPC_TLOG("wuji route Get this key failed. key:%s", key.c_str());
      break;
    }
  }
  if (wuji_has_failed) {
    return -1;
  }
  // 为了保险先更新到临时变量没问题再覆盖
  omgid_set_ = std::move(new_omgid_set);
  qq_set_ = std::move(new_qq_set);
  vuser_id_set_ = std::move(new_vuser_id_set);
  guid_set_ = std::move(new_guid_set);
  last_update_timestamp_ = update_time;
  RPC_TLOG("dyeflag size qq:%lu vuid:%lu guid:%lu omgid:%lu", qq_set_.size(), vuser_id_set_.size(),
           guid_set_.size(), omgid_set_.size());
  return 0;
}
}  // namespace comm_access
