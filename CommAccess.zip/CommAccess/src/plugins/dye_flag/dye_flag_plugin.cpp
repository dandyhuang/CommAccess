/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 打染色标记插件。
 * 处理流程：取无极里的染色账号和请求的账号做匹配，如果匹配到了就在包头里打染色标记给下游服务用
 * 此类是抽象类 所有协议都继承这个类实现GetDyeFlag，SetDyeFlag方法即可
 *
 */

#include "src/plugins/dye_flag/dye_flag_plugin.h"

#include <map>
#include <unordered_map>
#include <utility>
#include <vector>

#include "spp_rpc/common/logger/logger_interface.h"
#include "spp_rpc/spp_rpc.h"
#include "src/plugins/dye_flag/dye_account_config.h"

namespace comm_access {

// 判断该用户是否是染色用户如果是染色用户在包头设置染色字段
int DyeFlagPlugin::Invoke() {
  SPAN_LOG_FUNCTION_START(msg());
  SPAN_LOG_ERR(msg(), DYE_ACCOUNT_INS->UpdateAccountConfig(), "UpdateAccountConfig() failed");
  bool dye_flag = GetDyeFlag();
  SPAN_TLOG(msg(), "call GetDyeFlag|dye_flag:%d", dye_flag);
  SPAN_LOG_ERR(msg(), SetDyeFlag(dye_flag), "call SetDyeFlag err");
  if (!msg()->span() && dye_flag) {
    msg()->MakeSpan();
  }
  SPAN_LOG_FUNCTION_END(msg());
  return kOk;
}

// 判断是否是染色账号，如果是返回true
bool DyeFlagPlugin::GetDyeFlag() {
  // 根据请求过来的字段看是否能在wuji里查找到对应的配置
  SPAN_TLOG(msg(), "req qq:%s vuid:%s omgid:%s guid:%s", msg()->qq().c_str(), msg()->vuid().c_str(),
            msg()->GetOmgId().c_str(), msg()->GetGuid().c_str());
  if (!msg()->qq().empty()) {
    SPAN_LOG_RET(msg(), DYE_ACCOUNT_INS->GetAccount(msg()->qq(), kAccountTypeQQ),
                 "qq:%s is dye_flag=1", msg()->qq().c_str());
  }
  if (!msg()->vuid().empty()) {
    SPAN_LOG_RET(msg(), DYE_ACCOUNT_INS->GetAccount(msg()->vuid(), kAccountTypeVuserid),
                 "vuid:%s is dye_flag=1", msg()->vuid().c_str());
  }
  if (!msg()->GetOmgId().empty()) {
    SPAN_LOG_RET(msg(), DYE_ACCOUNT_INS->GetAccount(msg()->GetOmgId(), kAccountTypeOmgid),
                 "omgid:%s is dye_flag=1", msg()->GetOmgId().c_str());
  }
  if (!msg()->GetGuid().empty()) {
    SPAN_LOG_RET(msg(), DYE_ACCOUNT_INS->GetAccount(msg()->GetGuid(), kAccountTypeGuid),
                 "guid:%s is dye_flag=1", msg()->GetGuid().c_str());
  }
  return false;
}
}  // namespace comm_access
