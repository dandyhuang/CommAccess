/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 无极染色账号配置
 *
 */

#pragma once

#include <util/tc_singleton.h>

#include <string>
#include <unordered_set>

namespace comm_access {

enum AccountType {
  kAccountTypeNull = 0,
  kAccountTypeOmgid = 1,
  kAccountTypeQQ = 2,
  kAccountTypeVuserid = 3,
  kAccountTypeGuid = 4,
};

class DyeAccountConfig {
 public:
  DyeAccountConfig() = default;
  virtual ~DyeAccountConfig() = default;

  bool GetAccount(const string& account, const int type);
  int UpdateAccountConfig();

 public:
  std::unordered_set<std::string> omgid_set_;
  std::unordered_set<std::string> qq_set_;
  std::unordered_set<std::string> vuser_id_set_;
  std::unordered_set<std::string> guid_set_;
  uint64_t last_update_timestamp_{0};
};

typedef tars::TC_Singleton<DyeAccountConfig> DyeAccountConfigSingleton;
#define DYE_ACCOUNT_INS comm_access::DyeAccountConfigSingleton::getInstance()
}  // namespace comm_access
