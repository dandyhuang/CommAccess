/*
 *
 * Copyright 2020 Tencent authors.
 *
 * qmf打染色标记插件。
 *
 */

#pragma once

#include "src/plugins/dye_flag/dye_flag_plugin.h"

namespace comm_access {

class QmfDyeFlagPlugin : public DyeFlagPlugin {
 public:
  explicit QmfDyeFlagPlugin(const PluginParam& param) : DyeFlagPlugin(param) {}
  virtual ~QmfDyeFlagPlugin() = default;
  int SetDyeFlag(const bool dye_flag) override;
};

extern "C" void* qmf_dye_flag_plugin();

}  // namespace comm_access
