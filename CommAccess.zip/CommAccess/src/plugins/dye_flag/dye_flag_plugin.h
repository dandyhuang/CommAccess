/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 打染色标记插件。
 * 处理流程：取无极里的染色账号和请求的账号做匹配，如果匹配到了就在包头里打染色标记给下游服务用
 * 此类是抽象类 所有协议都继承这个类实现GetDyeFlag，SetDyeFlag方法即可
 *
 */

#pragma once

#include <string>
#include <unordered_set>

#include "src/plugin_frame/plugin.h"

namespace comm_access {

class DyeFlagPlugin : public Plugin {
 public:
  explicit DyeFlagPlugin(const PluginParam& param) : Plugin(param) {}
  virtual ~DyeFlagPlugin() = default;
  virtual int Invoke();
  virtual bool GetDyeFlag();
  virtual int SetDyeFlag(const bool dye_flag) { return 0; }
};
}  // namespace comm_access
