//  Copyright 2020 Tencent authors.

#include <string>
#include <vector>

#include "gmock/gmock.h"
#include "gtest/gtest.h"
#include "src/plugin_frame/plugin.h"
#include "src/plugins/dye_flag/dye_account_config.h"
#include "src/plugins/dye_flag/trpc_dye_flag_plugin.h"
#include "src/trpc_comm_msg.h"

namespace comm_access {

class TrpcMsgMock : public TrpcCommMsg {
 public:
  const std::string& GetGuid() override { return guid_; }
  const std::string& GetOmgId() override { return omgid_; }
  const std::string& qq() const override { return qq_; }

 public:
  std::string qq_;
  std::string vuid_;
  std::string guid_;
  std::string omgid_;
};
}  // namespace comm_access

/**
 * @case_name DyeFlagPlugin.Case1_TrpcGetDyeFlag_P0
 * @priority P0
 * @brief 获取账号是否被染色
 */
TEST(DyeFlagPlugin, Case1_TrpcGetDyeFlag_P0) {
  auto plugin =
      reinterpret_cast<comm_access::TrpcDyeFlagPlugin*>(comm_access::trpc_dye_flag_plugin());
  comm_access::TrpcMsgMock trpc_msg;
  trpc_msg.qq_ = "123456";
  trpc_msg.vuid_ = "vuid";
  trpc_msg.guid_ = "guid";
  trpc_msg.omgid_ = "omgid";
  plugin->set_msg(&trpc_msg);

  // 验证omgid
  DYE_ACCOUNT_INS->omgid_set_.insert("omgid");
  EXPECT_TRUE(plugin->GetDyeFlag());
  DYE_ACCOUNT_INS->omgid_set_.clear();

  // 验证qq
  DYE_ACCOUNT_INS->qq_set_.insert("123456");
  EXPECT_TRUE(plugin->GetDyeFlag());

  // 验证没匹配到账号场景
  DYE_ACCOUNT_INS->qq_set_.clear();
  EXPECT_FALSE(plugin->GetDyeFlag());
}

/**
 * @case_name DyeFlagPlugin.Case2_TrpcInvoke_P0
 * @priority P0
 * @brief Invoke验证
 */
TEST(DyeFlagPlugin, Case2_TrpcInvoke_P0) {
  auto plugin =
      reinterpret_cast<comm_access::TrpcDyeFlagPlugin*>(comm_access::trpc_dye_flag_plugin());
  comm_access::TrpcMsgMock trpc_msg;
  trpc_msg.qq_ = "123456";
  trpc_msg.vuid_ = "vuid";
  trpc_msg.guid_ = "guid";
  trpc_msg.omgid_ = "omgid";
  plugin->set_msg(&trpc_msg);

  // 验证qq
  DYE_ACCOUNT_INS->qq_set_.insert("123456");
  EXPECT_EQ(plugin->Invoke(), comm_access::kOk);
  EXPECT_EQ(trpc_msg.GetMutableExtraValue(TRPC_DYE_KEY), to_string(::trpc::TRPC_DYEING_MESSAGE));
}

/**
 * @case_name DyeFlagPlugin.Case3_TrpcInvoke_P0
 * @priority P0
 * @brief Invoke验证没匹配到染色账号场景
 */
TEST(DyeFlagPlugin, Case3_TrpcInvoke_P0) {
  auto plugin =
      reinterpret_cast<comm_access::TrpcDyeFlagPlugin*>(comm_access::trpc_dye_flag_plugin());
  comm_access::TrpcMsgMock trpc_msg;
  trpc_msg.qq_ = "12345678";
  trpc_msg.vuid_ = "vvv";
  trpc_msg.guid_ = "uuu";
  trpc_msg.omgid_ = "gggg";
  plugin->set_msg(&trpc_msg);
  EXPECT_EQ(plugin->Invoke(), comm_access::kOk);
  EXPECT_NE(trpc_msg.GetMutableExtraValue(TRPC_DYE_KEY), to_string(::trpc::TRPC_DYEING_MESSAGE));
}
