/*
 *
 * Copyright 2020 Tencent authors.
 *
 * demo插件。
 *
 */

#include "src/plugins/demo/demo_plugin.h"

#include <string>
#include <utility>

#include "spp_rpc/common/logger/logger_interface.h"
#include "spp_rpc/msg/http_msg.h"
#include "src/comm/config.h"
#include "src/comm/util.h"
#include "src/trpc_comm_msg.h"

namespace comm_access {

// demo功能：获取不同协议的通用字段并设置成一个新的值
int DemoPlugin::Invoke() {
  SPAN_LOG_FUNCTION_START(msg());

  // 不同子类实现GetSomeThing函数目的是把协议的差异化转成协议无关的成员变量
  int ret = GetSomeThing();
  SPAN_LOG_ERR(msg(), ret, "call GetSomeThing|ret:%d", ret);

  // 处理插件业务逻辑
  ret = Process();
  SPAN_LOG_ERR(msg(), ret, "call Process|ret:%d", ret);

  // 回写数据到具体协议
  ret = SetSomeThing();
  SPAN_LOG_ERR(msg(), ret, "call SetSomeThing|ret:%d", ret);

  SPAN_LOG_FUNCTION_END(msg());
  return 0;
}

int DemoPlugin::Process() {
  test_value_ += " world";
  return 0;
}

}  // namespace comm_access
