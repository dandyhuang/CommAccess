/*
 *
 * Copyright 2020 Tencent authors.
 *
 * demo插件。
 *
 */

#pragma once

#include <string>

#include "src/plugin_frame/plugin.h"

namespace comm_access {

class DemoPlugin : public Plugin {
 public:
  explicit DemoPlugin(const PluginParam& param) : Plugin(param) {}
  virtual ~DemoPlugin() = default;
  virtual int Invoke();
  int Process();
  virtual int GetSomeThing() { return 0; }
  virtual int SetSomeThing() { return 0; }

 protected:
  spp_rpc::SppRpcBaseMsg* msg_{nullptr};
  std::string test_value_;
};

}  // namespace comm_access
