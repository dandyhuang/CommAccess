/*
 *
 * Copyright 2020 Tencent authors.
 *
 * demo插件。
 *
 */

#pragma once

#include "src/plugins/demo/demo_plugin.h"

namespace comm_access {

class ThirdDemoPlugin : public DemoPlugin {
 public:
  explicit ThirdDemoPlugin(const PluginParam& param) : DemoPlugin(param) {}
  virtual ~ThirdDemoPlugin() = default;
  int GetSomeThing() override;
  int SetSomeThing() override;
};

}  // namespace comm_access
