/*
 *
 * Copyright 2020 Tencent authors.
 *
 * demo插件。
 *
 */

#pragma once

#include "src/plugins/demo/demo_plugin.h"

namespace comm_access {

class TrpcDemoPlugin : public DemoPlugin {
 public:
  explicit TrpcDemoPlugin(const PluginParam& param) : DemoPlugin(param) {}
  virtual ~TrpcDemoPlugin() = default;
  int GetSomeThing() override;
  int SetSomeThing() override;
};

}  // namespace comm_access
