/*
 *
 * Copyright 2020 Tencent authors.
 *
 * demo插件。
 *
 */

#include "src/plugins/demo/third_demo_plugin.h"

#include <string>
#include <utility>

#include "spp_rpc/common/logger/logger_interface.h"
#include "src/comm/config.h"
#include "src/comm/util.h"
#include "src/plugin_frame/plugin_factory.h"
#include "src/plugin_frame/plugin_id.h"
#include "src/third_msg.h"

namespace comm_access {

extern "C" void* third_demo_plugin() {
  PluginParam param;
  param.id = kHttpDemoPluginId;
  param.name = __FUNCTION__;
  param.priority = kHttpDemoPluginPriority;
  param.proto = spp_rpc::PROTO_TYPE_HTTP;
  param.enable = GetPluginStatus(__FUNCTION__);
  auto plugin = new comm_access::ThirdDemoPlugin(param);
  return plugin;
}

extern "C" int third_demo_plugin_init(void* arg1, void* arg2) {
  RPC_LOG_FUNCTION_START;
  // todo something init
  return 0;
}

// 把插件注册函数注册到框架
COMM_ACCESS_REGISTER_PLUGIN_FUNC(kHttpDemoPluginId, third_demo_plugin);

// 如果需要Init则要注册Init函数
COMM_ACCESS_REGISTER_PLUGIN_INIT_FUNC(kHttpDemoPluginId, third_demo_plugin_init);  // NOLINT

int ThirdDemoPlugin::GetSomeThing() {
  auto third_msg = dynamic_cast<comm_access::ThirdMsg*>(msg());
  if (!third_msg) {
    SPAN_ELOG(msg(), "dynamic_cast third_msg is null");
    return kFailedContinue;
  }
  test_value_ = "hello";
  return 0;
}

int ThirdDemoPlugin::SetSomeThing() {
  auto third_msg = dynamic_cast<comm_access::ThirdMsg*>(msg());
  if (!third_msg) {
    SPAN_ELOG(msg(), "dynamic_cast third_msg is null");
    return kFailedContinue;
  }
  SPAN_TLOG(msg(), "test_value_:%s", test_value_.c_str());
  return 0;
}

}  // namespace comm_access
