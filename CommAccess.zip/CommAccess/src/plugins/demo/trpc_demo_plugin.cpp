/*
 *
 * Copyright 2020 Tencent authors.
 *
 * demo插件。
 *
 */

#include "src/plugins/demo/trpc_demo_plugin.h"

#include <string>
#include <utility>

#include "spp_rpc/common/logger/logger_interface.h"
#include "src/comm/config.h"
#include "src/comm/util.h"
#include "src/plugin_frame/plugin_factory.h"
#include "src/plugin_frame/plugin_id.h"
#include "src/trpc_comm_msg.h"

namespace comm_access {

extern "C" void* trpc_demo_plugin() {
  PluginParam param;
  param.id = kTrpcDemoPluginId;
  param.name = __FUNCTION__;
  param.priority = kTrpcDemoPluginPriority;
  param.proto = spp_rpc::PROTO_TYPE_TRPC;
  param.enable = GetPluginStatus(__FUNCTION__);
  auto plugin = new comm_access::TrpcDemoPlugin(param);
  return plugin;
}

extern "C" int trpc_demo_plugin_init(void* arg1, void* arg2) {
  RPC_LOG_FUNCTION_START;
  // todo something init
  return 0;
}

// 把插件注册函数注册到框架
COMM_ACCESS_REGISTER_PLUGIN_FUNC(kTrpcDemoPluginId, trpc_demo_plugin);
// 如果需要Init则要注册Init函数
COMM_ACCESS_REGISTER_PLUGIN_INIT_FUNC(kTrpcDemoPluginId, trpc_demo_plugin_init);  // NOLINT

int TrpcDemoPlugin::GetSomeThing() {
  auto trpc_msg = dynamic_cast<TrpcCommMsg*>(msg());
  if (!trpc_msg) {
    SPAN_ELOG(msg(), "dynamic_cast trpc_msg is null");
    return kFailedContinue;
  }
  // to get some thing
  // const auto& trans_info = trpc_msg->req().logic_header.trans_info();
  test_value_ = "hello";
  return 0;
}

int TrpcDemoPlugin::SetSomeThing() {
  auto trpc_msg = dynamic_cast<TrpcCommMsg*>(msg());
  if (!trpc_msg) {
    SPAN_ELOG(msg(), "dynamic_cast trpc_msg is null");
    return kFailedContinue;
  }
  (*trpc_msg->mutable_req()->logic_header.mutable_trans_info())["test_value"] = test_value_;
  SPAN_TLOG(msg(), "test_value_:%s", test_value_.c_str());
  return 0;
}

}  // namespace comm_access
