
/*
 *
 * Copyright 2019 Tencent authors.
 *
 * qmf_msg_test
 *
 */

#include "src/qmf_msg.h"

#include <iostream>

#include "gtest/gtest.h"
#include "proto/hello_trpc.pb.h"
#include "proto/hi_pb.spp_rpc.pb.h"

namespace comm_access {
class QmfMsg_Test : public QmfMsg {
 public:
  void AttaReport(int frame_code, int logic_code) { QmfMsg::AttaReport(); }

  void ResponseImp(int frame_code, int logic_code) { QmfMsg::ResponseImp(frame_code, frame_code); }
  void GetRoute() { QmfMsg::GetRoute(); }

  int DecodeReq() { return QmfMsg::DecodeReq(); }

  int CheckParams() { return QmfMsg::CheckParams(); }

  void ParseLoginToken() { QmfMsg::ParseLoginToken(); }
};
}  // namespace comm_access

TEST(QmfMsg, QmfMsg_Test) {
  comm_access::QmfMsg_Test msg;
  comm_access::qmf_protocol::QmfHelper helper;
  helper.Init();
  helper.mutable_qmf_head()->Flag = 0x20213;

  helper.mutable_qmf_acc_head()->ClientIP = 238313840;  // 112.97.52.14
  helper.mutable_qmf_head()->ResvLen = 16;
  helper.mutable_qmf_head()->Resv[2] = 16;
  *((uint128_t*)&(helper.mutable_qmf_head()->Resv[3])) = 69877198038765092;  // NOLINT

  comm_access::qmf_protocol::VideoRequestProtocol frame_req;
  frame_req.logic_header.set_callee("com.tencent.spp_rpc.RpcHello");
  frame_req.logic_header.set_func("/com.tencent.spp_rpc.RpcHello/Sum");

  frame_req.logic_header.mutable_version_info()->set_app_id("1000005");
  frame_req.logic_header.mutable_bucket_info()->set_bucket_id(4);
  frame_req.logic_header.mutable_device_info()->set_guid("pb_test_guid_11");

  // qq
  auto token = frame_req.logic_header.add_login_token();
  token->set_type(1);
  token->set_account("12345678");

  com::tencent::spp_rpc::SumRequest sum_req;
  sum_req.set_lhs(1);
  sum_req.set_rhs(2);
  frame_req.EncodeBody(sum_req);

  std::vector<char> req_buf;
  frame_req.Encode(&req_buf);

  helper.Encode(req_buf.data(), req_buf.size());
  msg.SetReqPkg(helper.rsp_buf(), helper.rsp_buff_len());
  comm_access::WuJiConfig config;
  msg.set_config(config);

  EXPECT_EQ(msg.DecodeReq(), 0);
  msg.ParseLoginToken();
  EXPECT_EQ(msg.qq(), "12345678");
  msg.AttaReport(0, 0);
  EXPECT_EQ(msg.CheckParams(), 0);
}
