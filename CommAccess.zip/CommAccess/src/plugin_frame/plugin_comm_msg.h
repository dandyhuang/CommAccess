/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 插件msg主要是为了覆盖msg的ProcessServant方法
 * 方便灰度可通过开关控制走此msg和老msg
 *
 */

#pragma once

#include "src/comm/config.h"
#include "src/plugin_frame/plugin_comm_msg.h"
#include "src/plugin_frame/plugin_frame.h"
#include "src/qmf_msg.h"
#include "src/third_msg.h"
#include "src/trpc_comm_msg.h"

namespace comm_access {

template <typename Msg_>
class PluginCommMsg : public Msg_ {
 protected:
  int ProcessServant() override {
    SPAN_LOG_FUNCTION_START(this);
    PluginFrame plugin_frame(this);
    int ret = plugin_frame.Process();
    SPAN_TLOG(this, "pluginFrame ret:%d callee:%s func:%s", ret, this->GetServantName().c_str(),
              this->GetFuncName().c_str());
    INS_CONFIG->PluginUpdateConfig();  // TODO(booyu) 如果将来打包作为插件放打包里
    SPAN_LOG_FUNCTION_END(this);
    return 0;
  }
};

template <typename msg>
spp_rpc::SppRpcBaseMsg* PluginMsgCreater() {
  return new (std::nothrow) PluginCommMsg<msg>;
}

}  // namespace comm_access
