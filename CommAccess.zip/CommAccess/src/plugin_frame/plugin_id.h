/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 插件id和插件优先级汇总的头文件
 * 要遵循命名规范k{插件类名}Id或k{插件类名}Priority
 */

#pragma once

namespace comm_access {

// PluginId每写一个自增即可，id不变和收拢到这里就是为了好管理和排查问题方便
enum PluginId {
  kTrpcDemoPluginId = 10,
  kHttpDemoPluginId = 11,
  kTrpcProxyPluginId = 12,
  kQmfProxyPluginId = 13,
  kHttpProxyPluginId = 14,
  kTrpcProxyPluginIdV2 = 17,
  kQmfCheckAuthPluginId = 20,
  kQmfCheckTeenGuardPluginId = 21,
  kQmfCheckSecurityPluginId = 22,
  kHttpCheckAuthPluginId = 23,
  kQmfAntiWhiteScreenPluginId = 24,
  kQmfGetUserTypePluginId = 25,
  kTrpcDyeFlagPluginId = 26,
  kQmfDyeFlagPluginId = 27,
  kQmfLimitPoliarisPluginId = 28,
  kHttpLimitPoliarisPluginId = 29,
  kTrpcLimitPoliarisPluginId = 30,
  kLimitPoliarisInitPluginId = 31,
};

// 框架会按照优先级执行Invoke函数，优先级相同会并发调用，值越小优先级越大，按照优先级由小到大排列
enum PluginPriority {
  // 0-99预留
  // 基础业务插件 100-500
  kTrpcDyeFlagPluginPriority = 104,
  kQmfDyeFlagPluginPriority = 104,
  kQmfLimitPoliarisPlugin = 105,   // qmf限流
  kHttpLimitPoliarisPlugin = 105,  // http限流
  kTrpcLimitPoliarisPlugin = 105,  // trpc限流
  kQmfCheckAuthPluginPriority = 200,
  kQmfCheckTeenGuardPluginPriority = 201,
  kQmfCheckSecurityPluginPriority = 202,
  kQmfGetUserTypePluginPriority = 205,
  kTrpcDemoPluginPriority = 300,
  kHttpDemoPluginPriority = 300,
  kHttpCheckAuthPluginPriority = 350,

  // 框架插件 500-599
  kTrpcProxyPluginPriority = 500,
  kQmfProxyPluginPriority = 500,
  kHttpProxyPluginPriority = 500,
  kQmfAntiWhiteScreenPluginPriority = 501,
};

}  // namespace comm_access
