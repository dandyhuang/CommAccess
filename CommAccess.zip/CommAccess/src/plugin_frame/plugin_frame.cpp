/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 插件框架。
 *
 */

#include "src/plugin_frame/plugin_frame.h"

#include <algorithm>
#include <unordered_map>

#include "spp_rpc/common/logger/logger_interface.h"
#include "spp_rpc/task_flow.h"
#include "src/comm/config.h"
#include "src/plugin_frame/plugin_factory.h"

namespace comm_access {

// 参数plugins必须是按照优先级是有序的 返回true是并发，false是非并发
bool PluginFrame::CheckConcurrency(const std::vector<PluginPtr>& plugins, const size_t cur_index) {
  if (plugins.size() <= 1 || cur_index > plugins.size() - 1) return false;
  // 如果当前元素是第一个元素则判断下一个元素的优先级就能得出结论
  if (cur_index == 0) {
    return plugins[cur_index]->priority() == plugins[cur_index + 1]->priority();
  }
  // 如果当前元素是最后一个元素则和之前元素优先级相同就是并发
  if (cur_index == plugins.size() - 1) {
    return plugins[cur_index]->priority() == plugins[cur_index - 1]->priority();
  }
  if (plugins[cur_index]->priority() == plugins[cur_index + 1]->priority() ||
      plugins[cur_index]->priority() == plugins[cur_index - 1]->priority()) {
    return true;
  } else {
    return false;
  }
}

// 按照优先级调用各插件Invoke函数，优先级相同则并发调用
int PluginFrame::CallInvoke(const std::vector<PluginPtr>& final_plugins) {
  spp_rpc::LamTaskList task_list;
  auto check_task_result = [&] {
    const auto& tasks = task_list.task_list_result();
    auto it = std::find_if(tasks.begin(), tasks.end(), [&](const pair<std::string, int>& task) {
      SPAN_DLOG(msg(), "Invoke plugin id:%s ret:%d", task.first.c_str(), task.second);
      return task.second == kFailedEnd;
    });
    if (it != tasks.end()) {
      SPAN_DLOG(msg(), "Invoke plugin id:%s force end all!", it->first.c_str());
      return kFailedEnd;
    }
    return kOk;
  };
  for (size_t i = 0; i < final_plugins.size(); ++i) {
    auto id = final_plugins[i]->id();
    if (!CheckConcurrency(final_plugins, i)) {
      if (task_list.task_list().size()) {
        int ret = task_list.Sync();
        // 这里如果出错了就打印一条日志，就算成功不要影响后边的插件执行
        SPAN_LOG_ERR(msg(), ret, "tasklist return err|ret:%d", ret);
        if (check_task_result() == kFailedEnd) {
          SPAN_DLOG(msg(), "concurrency plugin force end all!");
          return kFailedEnd;
        }
        task_list.Reset();
      }
      int ret = final_plugins[i]->Invoke();
      if (ret == kFailedEnd) {
        SPAN_DLOG(msg(), "plugin force end all|id:%u", id);
        return kFailedEnd;
      }
    } else {
      task_list << [&, i]() {
        SPAN_DLOG(msg(), "concurrency call invoke id:%u", final_plugins[i]->id());
        return final_plugins[i]->Invoke();
      };
      task_list << std::to_string(id);  // 用plugid当并发id方便反查返回值
    }
  }
  if (task_list.task_list().size()) {
    int ret = task_list.Sync();
    // 这里如果出错了就打印一条日志，就算成功不要影响后边的插件执行
    SPAN_LOG_ERR(msg(), ret, "task_list return err|ret:%d", ret);
    if (check_task_result() == kFailedEnd) {
      SPAN_DLOG(msg(), "concurrency plugin force end all!");
      return kFailedEnd;
    }
  }
  // TODO(booyu) 回包处理等，可以放到插件里
  return kOk;
}

// 根据请求和无极的黑白名单配置，过滤掉不符合条件的插件
void PluginFrame::FilterPlugin(const std::unordered_map<uint32_t, PluginPtr>& all_plugin,
                               std::vector<PluginPtr>* final_plugins) {
  if (!final_plugins) {
    return;
  }
  string appid_callee_func = msg()->GetCallerId() + msg()->GetServantName() + msg()->GetFuncName();
  const auto config = INS_CONFIG->PluginGetConfig(appid_callee_func);
  int mode = INS_CONFIG->PluginMode(config);
  SPAN_DLOG(msg(), "all_plugin_map.size:%lu|mode:%d|msgname:%s", all_plugin.size(), mode,
            appid_callee_func.c_str());
  for (const auto& it : all_plugin) {
    const auto id = it.first;
    const auto plugin = it.second;
    if (!plugin) {
      continue;
    }
    // 根据插件协议过滤，可定义PROTO_TYPE_ALL不过滤
    if (!plugin->CheckProto(msg()->GetProto())) {
      SPAN_DLOG(msg(), "CheckProto failed|id:%d|proto:%d|plugin_proto:%d", id, msg()->GetProto(),
                plugin->proto());
      continue;
    }
    // 根据业务拼接id过滤
    if (!plugin->CheckAppidCalleeFunc(appid_callee_func)) {
      SPAN_DLOG(msg(), "CheckAppidCalleeFunc failed|id:%d|key:%s", id, appid_callee_func.c_str());
      continue;
    }

    // 目前只支持要么所有插件都是黑名单要么所有插件都是白名单
    // 在黑名单则过滤
    if (mode == kIsBlacklist) {
      if (INS_CONFIG->PluginFindInBlacklist(config, id)) {
        SPAN_DLOG(msg(), "FindInBlacklist|id:%d", id);
        continue;
      }
    } else if (mode == kIsWhitelist) {
      // 没在白名单则过滤
      if (!INS_CONFIG->PluginFindInWhitelist(config, id)) {
        SPAN_DLOG(msg(), "not FindInWhitelist|id:%d", id);
        continue;
      }
    }
    // 重新new一个插件再调用Invoke 用于让插件内部可以传递上下文
    PluginPtr final_plugin(
        (Plugin*)PluginFactorySingleton::getInstance()->GetRegisterPluginFunc(id)());  // NOLINT
    if (!final_plugin) continue;
    final_plugin->set_msg(msg());
    final_plugin->set_id(plugin->id());
    // 这里支持业务自定义插件的优先级
    const auto custom_priority = INS_CONFIG->PluginGetCustomPriority(config, id);
    if (custom_priority) {
      final_plugin->set_priority(custom_priority);
    } else {
      final_plugin->set_priority(plugin->priority());
    }
    final_plugins->push_back(final_plugin);
  }
}

int PluginFrame::Process() {
  if (!msg()) {
    return kFailedEnd;
  }
  SPAN_LOG_FUNCTION_START(msg());
  // 根据插件注册的插件范围和业务指定的插件黑白名单生成最终要执行的插件列表
  const auto& all_plugin_map = PluginFactorySingleton::getInstance()->all_plugin_map();
  FilterPlugin(all_plugin_map, &final_plugins_);
  // 按优先级排序
  std::sort(final_plugins_.begin(), final_plugins_.end(),
            [](const PluginPtr p1, const PluginPtr p2) { return p1->priority() < p2->priority(); });
  string plugin_str;
  for (auto p : final_plugins_) {
    plugin_str += ("," + std::to_string(p->id()));
  }
  SPAN_DLOG(msg(), "final_plugins.size:%lu|proto:%d|plugins:%s", final_plugins_.size(),
            msg()->GetProto(), plugin_str.c_str());
  // 调用各个插件支持并发
  int ret = CallInvoke(final_plugins_);
  SPAN_DLOG(msg(), "CallInvoke return|ret:%d", ret);
  SPAN_LOG_FUNCTION_END(msg());
  return ret;
}

}  // namespace comm_access
