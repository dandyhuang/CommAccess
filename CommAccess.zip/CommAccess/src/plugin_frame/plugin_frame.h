/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 插件框架。
 *
 */

#pragma once

#include <memory>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

#include "src/plugin_frame/plugin.h"

namespace comm_access {

class PluginFrame {
 public:
  explicit PluginFrame(spp_rpc::SppRpcBaseMsg* value) : msg_(value) {}
  virtual ~PluginFrame() = default;

  int Process();

  spp_rpc::SppRpcBaseMsg* msg() { return msg_; }
  void set_msg(spp_rpc::SppRpcBaseMsg* value) { msg_ = value; }
  void FilterPlugin(const std::unordered_map<uint32_t, PluginPtr>& all_plugin,
                    std::vector<PluginPtr>* final_plugins);
  bool CheckConcurrency(const std::vector<PluginPtr>& plugins, const size_t cur_index);
  int CallInvoke(const std::vector<PluginPtr>& final_plugins);

 protected:
  std::vector<PluginPtr> final_plugins_;
  spp_rpc::SppRpcBaseMsg* msg_{nullptr};
};

typedef std::shared_ptr<PluginFrame> PluginFramePtr;

}  // namespace comm_access
