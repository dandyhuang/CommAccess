/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 插件基类。
 *
 */

#pragma once

#include <memory>
#include <string>
#include <unordered_set>
#include <utility>

#include "spp_rpc/msg/base_msg.h"

namespace comm_access {

enum RetStatus {
  kFailedEnd = -1,     // 失败已构造好回包结束流程框架回包
  kOk = 0,             // 成功继续执行后续插件
  kFailedContinue = 1  // 失败继续执行后续插件
};

struct PluginParam {
  uint32_t id = 0;
  std::string name;
  uint32_t priority = 0;
  uint32_t proto = 0;
  bool enable = 1;
};

class Plugin {
 public:
  explicit Plugin(const PluginParam& param) {
    this->set_id(param.id);
    this->AddProto(param.proto);
    this->set_priority(param.priority);
    this->set_name(param.name);
    this->set_enable(param.enable);
  }
  virtual ~Plugin() = default;

  virtual int Invoke() = 0;

  spp_rpc::SppRpcBaseMsg* msg() const { return msg_; }
  void set_msg(spp_rpc::SppRpcBaseMsg* value) { msg_ = value; }

  const uint32_t id() const { return id_; }
  void set_id(const uint32_t value) { id_ = value; }

  const std::string& name() const { return name_; }
  void set_name(const std::string& value) { name_ = value; }

  const uint32_t priority() const { return priority_; }
  void set_priority(const uint32_t value) { priority_ = value; }

  const bool enable() const { return enable_; }
  void set_enable(const bool value) { enable_ = value; }

  const uint32_t proto() const { return proto_; }
  void AddProto(const uint32_t value) { proto_ |= value; }
  void set_proto(const uint32_t value) { proto_ = value; }
  bool CheckProto(const uint32_t value) {
    if (proto_ == spp_rpc::PROTO_TYPE_ALL) {
      return true;
    }
    if (proto_ & value) {
      return true;
    } else {
      return false;
    }
  }
  // 如果插件希望针对某个业务生效那么可以把appid，callee，func拼接起来传入
  // 这样非这个业务的请求就不会跑此插件
  void AddAppidCalleeFunc(const std::string& value) { appid_callee_func_set_.insert(value); }
  bool CheckAppidCalleeFunc(const std::string& value) {
    if (appid_callee_func_set_.empty()) {
      return true;
    }
    if (appid_callee_func_set_.find(value) == appid_callee_func_set_.end()) {  // NOLINT
      return false;
    } else {
      return true;
    }
  }

 protected:
  uint32_t id_{0};
  std::string name_;
  uint32_t priority_{0};
  bool enable_{true};
  spp_rpc::SppRpcBaseMsg* msg_{nullptr};

  // 用于插件范围校验
  uint32_t proto_{0};
  std::unordered_set<std::string> appid_callee_func_set_;
};

typedef std::shared_ptr<Plugin> PluginPtr;

}  // namespace comm_access
