/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 管理插件
 *
 */

#include "src/plugin_frame/plugin_factory.h"

#include <algorithm>
#include <memory>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

#include "spp_rpc/common/logger/logger_interface.h"

namespace comm_access {

// 存储插件的注册函数，后续创建插件时会用到
int PluginFactory::RegisterObjCreaterFunc(const uint32_t id, ObjCreaterFunc func) {
  // 存一份插件的注册函数，方便后续new插件传递上下文用
  int ret = register_func_map_.insert(std::pair<uint32_t, ObjCreaterFunc>(id, func)).second;
  if (!ret) {
    printf("exist|plugin_id:%u\n", id);
    exit(1);
  } else {
    printf("register ObjCreaterFunc|%u:%p\n", id, func);
  }
  return 0;
}

// 存储插件的Init函数，程序启动的时候会按照优先级顺序调用
int PluginFactory::RegisterObjCreaterInitFunc(const uint32_t id, ObjCreaterInitFunc init) {
  // 存一份插件的注册函数，方便后续new插件传递上下文用
  int ret = register_init_map_.insert(std::pair<uint32_t, ObjCreaterInitFunc>(id, init)).second;
  if (!ret) {
    printf("exist|plugin_id:%u\n", id);
    exit(1);
  } else {
    printf("register ObjCreaterInitFunc|%u:%p\n", id, init);
  }
  return 0;
}

int PluginFactory::InitPlugin() {
  RPC_LOG_FUNCTION_START;
  for (const auto& it : register_func_map_) {
    RPC_LOG_RET(!it.second, "register id:%d pluginptr is null", it.first);
    PluginPtr plugin(reinterpret_cast<Plugin*>(it.second()));
    RPC_LOG_RET(!plugin, "register failed plugin is null");
    if (plugin->enable() == false) {
      RPC_DLOG("this plugin is off|id:%d|name:%s", it.first, plugin->name().c_str());
      continue;
    }
    bool ret =
        all_plugin_map_.insert(std::pair<uint32_t, PluginPtr>(it.first, plugin)).second;  // NOLINT
    if (!ret) {
      RPC_DLOG("exist|plugin_id:%d", it.first);
      return -1;
    }
    RPC_DLOG("register plugin id:%d name:%s priority:%d addr:%p", plugin->id(),
             plugin->name().c_str(), plugin->priority(), plugin.get());
  }
  RPC_DLOG("all_plugin_map.size:%lu", all_plugin_map_.size());
  RPC_LOG_FUNCTION_END;
  return 0;
}

// 按照插件的优先级顺序遍历所有插件执行Init函数
int PluginFactory::Init(void* arg1, void* arg2) {
  RPC_LOG_FUNCTION_START;
  // 先初始化插件
  RPC_LOG_RET(InitPlugin(), "init plugin faied");

  // 根据优先级排序各插件
  for (const auto& it : all_plugin_map_) {
    all_plugin_vec_.push_back(it.second);
  }
  std::sort(all_plugin_vec_.begin(), all_plugin_vec_.end(),
            [](PluginPtr p1, PluginPtr p2) { return p1->priority() < p2->priority(); });

  // 再按照插件注册的优先级顺序逐个调用Init函数
  for (auto plugin : all_plugin_vec_) {
    auto it = register_init_map_.find(plugin->id());
    if (it == register_init_map_.end()) {
      continue;
    }
    RPC_TLOG("init plugin,id:%d name:%s priority:%d", plugin->id(), plugin->name().c_str(),
             plugin->priority());
    RPC_LOG_RET(it->second(arg1, arg2), "init plugin faied,id:%d name:%s priority:%d", plugin->id(),
                plugin->name().c_str(), plugin->priority());
  }
  RPC_LOG_FUNCTION_END;
  return 0;
}

}  // namespace comm_access
