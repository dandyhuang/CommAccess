//  Copyright 2020 Tencent authors.

#include "src/plugin_frame/plugin_frame.h"

#include "gmock/gmock.h"
#include "gtest/gtest.h"
#include "src/comm/config.h"
#include "src/plugin_frame/plugin.h"
#include "src/plugin_frame/plugin_factory.h"
#include "src/plugin_frame/plugin_id.h"
#include "src/plugins/check_auth/qmf_check_auth_plugin.h"
#include "src/plugins/proxy/trpc_proxy_plugin.h"
#include "src/trpc_comm_msg.h"

namespace comm_access {

class MockPlugin : public Plugin {
 public:
  explicit MockPlugin(const PluginParam& param) : Plugin(param) {}
  int Invoke() { return 0; }
};

}  // namespace comm_access

/**
 * @case_name PluginFrame.Case1_CheckConcurrency_P0
 * @priority P0
 * @brief 检查插件并发判断逻辑
 */
TEST(PluginFrame, Case1_CheckConcurrency_P0) {
  std::vector<comm_access::PluginPtr> plugins;
  comm_access::PluginParam param1;
  param1.id = 1;
  param1.priority = 1;
  plugins.push_back(comm_access::PluginPtr(new comm_access::MockPlugin(param1)));
  comm_access::PluginParam param2;
  param2.id = 2;
  param2.priority = 2;
  plugins.push_back(comm_access::PluginPtr(new comm_access::MockPlugin(param2)));
  comm_access::PluginParam param3;
  param3.id = 3;
  param3.priority = 2;
  plugins.push_back(comm_access::PluginPtr(new comm_access::MockPlugin(param3)));
  comm_access::PluginParam param4;
  param4.id = 4;
  param4.priority = 3;
  plugins.push_back(comm_access::PluginPtr(new comm_access::MockPlugin(param4)));
  comm_access::PluginFrame plugin_frame(nullptr);
  EXPECT_FALSE(plugin_frame.CheckConcurrency(plugins, 0));
  EXPECT_TRUE(plugin_frame.CheckConcurrency(plugins, 1));
  EXPECT_TRUE(plugin_frame.CheckConcurrency(plugins, 2));
  EXPECT_FALSE(plugin_frame.CheckConcurrency(plugins, 3));
  EXPECT_EQ(plugin_frame.CallInvoke(plugins), 0);
}

extern "C" int plugin_init(void* arg1, void* arg2) { return 0; }

/**
 * @case_name PluginFrame.Case2_FilterPlugin_P0
 * @priority P0
 * @brief 过滤插件
 */
TEST(PluginFrame, Case2_FilterPluginProto_P0) {
  comm_access::PluginFactorySingleton::getInstance()->RegisterObjCreaterFunc(
      222, comm_access::qmf_check_auth_plugin);
  comm_access::PluginFactorySingleton::getInstance()->RegisterObjCreaterFunc(
      223, comm_access::trpc_proxy_plugin);
  comm_access::PluginFactorySingleton::getInstance()->RegisterObjCreaterInitFunc(223, plugin_init);
  comm_access::PluginFactorySingleton::getInstance()->Init(nullptr, nullptr);
  auto trpc_msg = dynamic_cast<comm_access::TrpcCommMsg*>(comm_access::TpcCommMsgCreater());
  comm_access::PluginFrame plugin_frame(trpc_msg);
  const auto& all_plugin_map = comm_access::PluginFactorySingleton::getInstance()->all_plugin_map();
  std::vector<comm_access::PluginPtr> final_plugins;
  plugin_frame.FilterPlugin(all_plugin_map, &final_plugins);
  EXPECT_GE(final_plugins.size(), 1);
  for (auto plugin : final_plugins) {
    // 所有类型不会被过滤掉
    bool proto =
        (plugin->proto() == spp_rpc::PROTO_TYPE_TRPC || plugin->proto() == spp_rpc::PROTO_TYPE_ALL);
    EXPECT_TRUE(proto);
  }
}

/**
 * @case_name PluginFrame.Case3_Process_P0
 * @priority P0
 * @brief process处理test
 */
TEST(PluginFrame, Case3_Process_P0) {
  comm_access::PluginFactorySingleton::getInstance()->all_plugin_map().clear();
  comm_access::PluginFrame plugin_frame(comm_access::TpcCommMsgCreater());
  EXPECT_EQ(plugin_frame.Process(), comm_access::kOk);
}