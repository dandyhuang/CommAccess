/*
 *
 * Copyright 2020 Tencent authors.
 *
 * 管理插件
 *
 */

#pragma once

#include <memory>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

#include "src/plugin_frame/plugin.h"
#include "util/tc_singleton.h"

namespace comm_access {

// 用于创建对象的函数，该函数需要返回一个对象
typedef void* (*ObjCreaterFunc)();
typedef int (*ObjCreaterInitFunc)(void* arg1, void* arg2);

class PluginFactory {
 public:
  // 存储插件的注册函数，后续创建插件时会用到
  int RegisterObjCreaterFunc(const uint32_t id, ObjCreaterFunc func);
  // 存储插件的Init函数，程序启动的时候会按照优先级顺序调用
  int RegisterObjCreaterInitFunc(const uint32_t id, ObjCreaterInitFunc init);
  // 按照插件的优先级顺序遍历所有插件执行Init函数

  int Init(void* arg1, void* arg2);
  PluginPtr GetPlugin(const uint32_t plug_id) {
    auto it = all_plugin_map_.find(plug_id);
    if (it == all_plugin_map_.end()) {
      return nullptr;
    }
    return it->second;
  }
  std::unordered_map<uint32_t, PluginPtr>& all_plugin_map() { return all_plugin_map_; }
  ObjCreaterFunc GetRegisterPluginFunc(const uint32_t plug_id) {
    auto it = register_func_map_.find(plug_id);
    if (it == register_func_map_.end()) {
      return nullptr;
    }
    return it->second;
  }
  int InitPlugin();

 protected:
  std::unordered_map<uint32_t, PluginPtr> all_plugin_map_;
  std::unordered_map<uint32_t, ObjCreaterFunc> register_func_map_;
  std::unordered_map<uint32_t, ObjCreaterInitFunc> register_init_map_;
  std::vector<PluginPtr> all_plugin_vec_;  // 经过注册时的优先级顺序排序的插件
};

typedef tars::TC_Singleton<PluginFactory> PluginFactorySingleton;
#define COMM_ACCESS_REGISTER_PLUGIN_FUNC(id, func) \
  static const bool g_register_##id##func =        \
      comm_access::PluginFactorySingleton::getInstance()->RegisterObjCreaterFunc(id, func)

#define COMM_ACCESS_REGISTER_PLUGIN_INIT_FUNC(id, init_func)                             \
  static const bool g_register_##id##init_func =                                         \
      comm_access::PluginFactorySingleton::getInstance()->RegisterObjCreaterInitFunc(id, \
                                                                                     init_func)

}  // namespace comm_access
