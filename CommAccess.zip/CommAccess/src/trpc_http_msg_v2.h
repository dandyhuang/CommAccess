/*
 *
 * Copyright 2020 Tencent authors.
 *
 * third msg
 *
 */

#pragma once
#include <memory>
#include <string>

#include "spp_rpc/msg/http_msg.h"
#include "src/trpc_comm_msg_v2.h"

namespace comm_access {

using com::tencent::qqlive::protocol::pb::BackEndRequestHead;
using com::tencent::qqlive::protocol::pb::RequestHead;

class TrpcHttpMsgV2 : public TrpcCommMsgV2 {
 public:
  TrpcHttpMsgV2() { context_->set_msg(this); }
  ~TrpcHttpMsgV2() = default;
  void busi_remote_ip(string ip) { busi_remote_ip_ = ip; }

 protected:
  int DecodeReq() override;
  void ResponseImp(int frame_code, int logic_code) override;

  const spp_rpc::ProtoType GetProto() const override { return spp_rpc::PROTO_TYPE_TRPC_V2; }

 private:
  int DecodeTrpc();

 protected:
  tars::TC_HttpResponse http_rsp_;
  tars::TC_HttpRequest http_req_;
};

spp_rpc::SppRpcBaseMsg* TrpcHttpMsgV2Creater();

}  // namespace comm_access
