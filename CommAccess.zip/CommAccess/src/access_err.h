/*
 *
 * Copyright 2019 Tencent authors.
 *
 * qmf协议校验逻辑
 *
 */

#pragma once

namespace comm_access {

enum AbAccessErrno {
  // qmf协议的魔数校验失败，应该为0x15
  E_QMF_MAGIC_INVALID = -25001,
  // qmf协议的包超过最大长度，目前设置为256MB
  E_QMF_LEN_OVERLOAD = -25002,
  E_QMF_ACC_HEAD_LEN = -25003,
  // 解析acc包头失败
  E_QMF_DECODE_ACC_HEAD = -25004,
  // 解析包头失败
  E_QMF_DECODE_HEAD = -25005,
  // cmd != 0xff01
  E_QMF_CMD = -25006,
  // body部分，trpc包头解析失败
  E_QMF_DECODE_TRPC_HEAD = -25007,
  // 有压缩时，实际解压后大小和包头中指定的不一致
  E_QMF_DECODE_COMPRESS_LEN = -25008,
  E_QMF_ENCODE_BUF_NULL = -25009,

  // 业务错误码

  E_TRPC_HTTP_PATH_NOT_EXIST = -26009,
  E_TRPC_HTTP_PATH_INVALID = -26010,
};

enum SecurityAccessErrno {
  E_QMF_AUTH_FAILED = 15006,
  E_QMF_SECURITY_BEGIN = 15026,
  E_QMF_SECURITY_END = 15031,
};

enum AccessHttpERROR {
  E_OK = 0,
  E_DISPATCH_AUTH_FAIL = 15006,
  E_DISPATCH_TIME_OUT = 15005,
  E_DISPATCH_SEND_TIME_OUT = 15205,   // 发送应答失败
  E_DISPATCH_REV_TIME_OUT = 15305,    // 接收应答失败
  E_DISPATCH_LINK_TIME_OUT = 15405,   // 链接失败，一般是对端不响应链接
  E_DISPATCH_CLOSE_TIME_OUT = 15705,  // 后端主动关闭链接
  E_DISPATCH_ROUTE_FAIL = 15008,      // 路由失败
  E_DISPATCH_LIMIT_FAIL = 15050,      // 服务被限流
  E_DISPATCH_RETRY_FAIL = 15051,      // 非法的重试请求

  E_REQ_FORMAT_INVALID = 35001,
  E_PARAM_INVALID = 35002,
  E_APPSECRET_INVALID = 35003,
  E_NO_CMD_BINDED = 35004,
  E_FREQUENCY_OUT_OF_LIMIT = 35005,
  E_JSON_2_JCE_FAIL = 35006,
  E_JCE_2_JSON_FAIL = 35007,
  E_DISPATCH_TIMEOUT = 35008,
  E_DECODE_RESULT_FAIL = 35009,
  E_PATH_FORBIDDEN = 35010,
  E_TOO_BUSY = 35011,
  E_HOST_INVALID = 35012,
  E_REFERER_INVALID = 35013,
  E_GTK_INVALID = 35014,
  E_DISPATCH_UNKNOW_FAIL = 35015,
};

enum AuthAccessErrno {
  E_AUTH_NOT_VUID = -1,
  E_AUTH_VERIFY_FAILED = -2,
  E_AUTH_NOT_TOKENS = -3,
};

}  // namespace comm_access
