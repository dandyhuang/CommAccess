// Copyright 2020 Tencent authors.

#include "src/third_msg.h"

#include <fcntl.h>
#include <rapidjson/document.h>
#include <rapidjson/rapidjson.h>
#include <rapidjson/reader.h>
#include <rapidjson/stringbuffer.h>
#include <rapidjson/writer.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unified_config_wuji.h>

#include <array>
#include <map>
#include <string>
#include <utility>
#include <vector>

#include "spp_rpc/spp_rpc.h"
#include "src/attr_report.h"

namespace comm_access {

spp_rpc::SppRpcBaseMsg* ThirdMsgCreater() { return new (std::nothrow) ThirdMsg; }

int ThirdMsg::CheckParams() {
  const string& url = req_.getRequestUrl();
  auto& appid = query_["v_third_appid"];
  string c_key = appid + url;
  RPC_DLOG("c_key:%s", c_key.c_str());
  config_ = INS_CONFIG->GetWujiConfig(c_key, HTTP_TYPE);
  if (INS_CONFIG->GetThridCheck() == 0) {
    return 0;
  }

  if (INS_CONFIG->IsDefault(config_)) {
    RPC_LOG_RET(spp_rpc::SPP_RPC_HTTP_PARAM_ERROR, "check wuji config err");
  }

  return 0;
}

int ThirdMsg::ProcessServant() {
  std::string pry_name = "HttpProxy";
  if (config_->proto_type == TRPC_TYPE) {
    pry_name = "HttpPbProxy";
  }
  // 走的另外一个无极配置
  proxy_ = spp_rpc::GetServantProxy<spp_rpc::HttpRpcProxyPtr>(pry_name);
  if (config_->timeout == 0) config_->timeout = kTimeOut;
  proxy_->mutable_route_point()->SetTimeout(config_->timeout);
  tars::TC_HttpResponse* rsp = NULL;
  frame_error_code_ = proxy_->AccessHttp(req_, &rsp, context_);
  RPC_LOG_RET(frame_error_code_, "access http err");
  busi_remote_ip_ = proxy_->route_point().GetIp();
  rsp_ = *rsp;
  frame_error_code_ = proxy_->GetResult();
  logic_error_code_ = 0;
  return 0;
}

void ThirdMsg::ResponseImp(int frame_code, int logic_code) {
  RPC_LOG_FUNCTION_START;
  if (frame_code >= spp_rpc::SPP_RPC_HTTP_PARAM_ERROR &&
      frame_code <= spp_rpc::SPP_RPC_HTTP_CHECK_HEAD) {
    PackResponse(frame_code, logic_code);
  } else {
    HttpMsg::ResponseImp(frame_code, logic_code);
  }

  INS_CONFIG->UpdateWujiConfig(HTTP_TYPE);
  AttaReport(frame_code, logic_code);
  RPC_LOG_FUNCTION_END;
}

int ThirdMsg::PackResponse(int frame_code, int logic_code) {
  RPC_LOG_FUNCTION_START;
  rsp_buf_.clear();
  string content;
  busi_rsp_.setStatus(Code2StatusCode(frame_code));

  busi_rsp_.setConnection("close");
  busi_rsp_.setContentType("text/plain; charset=utf-8");

  busi_rsp_.setHeader("Access-Control-Allow-Origin", req_.getHeader("Origin"));
  busi_rsp_.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
  busi_rsp_.setHeader("Access-Control-Allow-Credentials", "true");

  rapidjson::Document rsp_body;
  rsp_body.SetObject();
  rsp_body.AddMember("ret", frame_code, rsp_body.GetAllocator());
  rapidjson::Value err_msg;
  err_msg.SetString(frame_err_msg_.c_str(), frame_err_msg_.length());
  rsp_body.AddMember("msg", err_msg, rsp_body.GetAllocator());

  rapidjson::StringBuffer buf;
  rapidjson::Writer<rapidjson::StringBuffer> writer(buf);
  rsp_body.Accept(writer);
  content = buf.GetString();

  busi_rsp_.setContent(content, true);
  rsp_buf_ = busi_rsp_.encode();
  RPC_DLOG("rsp_buf:%s, content:%s", rsp_buf_.c_str(), content.c_str());
  Response(rsp_buf_.c_str(), rsp_buf_.size());
  RPC_LOG_FUNCTION_END;
  return 0;
}

int ThirdMsg::Code2StatusCode(int errcode) {
  switch (errcode) {
    case spp_rpc::SPP_RPC_SUCCESS:
      frame_err_msg_ = "ok.";
      return 200;  // "ok.";
    case spp_rpc::SPP_RPC_HTTP_PARAM_ERROR:
      frame_err_msg_ = "param url invalid.";
      return 400;
    default:
      frame_err_msg_ = "unknow error.";
      return 500;
  }
  return 0;
}

void ThirdMsg::AttaReport(int frame_code, int logic_code) {
  pcg_attr::STAttrReport report1;

  report1.func = req_.getRequestUrl();
  report1.appid = query_["appid"];

  report1.active_ip = context_->GetLocalIp();
  report1.passive_ip = busi_remote_ip_;
  report1.calltype = "active";

  // // Dimension
  report1.total = 1;
  if (frame_code == 0) {
    report1.success = 1;
  } else {
    report1.failed = 1;
  }

  report1.cost = context_->msg()->GetMsgCost();
  report1.ret = frame_code;
  // report1.func_ret = rsp_.logic_header.func_ret();

  RPC_TLOG("report1 url:%s, appid:%s ,cost:%d, a_ip:%s, p_ip:%s", report1.func.c_str(),
           report1.appid.c_str(), report1.cost, report1.active_ip.c_str(),
           report1.passive_ip.c_str());
  INS_ATTR->CustomItemAttr(report1);

  report1.active_ip = context_->msg()->GetRemoteIp();
  report1.passive_ip = context_->GetLocalIp();
  report1.calltype = "passive";
  INS_ATTR->CustomItemAttr(report1);
}

}  // namespace comm_access
