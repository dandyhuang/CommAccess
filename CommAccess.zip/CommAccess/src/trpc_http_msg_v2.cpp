// Copyright 2020 Tencent authors.

#include "src/trpc_http_msg_v2.h"

#include <fcntl.h>
#include <rapidjson/document.h>
#include <rapidjson/rapidjson.h>
#include <rapidjson/reader.h>
#include <rapidjson/stringbuffer.h>
#include <rapidjson/writer.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unified_config_wuji.h>
#include <util/tc_base64.h>

#include <array>
#include <map>
#include <string>
#include <utility>
#include <vector>

#include "spp_rpc/common/flow.h"
#include "spp_rpc/spp_rpc.h"
#include "src/access_err.h"

#include "src/config_frame/config_factory.h"
#include "src/comm/tools.h"

namespace comm_access {
using com::tencent::qqlive::protocol::pb::LoginToken;

spp_rpc::SppRpcBaseMsg *TrpcHttpMsgV2Creater() {
  return new (std::nothrow) TrpcHttpMsgV2;
}

int TrpcHttpMsgV2::DecodeReq() {
  int ret = http_req_.decode(_msg_buff.data(), _msg_buff.size());
  if (!ret) {
    RPC_LOG_RET(E_DECODE_RESULT_FAIL, "http decode err:%d", ret);
  }

  RPC_LOG_RET(DecodeTrpc(), "decode trpc error");
  return 0;
}

int TrpcHttpMsgV2::DecodeTrpc() {
  int ret =
      req_.Decode(http_req_.getContent().c_str(), http_req_.getContentLength());
  if (ret != 0) {
    return E_DECODE_RESULT_FAIL;
  }

  return 0;
}

void TrpcHttpMsgV2::ResponseImp(int frame_code, int logic_code) {
  std::vector<char> rsp_buf;
  // 包头没数据，说明下游没有回包
  if (rsp_.frame_header.pb_header_size == 0) {
    rsp_.logic_header.set_ret(frame_code);
    rsp_.logic_header.set_func_ret(logic_code);
  }

  rsp_.Encode(&rsp_buf);

  const char *s = &(*rsp_buf.begin());
  std::string res = std::string(s, rsp_buf.size());

  http_rsp_.setContent(res, true);
  http_rsp_.setHeader("Content-Type", "application/octet-stream");

  std::string buf = http_rsp_.encode();
  Response(buf.c_str(), buf.length());
  RPC_DLOG("buf:%s, %zd", buf.c_str(), rsp_buf.size());
  INS_CONFIG_MGR->UpdateConfig();
  int func_ret = rsp_.logic_header.func_ret();
  // frame_code = frame_code ? E_DECODE_RESULT_FAIL : trpc_rsp_.logic_header.ret();
  AttaReport(frame_code, func_ret);

  RPC_LOG_FUNCTION_END;
}

}  // namespace comm_access
