// Copyright 2019 Tencent authors.

#pragma once

#include <memory>
#include <string>
#include <vector>

#include "request_base.pb.h"
#include "spp_rpc/client/trpc_servant_proxy.h"
#include "spp_rpc/msg/trpc_msg.h"

namespace comm_access {

using com::tencent::qqlive::protocol::pb::RequestHead;
spp_rpc::SppRpcBaseMsg* TpcCommMsgV2Creater();

class TrpcCommMsgV2 : public spp_rpc::TrpcMsg {
 public:
  void set_rsp_buf(const char* value) { rsp_buf_ = const_cast<char*>(value); }
  const char* rsp_buf() const { return rsp_buf_; }
  void set_rsp_size(size_t value) { rsp_size_ = value; }
  size_t rsp_size() const { return rsp_size_; }
  void set_proxy_ptr(spp_rpc::TrpcServantProxyPtr value) { proxy_ptr_ = value; }
  void set_busi_remote_ip(const std::string& ip) { busi_remote_ip_ = ip; }
  const spp_rpc::ProtoType GetProto() const override { return spp_rpc::PROTO_TYPE_TRPC_V2; }
  virtual void SetUserTypeConfig(int user_type) { user_type_config_ = user_type; }
  virtual void SetSecurityConfig(int security_type) { security_config_ = security_type; }

 protected:
  void ParseLoginToken() override;
  void ResponseImp(int frame_code, int logic_code) override;
  const std::string& GetTracerServantName() const override {
    static std::string name = "normal.CommAcc.CommAccess";
    return name;
  }
  virtual void AttaReport(int frame_code, int logic_code);
  int PrintPbBody(const std::vector<char>* buf);
  void EncodeQQlive();

 protected:
  spp_rpc::TrpcServantProxyPtr proxy_ptr_ = nullptr;
  char* rsp_buf_ = nullptr;
  size_t rsp_size_ = 0;
  std::string seqnum_;
  std::string busi_remote_ip_;

  int user_type_config_ = 0;
  int security_config_ = 0;
};

}  // namespace comm_access
