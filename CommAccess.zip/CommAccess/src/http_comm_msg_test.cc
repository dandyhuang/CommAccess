// Copyright 2020 Tencent authors.
#include "src/http_comm_msg.h"

#include <iostream>
#include <map>

#include "gmock/gmock.h"
#include "gtest/gtest.h"
#include "spp_rpc/client/http_proxy_mock.h"
#include "spp_rpc/client/servant_proxy_factory.h"
#include "spp_rpc/codec/http/http_util.h"
#include "src/access_err.h"
#include "src/comm/config.h"

namespace comm_access {
class HttpCommMsg_Test : public HttpCommMsg {
 public:
  void AttaReport(int frame_code, int logic_code) {
    HttpCommMsg::AttaReport(frame_code, logic_code);
  }

  void ResponseImp(int frame_code, int logic_code) {
    HttpCommMsg::ResponseImp(frame_code, frame_code);
  }

  int CheckValidataion() { return HttpCommMsg::CheckValidation(); }

  int DecodeReq() { return HttpCommMsg::DecodeReq(); }

  int ProcessServant() { return HttpCommMsg::ProcessServant(); }

  int CheckParams() { return HttpCommMsg::CheckParams(); }
  void ParseUrl(std::string url) { spp_rpc::ParseUrlParam(url, &query_); }

  MOCK_METHOD(void, UpdateConfig, (), (override));
};
}  // namespace comm_access

void HttpCommMsg_Sercure_Test() {
  comm_access::HttpCommMsg_Test msg;
  comm_access::WuJiConfig config;
  config.hosts = "www.baidu.com;www.qq.video.com";
  config.referer = "www.baidu.com;www.qq.video.com";
  config.gtk_flag = 1;
  msg.mutable_req()->setHeader("Referer", "http://www.baidu.com?3454");
  msg.mutable_req()->setHeader("Host", "www.qq.video.com");
  std::string cookie =
      "video_platform=2; video_guid=99f6565a96421d80; pgv_pvid=9133944646;"
      " pac_uid=0_5eba7b8686e88; pgv_pvi=3896183808; mobileUV=1_17293d0ec27_76904;"
      " RK=aM4BwrKHZI; ptcz=704bc593991c0f8aa441368779cef1ce9ddcaa85f0484b0099b315fc646b9a00;"
      " main_login=qq; vqq_access_token=BA6BB153206C53999F56775582405D3C; vqq_appid=101483052;"
      " vqq_openid=EF58243272F0B65C42CC39E180B057FB; vqq_vuserid=301609889;"
      " vqq_refresh_token=DD1D277F3FBC6D5D5152ADA01019E909; uid=680530912; "
      "pgv_info=ssid=s5037830070;"
      " vqq_vusession=rR_34bxCAoonB7WhP75F9Q..;";
  msg.mutable_req()->setCookie(cookie);
  std::string url = "http://www.qq.video.com?g_vstk=283616281&g_actk=1458743151";

  msg.mutable_req()->setGetRequest(url);
  msg.ParseUrl(url);
  msg.set_config(config);
  // std::string buf = msg.mutable_req()->encode();
  // msg.mutable_req()->decode(buf.c_str(), buf.length());  // http_req.encode();
  tars::TC_HttpCookie tc_cookie;
  tc_cookie.addCookie("qq.com", msg.mutable_req()->getCookie());
  auto cookies = tc_cookie.getAllCookie();
  if (cookies.size() > 0) {
    *(msg.mutable_cookie()) = cookies.front();
  }
  int ret = msg.CheckValidataion();
  EXPECT_EQ(ret, 0);

  msg.mutable_req()->setHeader("Referer", "http://www.baidu1.com");
  ret = msg.CheckValidataion();
  EXPECT_EQ(ret, comm_access::E_REFERER_INVALID);

  msg.mutable_req()->setHeader("Referer", "http://www.baidu.com");
  msg.mutable_req()->setHeader("Host", "http://www.qq.video1.com");
  ret = msg.CheckValidataion();
  EXPECT_EQ(ret, comm_access::E_HOST_INVALID);

  comm_access::HttpCommMsg_Test msg1;
  msg1.mutable_req()->setHeader("Host", "https://www.qq.video.com");
  url = "http://www.qq.video.com?g_vstk=283616238d&g_actk=1458743125d";
  msg1.mutable_req()->setGetRequest(url);
  cookie = "main_login=qq; vqq_access_token=BA6BB153206C53999F5";

  // tars::TC_HttpCookie tc_cookie1;
  // tc_cookie1.addCookie("qq.com", msg1.mutable_req()->getCookie());
  // auto cookies1 = tc_cookie1.getAllCookie();
  // if (cookies.size() > 0) {
  //   *(msg1.mutable_cookie()) = cookies1.front();
  // }
  msg1.mutable_req()->setGetRequest(url);
  msg1.ParseUrl(url);
  config.referer = "";
  config.hosts = "";
  msg1.set_config(config);
  ret = msg1.CheckValidataion();
  EXPECT_EQ(ret, comm_access::E_GTK_INVALID);
}

TEST(HttpCommMsg, HttpCommMsg_host_Test) { HttpCommMsg_Sercure_Test(); }

TEST(HttpCommMsg, HttpCommMsg_Test) {
  comm_access::HttpCommMsg_Test msg;
  INS_CONFIG->Init();
  auto req = msg.mutable_req();
  std::string url =
      "http://vip.video.qq.com/fcgi-bin/comm_cgi_js?"
      "name=bindphone_task&video_appid=3000006&vappid=50722383&"
      "vsecret=d2a3dba4019ba6049dd7829d199833711c94c080f694ec2f";
  req->setHeader("trpc-callee", "trpc.dandyhuang.dangdyhuang.test");
  req->setHeader("trpc-func", "/trpc.dandyhuang.dangdyhuang.test/func");
  req->setGetRequest(url,
                     true);  // NOLINT
  msg.AttaReport(0, 0);
  std::string buf = req->encode();
  msg.SetReqPkg(buf.c_str(), buf.length());
  msg.DecodeReq();
  int check = msg.CheckParams();
  EXPECT_EQ(check, 0);

  auto mock_proxy = new spp_rpc::MockHttpRpcProxy;
  // 2. 区别于可测方法，mock的proxy需要注册
  // TODO(songliao): 这部分可以封装下
  ::testing::MockFunction<::spp_rpc::ServantProxy*(const std::string&, uint32_t set_id)> mock_func;
  // 当获取com.tencent.spp_rpc2.RpcHello2的proxy时，mock这个proxy
  EXPECT_CALL(mock_func, Call("trpc.dandyhuang.dangdyhuang.test", 0))
      .WillOnce(::testing::Return(mock_proxy));

  EXPECT_CALL(*mock_proxy, AccessHttp(::testing::_, ::testing::_, ::testing::_))
      .WillOnce([&](tars::TC_HttpRequest& http_req,  // NOLINT
                    tars::TC_HttpResponse** http_rsp, spp_rpc::ServantContextPtr contexts) {
        tars::TC_HttpResponse* rsp = new tars::TC_HttpResponse;
        *http_rsp = rsp;
        return 0;
      });

  spp_rpc::ServantProxyFactorySingleton::getInstance()->set_func(mock_func.AsStdFunction());

  int ret = msg.ProcessServant();
  EXPECT_EQ(ret, 0);
  EXPECT_CALL(msg, UpdateConfig()).Times(1).WillOnce([&]() { return; });
  auto rsp = msg.mutable_rsp();
  rsp->setHeader("Content-Type", "application/json");
  rsp->setContent("6655565", true);

  msg.ResponseImp(0, 0);
  msg.ResponseImp(spp_rpc::SPP_RPC_HTTP_PARAM_ERROR, 0);
}
