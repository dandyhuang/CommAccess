// Copyright 2019 Tencent authors.

#include "src/codec/qmf_protocol.h"

#include "CQmfCompress.h"
#include "spp_rpc/spp_rpc.h"
#include "src/access_err.h"

namespace comm_access {
namespace qmf_protocol {

static const size_t kCompressBodySize = 10 * 1024 * 1024;
std::vector<char> QmfHelper::compress_body_buff_(kCompressBodySize);

int QmfChecker(void* ptr, int len, bool closed, void* msg_ctx,
               bool& msg_len_detected) {  // NOLINT
  msg_len_detected = false;
  if (len < 1) return 0;

  const char* buf = reinterpret_cast<const char*>(ptr);
  // qmf魔数
  if (buf[0] != 0x15) {
    spp_rpc::AttrApi("qmf_invalid_magic", 1);
    RPC_LOG_RET(E_QMF_MAGIC_INVALID, "invalid qmf magic:0x%x", buf[0]);
  }

  if (len < 5) return 0;

  uint32_t total_len = ntohl(*reinterpret_cast<const uint32_t*>(buf + 1));
  if (total_len > 256 * 1024 * 1024) {
    spp_rpc::AttrApi("qmf_len_overload", 1);
    RPC_LOG_RET(E_QMF_LEN_OVERLOAD, "qmf len:%u overload", total_len);
  }
  msg_len_detected = true;
  return total_len;
}

int DecodeQmfAccHead(const char* buf, size_t len, size_t* head_len, QMF_PROTOCAL::QmfAccHead* head,
                     std::string* http_cookie) {
  QMF_PROTOCAL::QmfHeadParser parser;
  int ret = parser.DecodeQmfAccHead(buf, len, *head, *http_cookie);
  if (ret) {
    spp_rpc::AttrApi("decode_acc_head", 1);
    RPC_ELOG("decode acc head ret:%d", ret);
    return E_QMF_DECODE_ACC_HEAD;
  }

  *head_len = parser.GetAccHeadLen(*head);
  if (len < *head_len) {
    spp_rpc::AttrApi("acc_head_len", 1);
    RPC_ELOG("acc_head_len:%lu > buf_len:%lu", *head_len, len);
    return E_QMF_ACC_HEAD_LEN;
  }

  return 0;
}

int DecodeQmfHead(const char* buf, size_t len, QMF_PROTOCAL::QmfHead* head) {
  QMF_PROTOCAL::QmfHeadParser parser;
  int ret = parser.DecodeQmfHead(buf, len, *head);
  if (ret) {
    spp_rpc::AttrApi("decode_head", 1);
    RPC_ELOG("decode head ret:%d", ret);
    return E_QMF_DECODE_HEAD;
  }

  if (head->wCmd != 0xff01) {
    spp_rpc::AttrApi("cmd_err", 1);
    RPC_ELOG("head cmd:0x%x != 0xff01", head->wCmd);
    return E_QMF_CMD;
  }

  return 0;
}

int QmfHelper::Decode(const char* buf, size_t len) {
  RPC_LOG_RET(DecodeQmfAccHead(buf, len, &acc_head_len_, &qmf_acc_head_, &http_cookie_),
              "decod qmf acc head err");
  RPC_LOG_RET(DecodeQmfHead(buf + acc_head_len_, len - acc_head_len_, &qmf_head_),
              "decode qmf head err");
  compress_ = qmf_head_.Flag & 0x01;
  // TODO(songliao): 校验包长
  RPC_TLOG(
      "qmf head flag: 0x%x, compress:%d, "
      "acc_head_len:%lu, acc_len:%u "
      "qmf_head_len:%u, qmf_body_len:%u qmf_len:%u comprelen:%u ",
      qmf_head_.Flag, compress_, acc_head_len_, qmf_acc_head_.Len, qmf_head_.HeadLen,
      qmf_head_.BodyLen, qmf_head_.Len, qmf_head_.ComprLen);

  // 没有压缩，下面的逻辑就可以不用走了
  if (!compress_) return 0;

  un_compress_body_buff_.resize(qmf_head_.ComprLen);
  size_t un_compress_len = qmf_head_.ComprLen;
  QMF::CQmfCompressSvr svr_compress;
  RPC_LOG_RET(
      svr_compress.UnCompress(qmf_head_, reinterpret_cast<char*>(qmf_head_.Body), qmf_head_.BodyLen,
                              un_compress_body_buff_.data(), &un_compress_len),
      "un compress err");

  if (un_compress_len != qmf_head_.ComprLen) {
    RPC_LOG_RET(E_QMF_DECODE_COMPRESS_LEN, "qmf_head.CompreLen:%u, actually uncompress len:%lu",
                qmf_head_.ComprLen, un_compress_len);
  }

  qmf_head_.Body = reinterpret_cast<uint8_t*>(un_compress_body_buff_.data());
  qmf_head_.BodyLen = un_compress_len;

  return 0;
}

// 格式：
// | qmf_acc_head    |
// | qmf_head        |
// | trpc_frame_head |
// | trpc_head       |
// | trpc_body       |
// | qmf_tail        | 1字节
// | qmf_acc_tail    | 1字节
//
// 在回包的时候，当请求acc包头不是变长的时候，
// qmf_acc_head和qmf_head的长度是不变的，
// 只有其中的个别字段需要改变：
// - qmf acc head总包长度
// - qmf head包长
//
// acc层帧头长度，不包含帧尾
// acc_head_len_ = parser_.GetAccHeadLen(qmf_acc_head_);
// qmf层帧头长度，包含帧尾
// qmf_head_.HeadLen = parser_.GetQmfHeadLen(qmf_head_);
// 这里有个隐含的问题：
// acc_head_len 只有acc帧头的长度
// qmf_head_.HeadLen即包含了帧头的长度，也包含了帧尾的长度
int QmfHelper::Encode(const char* req_buf, const char* buf, size_t len) {
  compress_ = qmf_head_.Flag & 0x01;
  if (compress_) {
    before_compress_len_ = len;
    size_t out_len = kCompressBodySize;
    RPC_LOG_RET(Compress(buf, len, &out_len), "compress err");
    return EncodeImp(req_buf, compress_body_buff_.data(), out_len);
  }
  return EncodeImp(req_buf, buf, len);
}
int QmfHelper::Encode(const char* buf, size_t len) {
  compress_ = qmf_head_.Flag & 0x01;
  if (compress_ && buf && len > 0) {
    before_compress_len_ = len;
    size_t out_len = kCompressBodySize;
    RPC_LOG_RET(Compress(buf, len, &out_len), "compress err");
    return EncodeImp(compress_body_buff_.data(), out_len);
  }
  return EncodeImp(buf, len);
}
int QmfHelper::Compress(const char* buf, size_t len, size_t* out_len) {
  QMF::CQmfCompressSvr svr_compress;
  // TODO(songliao): 静态变量
  // compress_body_buff_.resize(len);
  RPC_LOG_RET(svr_compress.Compress(qmf_head_, buf, len, compress_body_buff_.data(), out_len),
              "compress err");
  return 0;
}
int QmfHelper::EncodeImp(const char* req_buf, const char* buf, size_t len) {
  // 如果acc包头大于63个字节，那说明包头里有扩展参数，
  // 但是回包是不能带扩展参数，因为conn层回包是定长包头。
  if (qmf_acc_head_.Ver == 0x03 && acc_head_len_ != sizeof(QMF_PROTOCAL::QmfAccHead)) {
    return EncodeImp(buf, len);
  }
  // len里包含了：trpc_frame_head + trpc_head + trpc_body
  // qmf_head_.HeadLen 包含了帧尾
  size_t trpc_start = acc_head_len_ + GetQmfHeadFrameLen();
  // size_t total_len = trpc_start + len + 1 + 1;
  size_t total_len = trpc_start + len + 1 + 1;
  // TODO(songliao): buffer池
  rsp_buff_.resize(total_len);
  char* ptr = rsp_buff_.data();
  // 先从请求中拷贝包头，这样做可以避免重复的序列化操作，包头都是复用的
  memcpy(ptr, req_buf, trpc_start);
  if (buf && len) memcpy(ptr + trpc_start, buf, len);

  // 之前的包头里的包长字段存的是请求包的，所以需要改成回包的包长
  uint32_t net_total_len = htonl(total_len);
  memcpy(ptr + 1, &net_total_len, sizeof(net_total_len));

  // TODO(songliao): 加密、压缩的支持，目前默认是不压缩，不加密
  uint32_t net_qmf_total_len = htonl(total_len - acc_head_len_ - 1);
  memcpy(ptr + acc_head_len_ + 1, &net_qmf_total_len, sizeof(net_qmf_total_len));

  // 设置压缩前大小
  if (compress_ && before_compress_len_ != -1) {
    RPC_TLOG("compress, before_compress_len:%d", before_compress_len_);
    uint32_t net_un = htonl(before_compress_len_);
    memcpy(ptr + acc_head_len_ + GetQmfHeadFrameLen() - 4, &net_un, sizeof(net_un));
  }

  // 低耦合，trpc自己负责帧头的信息
  // uint32_t net_body_len = htonl(len);
  // memcpy(ptr + acc_head_len_ + qmf_head_.HeadLen - 4, &net_body_len,
  //        sizeof(net_body_len));

  ptr[total_len - 1] = 0x3;
  ptr[total_len - 2] = 0x3;
  return 0;
}

int QmfHelper::EncodeImp(const char* buf, size_t len) {
  if (buf == nullptr || len == 0) {
    RPC_LOG_RET(E_QMF_ENCODE_BUF_NULL, "null buf or len:%p %lu", buf, len);
  }
  // 回包的时候，不要带扩展参数，所以计算acc_head_len_时不能用0x03的计算方式
  // conn层是直接把包头的前面63个字节去掉
  qmf_acc_head_.Ver = 0x02;
  // acc层帧头长度，不包含帧尾
  acc_head_len_ = parser_.GetAccHeadLen(qmf_acc_head_);
  // qmf层帧头长度，包含帧尾
  qmf_head_.HeadLen = parser_.GetQmfHeadLen(qmf_head_);
  // qmf层总长度 = 帧头长度（包含了帧尾1个字节） + 业务包长
  qmf_head_.Len = qmf_head_.HeadLen + len;
  if (compress_ && before_compress_len_ != -1) {
    qmf_head_.ComprLen = before_compress_len_;
  }
  // size_t rsp_buff_len_ = acc_head_len_ + qmf_head_.HeadLen + len + 2;

  // acc层总长度 = 帧头长度 + qmf包长 + acc帧尾
  qmf_acc_head_.Len = acc_head_len_ + qmf_head_.Len + 1;
  rsp_buff_.resize(qmf_acc_head_.Len);
  rsp_buff_[qmf_acc_head_.Len - 1] = 0x3;
  int out_len = qmf_head_.Len;
  // TODO(songliao): 对out_len做校验？
  RPC_LOG_RET(
      parser_.EncodeQmfHead(rsp_buff_.data() + acc_head_len_, &out_len, qmf_head_, buf, len),
      "encode qmf head err");

  RPC_TLOG(
      "encode, acc_head_len:%lu acc_len:%u, "
      "qmf_head_len:%u qmf_body_len:%u qmf_len:%u",
      acc_head_len_, qmf_acc_head_.Len, qmf_head_.HeadLen, qmf_head_.BodyLen, qmf_head_.Len);

  // 原地打包
  parser_.EncodeQmfAccHead(qmf_acc_head_);
  memcpy(rsp_buff_.data(), &qmf_acc_head_, acc_head_len_);
  // rsp_buff_[rsp_buff_len_ - 2] = 0x3;
  return 0;
}

void QmfHelper::Init() {
  qmf_acc_head_.init();
  acc_head_len_ = parser_.GetAccHeadLen(qmf_acc_head_);
  qmf_head_.init();
  qmf_head_.Omas_sign = 0x13;
  qmf_head_.wCmd = 0xff01;
}

}  // namespace qmf_protocol
}  // namespace comm_access
