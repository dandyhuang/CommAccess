// Copyright 2019 Tencent authors.

#pragma once

#include <arpa/inet.h>
#include <qmf_head_parser.h>

#include <memory>
#include <string>
#include <vector>

#include "request_base.pb.h"
#include "spp_rpc/codec/trpc/trpc_protocol.h"

namespace comm_access {

namespace qmf_protocol {

using VideoRequestProtocol = spp_rpc::TrpcProtocol<spp_rpc::TrpcFixedHeader,
                                                   com::tencent::qqlive::protocol::pb::RequestHead>;
using VideoResponseProtocol =
    spp_rpc::TrpcProtocol<spp_rpc::TrpcFixedHeader,
                          com::tencent::qqlive::protocol::pb::ResponseHead>;

int QmfChecker(void* ptr, int len, bool closed, void* msg_ctx,
               bool& msg_len_detected);  // NOLINT

int DecodeQmfAccHead(const char* buf, size_t len, size_t* head_len, QMF_PROTOCAL::QmfAccHead* head,
                     std::string* http_cookie);

int DecodeQmfHead(const char* buf, size_t len, QMF_PROTOCAL::QmfHead* head);

class QmfHelper {
 public:
  QmfHelper() = default;
  ~QmfHelper() = default;
  int Decode(const char* buf, size_t len);
  int Encode(const char* req_buf, const char* buf, size_t len);
  int Encode(const char* buf, size_t len);
  int EncodeImp(const char* req_buf, const char* buf, size_t len);
  int EncodeImp(const char* buf, size_t len);
  int Compress(const char* buf, size_t len, size_t* out_len);
  uint32_t GetQmfHeadFrameLen() {
    // qmf_head_.HeadLen 包含了帧尾。。。。
    if (qmf_head_.HeadLen > 0) return qmf_head_.HeadLen - 1;
    return 0;
  }
  void Init();

  const QMF_PROTOCAL::QmfHeadParser& parser() const { return parser_; }
  QMF_PROTOCAL::QmfHeadParser* mutable_parser() { return &parser_; }
  const QMF_PROTOCAL::QmfAccHead& qmf_acc_head() const { return qmf_acc_head_; }
  QMF_PROTOCAL::QmfAccHead* mutable_qmf_acc_head() { return &qmf_acc_head_; }
  const QMF_PROTOCAL::QmfHead& qmf_head() const { return qmf_head_; }
  QMF_PROTOCAL::QmfHead* mutable_qmf_head() { return &qmf_head_; }

  const char* rsp_buf() const { return rsp_buff_.data(); }
  size_t rsp_buff_len() const { return rsp_buff_.size(); }

 protected:
  size_t acc_head_len_ = 0;
  QMF_PROTOCAL::QmfHeadParser parser_;
  QMF_PROTOCAL::QmfAccHead qmf_acc_head_;
  QMF_PROTOCAL::QmfHead qmf_head_;
  std::string http_cookie_;
  std::vector<char> rsp_buff_;
  bool compress_ = false;
  int32_t before_compress_len_ = -1;
  // 如果有压缩，这里保存未压缩的数据
  // 保存解压缩的数据，会在整个生命周期都存在，所以不能用静态的
  std::vector<char> un_compress_body_buff_;

  // 压缩数据，只在打包过程中存在，是临时的，所以可以用静态变量
  static std::vector<char> compress_body_buff_;
};

}  // namespace qmf_protocol

}  // namespace comm_access
