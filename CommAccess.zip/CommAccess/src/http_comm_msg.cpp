// Copyright 2020 Tencent authors.

#include "src/http_comm_msg.h"

#include <fcntl.h>
#include <rapidjson/document.h>
#include <rapidjson/rapidjson.h>
#include <rapidjson/reader.h>
#include <rapidjson/stringbuffer.h>
#include <rapidjson/writer.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unified_config_wuji.h>
#include <util/tc_base64.h>

#include <array>
#include <map>
#include <string>
#include <utility>
#include <vector>

#include "oi_tea.h"
#include "spp_rpc/common/flow.h"
#include "spp_rpc/spp_rpc.h"
#include "src/access_err.h"
#include "src/attr_report.h"
#include "token_api.h"

namespace comm_access {
using com::tencent::qqlive::protocol::pb::LoginToken;

spp_rpc::SppRpcBaseMsg* HttpCommMsgCreater() { return new (std::nothrow) HttpCommMsg; }

std::string HttpCommMsg::GetAppid() {
  appid_ = GetCookie("video_appid");
  if (appid_.empty()) {
    appid_ = GetParam("video_appid");
    if (appid_.empty()) {
      appid_ = INS_CONFIG->GetVAppid();
    }
  }
  return appid_;
}

int HttpCommMsg::CheckParams() {
  callee_ = GetHeader("trpc-callee");
  func_ = GetHeader("trpc-func");
  set_info_ = GetHeader("video-set");
  RPC_DLOG("http: %s,", _msg_buff.data());
  // url 不为空则为http请求，
  string url = req_.getRequestUrl();
  // if (!url.empty()) {
  //   RPC_LOG_RET(CheckBasicInfo(), "check basic info err");
  // }

  if (GetHeader("Content-Type").find("application/proto") != string::npos) {
    http_type_ = 1;
  }
  if (callee_.empty()) {
    vector<std::string> vec;
    video_util::split2vec(url, "/", vec);
    if (vec.size() > 0) {
      callee_ = vec[0];
      if (callee_.empty()) {
        return E_REQ_FORMAT_INVALID;
      }
    }
  }

  if (func_.empty()) {
    func_ = url;
    if (func_.empty()) {
      return E_REQ_FORMAT_INVALID;
    }
  }

  string key = GetWujiConfigKey(HTTP_TYPE, GetAppid(), callee_, func_);

  SPAN_DLOG(this, "key:%s", key.c_str());
  // 和qmf配置走一块，应该不会两边不一致的场景
  config_ = INS_CONFIG->GetWujiConfig(key, QMF_TYPE);
  // 安全调用检查
  RPC_LOG_RET(CheckValidation(), "check sercure info err");
  SetTransInfo();
  return 0;
}

// TODO(booyu) 插件线上跑久了验证没问题这个函数要挪到插件里为了回滚保留的
void HttpCommMsg::InitVideoPacket() {
  if (packet_ == nullptr) {
    packet_ = std::make_shared<CVideoPacket>();
    spp_rpc::CommonHeadUtil::PbHeadReq2Jce(head_, &packet_->getVideoCommHeader());
  }
}

int HttpCommMsg::ProcessServant() {
  proxy_ = spp_rpc::GetServantProxy<spp_rpc::HttpRpcProxyPtr>(callee_);

  GetRoute(*config_, &r_info_, callee_, proxy_);
  SetRoute(proxy_, r_info_, "Http");

  tars::TC_HttpResponse* rsp = NULL;
  frame_error_code_ = proxy_->AccessHttp(req_, &rsp, context_);
  RPC_LOG_RET(frame_error_code_, "access http err");
  busi_remote_ip_ = proxy_->route_point().GetIp();
  if (rsp) {
    set_rsp(*rsp);
  }
  frame_error_code_ = proxy_->GetResult();
  logic_error_code_ = 0;
  return 0;
}

void HttpCommMsg::UpdateConfig() { INS_CONFIG->UpdateWujiConfig(QMF_TYPE); }

void HttpCommMsg::ResponseImp(int frame_code, int logic_code) {
  if (frame_code >= spp_rpc::SPP_RPC_HTTP_PARAM_ERROR &&
      frame_code <= spp_rpc::SPP_RPC_HTTP_CHECK_HEAD) {
    PackResponse(frame_code, logic_code);
    return;
  }

  std::string callback = GetParam("callback");
  if (callback.find("%") != string::npos || callback.find("<") != string::npos ||
      callback.find(">") != string::npos || callback.find("/") != string::npos ||
      callback.find("\\") != string::npos) {
    callback = "";
  }

  std::string origin = GetParam("origin");
  // tv 直接透传业务回包，不需要接入层拼包
  if (set_info_ == "tv" || !origin.empty()) {
    // 跨域问题也帮忙下游业务设置一下
    SetCommRspHeader();
    std::string rsp_buf = rsp_.encode();
    if (!callback.empty()) {
      rsp_buf = callback + "(" + rsp_buf + ");";
    }
    Response(rsp_buf.c_str(), rsp_buf.length());
    RPC_DLOG("rsp_buf:%s", rsp_buf.c_str());
    UpdateConfig();
    AttaReport(frame_code, logic_code);
    return;
  }

  RPC_DLOG("rsp json:%s", rsp_.getContent().c_str());
  rapidjson::Document document;
  document.Parse("{}");
  document.SetObject();

  if (!rsp_.getContent().empty()) {
    rapidjson::Document sub(&document.GetAllocator());
    sub.Parse(rsp_.getContent().c_str());
    document.AddMember("data", sub, document.GetAllocator());
  }
  if (frame_code || logic_code) {
    frame_err_msg_ = "server err";
  }

  document.AddMember("ret", frame_code, document.GetAllocator());
  rapidjson::Value err_msg;
  err_msg.SetString(frame_err_msg_.c_str(), frame_err_msg_.length());
  document.AddMember("msg", err_msg, document.GetAllocator());

  // output
  rapidjson::StringBuffer out;
  rapidjson::Writer<rapidjson::StringBuffer> writer(out);
  document.Accept(writer);

  rsp_.setContent(out.GetString(), true);
  SetCommRspHeader();

  std::string rsp_buf = rsp_.encode();
  if (!callback.empty()) {
    rsp_buf = callback + "(" + rsp_buf + ");";
  }
  Response(rsp_buf.c_str(), rsp_buf.length());
  RPC_DLOG("rsp_buf:%s", rsp_buf.c_str());
  UpdateConfig();
  AttaReport(frame_code, logic_code);
  RPC_LOG_FUNCTION_END;
}

int HttpCommMsg::PackResponse(int frame_code, int logic_code) {
  RPC_LOG_FUNCTION_START;
  std::string content;

  rsp_.setStatus(Code2StatusCode(frame_code));
  rsp_.setConnection("close");
  SetCommRspHeader();

  rapidjson::Document rsp_body;
  rsp_body.SetObject();
  rsp_body.AddMember("ret", frame_code, rsp_body.GetAllocator());
  rapidjson::Value err_msg;
  err_msg.SetString(frame_err_msg_.c_str(), frame_err_msg_.length());
  rsp_body.AddMember("msg", err_msg, rsp_body.GetAllocator());

  rapidjson::StringBuffer buf;
  rapidjson::Writer<rapidjson::StringBuffer> writer(buf);
  rsp_body.Accept(writer);
  content = buf.GetString();

  rsp_.setContent(content, true);
  rsp_buf_ = rsp_.encode();
  RPC_DLOG("rsp_buf:%s, content:%s", rsp_buf_.c_str(), content.c_str());
  Response(rsp_buf_.c_str(), rsp_buf_.size());
  RPC_LOG_FUNCTION_END;
  return 0;
}

void HttpCommMsg::SetCommRspHeader() {
  std::string ie = GetParam("ie");
  if (ie == "1") {
    rsp_.setContentType("text/html; charset=utf-8");
  } else {
    rsp_.setContentType("application/json; charset=utf-8");
  }
  if (req_.isOPTIONS()) {
    rsp_.setHeader("Access-Control-Allow-Headers", "Origin, Content-Type, X-Custom-Header");
  }

  rsp_.setHeader("Access-Control-Allow-Origin", req_.getHeader("Origin"));
  rsp_.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
  rsp_.setHeader("Access-Control-Allow-Credentials", "true");
  rsp_.setHeader("Access-Control-Allow-Headers", "Content-Type,Access-Token");
}

int HttpCommMsg::Code2StatusCode(int errcode) {
  switch (errcode) {
    case spp_rpc::SPP_RPC_SUCCESS:
      frame_err_msg_ = "ok.";
      return 200;  // "ok.";
    case spp_rpc::SPP_RPC_HTTP_PARAM_ERROR:
      frame_err_msg_ = "param url invalid.";
      return 400;
    default:
      frame_err_msg_ = "unknow error.";
      return 500;
  }
  return 0;
}

void HttpCommMsg::AttaReport(int frame_code, int logic_code) {
  pcg_attr::STAttrReport report;

  report.callee = callee_;
  report.func = func_;
  report.appid = head_.version_info().app_id();
  report.version = head_.version_info().version_name();
  auto pf = std::to_string(head_.version_info().platform());
  report.platform = pf;

  report.active_ip = context_->GetLocalIp();
  report.passive_ip = busi_remote_ip_;
  report.calltype = "active";

  // // Dimension
  report.total = 1;
  if (frame_code == 0) {
    report.success = 1;
  } else {
    report.failed = 1;
  }

  report.cost = context_->msg()->GetMsgCost();
  report.ret = frame_code;
  // report.func_ret = rsp_.logic_header.func_ret();

  RPC_TLOG("report url:%s, appid:%s ,cost:%d, a_ip:%s, p_ip:%s", report.func.c_str(),
           report.appid.c_str(), report.cost, report.active_ip.c_str(), report.passive_ip.c_str());
  INS_ATTR->CustomItemAttr(report);

  report.active_ip = context_->msg()->GetRemoteIp();
  report.passive_ip = context_->GetLocalIp();
  report.calltype = "passive";
  INS_ATTR->CustomItemAttr(report);
}

int HttpCommMsg::CheckBasicInfo() {
  // 颁发好人卡
  string pwd = "issac is a good man";
  map<string, string>::iterator itKV;
  string appid = GetParam("vappid");
  string appsecret = GetParam("vsecret");

  // appid和secret校验是否匹配
  string result = TeaDecrypt(pwd, appsecret);
  RPC_DLOG("appid:%s, result:%s", appid.c_str(), result.c_str());
  if (result != appid) {
    frame_error_code_ = E_APPSECRET_INVALID;
    return E_APPSECRET_INVALID;
  }

  return 0;
}

string HttpCommMsg::TeaDecrypt(const string& pwd, const string& encrypted) {
  int encryptedLen = 0, unencryptLen = 512;
  unsigned char sz_pwd[128] = {0};
  unsigned char sz_encrypted[1024] = {0};
  unsigned char sz_unencrypted[512] = {0};
  unsigned char tmp[1024] = {0};

  if (encrypted.length() >= 1024) {
    return "";
  }

  memcpy(sz_pwd, pwd.c_str(), pwd.length());
  memcpy(tmp, encrypted.c_str(), encrypted.length());
  HexToMem(encrypted.c_str(), 0, encrypted.length(), sz_encrypted, &encryptedLen);
  oi_symmetry_decrypt2(sz_encrypted, encryptedLen, (const BYTE*)pwd.c_str(), sz_unencrypted,
                       &unencryptLen);

  string unencrypt = "";
  unencrypt.assign(reinterpret_cast<char*>(sz_unencrypted), unencryptLen);

  return unencrypt;
}

void HttpCommMsg::ParseThirdToken() {
  map<string, string>::iterator itKV;
  string openid = GetParam("v_third_openid");
  string appid = GetParam("v_third_appid");
  string open_token = GetParam("v_third_open_token");
  third_param_ = GetParam("v_third_param");

  if (!appid.empty() || !open_token.empty()) {
    LoginToken token;
    token.set_app_id(appid);
    token.set_type(50);
    token.set_account(openid);
    token.set_token(open_token);
    token.set_is_main_login(false);
    qq_openid_ = openid;
    third_auth_ = true;
    LoginToken* tokens = head_.add_login_token();
    *tokens = token;
    return;
  }
}

void HttpCommMsg::ParseUinToken() {
  string version = GetCookie("_video_qq_version");
  string main_login = GetCookie("main_login");
  string video_main_login = GetCookie("_video_qq_main_login");

  // 这里有个逻辑，就是如果没有main_login等字段，那么默认认为是uin
  if (version == "1.1" && video_main_login == "wx") {
    return;
  }

  if (version != "1.1" && main_login == "wx") {
    return;
  }

  std::string uin = GetCookie("uin");
  std::string skey = GetCookie("skey");
  std::string luin = GetCookie("luin");
  std::string lskey = GetCookie("lskey");

  LoginToken token;
  if (uin.find("o") == 0) {
    uin = uin.substr(1);
  }

  if (!uin.empty()) {
    int64_t lduin = atoll(uin.c_str());
    token.set_app_id(uin);
    token.set_type(1);
    token.set_account(to_string(lduin));
    token.set_token(skey);
    token.set_is_main_login(true);
    qq_ = to_string(lduin);
    LoginToken* tokens = head_.add_login_token();
    *tokens = token;
    return;
  }

  if (luin.find("o") == 0) {
    luin = luin.substr(1);
  }

  if (!luin.empty()) {
    int64_t ldLuin = atoll(luin.c_str());
    token.set_app_id(luin);
    token.set_type(7);
    token.set_account(to_string(ldLuin));
    token.set_token(lskey);
    token.set_is_main_login(true);
    qq_ = to_string(ldLuin);
    LoginToken* tokens = head_.add_login_token();
    *tokens = token;
    return;
  }
}

void HttpCommMsg::ParseWxToken() {
  map<string, string>::iterator itKV;
  string video_version = GetCookie("_video_qq_version");
  string main_login = GetCookie("main_login");
  string video_main_login = GetCookie("_video_qq_main_login");

  if (video_version == "1.1" && video_main_login != "wx") {
    return;
  }

  if (video_version != "1.1" && main_login != "wx") {
    return;
  }

  string appid, openid, access_token, refresh_token;
  if (video_version == "1.1") {
    appid = GetCookie("_video_qq_appid");
    openid = GetCookie("_video_qq_openid");
    access_token = GetCookie("_video_qq_access_token");
    refresh_token = GetCookie("_video_qq_refresh_token");
  } else {
    appid = GetCookie("appid");
    openid = GetCookie("openid");
    access_token = GetCookie("access_token");
    refresh_token = GetCookie("refresh_token");
  }

  if (openid.empty()) {
    return;
  }

  wechat_openid_ = openid;

  LoginToken token;
  token.set_app_id(appid);
  token.set_type(100);
  token.set_account(openid);
  token.set_token(access_token);
  token.set_is_main_login(true);
  LoginToken* tokens = head_.add_login_token();
  *tokens = token;

  return;
}

void HttpCommMsg::ParseVideoToken() {
  map<string, string>::iterator itKV;
  string video_version = GetCookie("_video_qq_version");
  string main_login = GetCookie("main_login");
  string video_main_login = GetCookie("_video_qq_main_login");

  string vuser_id = "";
  string vusession = "";
  if (video_version == "1.1" && video_main_login == "wx") {
    vuser_id = GetCookie("_video_qq_vuserid");
    vusession = GetCookie("_video_qq_vusession");
  } else if (main_login == "qq") {
    vuser_id = GetCookie("vqq_vuserid");
    vusession = GetCookie("vqq_vusession");
  }

  if (vuser_id.empty() || vusession.empty()) {
    vuser_id = GetCookie("vuserid");
    vusession = GetCookie("vusession");
  }

  if (!vuser_id.empty()) {
    LoginToken token;
    token.set_app_id(vuser_id);
    token.set_type(9);
    token.set_account(vuser_id);
    token.set_token(vusession);
    token.set_is_main_login(false);
    vuid_ = vuser_id;
    LoginToken* tokens = head_.add_login_token();
    *tokens = token;
    if (qq_auth_ == false) {
      return;
    }
    uint64_t uin;
    int error = GetQQFromToken(vusession, uin);
    if (error == 0 && uin != 0) {
      RPC_TLOG("vusession:%s, uin :%lu", vusession.c_str(), uin);
      LoginToken token;
      token.set_app_id("350001");
      token.set_type(1);
      token.set_account(to_string(uin));
      token.set_token(vusession);
      token.set_is_main_login(true);
      LoginToken* tokens = head_.add_login_token();
      *tokens = token;
    }
  }

  return;
}

// 读取qq互联票据
void HttpCommMsg::ParseQqAuthToken() {
  map<string, string>::iterator itKV;
  std::string strMainLogin = GetCookie("main_login");

  if (strMainLogin != "qq") {
    return;
  }

  std::string appid = GetCookie("vqq_appid");
  std::string openid = GetCookie("vqq_openid");
  std::string access_token = GetCookie("vqq_access_token");

  if (openid.empty()) {
    return;
  }

  LoginToken token;
  token.set_app_id(appid);
  token.set_type(10);
  token.set_account(openid);
  token.set_token(access_token);
  token.set_is_main_login(true);
  qq_openid_ = openid;
  LoginToken* tokens = head_.add_login_token();
  *tokens = token;
  qq_auth_ = true;

  return;
}

void HttpCommMsg::SetCommHead() {
  // SafeInfo info;
  using com::tencent::qqlive::protocol::pb::SafeInfo;
  SafeInfo* pb_info = head_.mutable_safe_info();
  std::string safe_type = GetCookie("video_safe_type");
  if (safe_type.empty()) {
    safe_type = GetParam("video_safe_type");
  }
  std::string safe_key = GetCookie("video_safe_key");
  if (safe_key.empty()) {
    safe_key = GetParam("video_safe_key");
  }
  std::string appid = GetAppid();
  head_.mutable_version_info()->set_app_id(appid);

  std::string safe_result = GetCookie("video_safe_result");
  if (safe_result.empty()) {
    safe_result = GetParam("video_safe_result");
  }
  pb_info->set_type(std::atoi(safe_type.c_str()));
  pb_info->set_safe_key(safe_key);
  pb_info->mutable_safe_result()->assign(safe_result.begin(), safe_result.end());

  // location_info
  using com::tencent::qqlive::protocol::pb::LocationInfo;
  std::string country_code = GetCookie("country_code");
  if (country_code.empty()) {
    country_code = GetParam("country_code");
  }
  std::string lang_code = GetCookie("lang_code");
  if (lang_code.empty()) {
    lang_code = GetParam("lang_code");
  }
  LocationInfo* locate = head_.mutable_location_info();
  locate->set_country_code(std::atoi(country_code.c_str()));
  locate->set_lang_code(std::atoi(lang_code.c_str()));

  // NetworkInfo
  using com::tencent::qqlive::protocol::pb::NetworkInfo;
  string Ip = GetHeader("True-Client-IP");
  if (Ip.empty()) Ip = GetHeader("X-Forwarded-For-Pound");
  if (Ip.empty()) Ip = GetHeader("x-Real-IP");
  NetworkInfo* network = head_.mutable_network_info();
  network->set_ip(Ip);

  // VersionInfo
  using com::tencent::qqlive::protocol::pb::VersionInfo;
  std::string vplatform = GetCookie("vplatform");
  if (vplatform.empty()) {
    vplatform = GetParam("vplatform");
    if (vplatform.empty()) {
      vplatform = GetCookie("video_platform");
    }
  }
  std::string version_name = GetCookie("vversion_name");
  VersionInfo* version = head_.mutable_version_info();
  version->set_platform(std::atoi(vplatform.c_str()));
  version->set_version_name(version_name);

  // DeviceInfo
  std::string guid = GetCookie("guid");
  if (guid.empty()) {
    guid = GetParam("guid");
    if (guid.empty()) {
      guid = GetCookie("video_guid");
      if (guid.empty()) {
        guid = GetCookie("pgv_pvid");
      }
    }
  }
  std::string omgid = GetCookie("video_omgid");
  std::string pgv_pvid = GetCookie("pgv_pvid");
  std::string deviceid = GetParam("deviceid");
  std::string imei = GetCookie("qimei");

  using com::tencent::qqlive::protocol::pb::DeviceInfo;
  DeviceInfo* devinfo = head_.mutable_device_info();
  devinfo->set_imei(imei);
  devinfo->set_idfa(deviceid);
  devinfo->set_omg_id(omgid);
  devinfo->set_device_id(deviceid);
  devinfo->set_guid(guid.empty() ? pgv_pvid : guid);

  // BucketInfo
  std::string video_bucketid = GetCookie("video_bucketid");
  using com::tencent::qqlive::protocol::pb::BucketInfo;
  BucketInfo* bucket_info = head_.mutable_bucket_info();
  bucket_info->set_bucket_id(std::atoi(video_bucketid.c_str()));
}

void HttpCommMsg::SetTransInfo() {
  // trpc 不需要SetTransInfo
  if (http_type_) return;
  ParseUinToken();
  ParseThirdToken();
  ParseQqAuthToken();
  ParseWxToken();
  // 获取视频票价
  ParseVideoToken();

  SetCommHead();

  // 兼容trpc请求。终端会设置该包头
  string tran_info = GetCookie("trpc-trans-info");
  if (!tran_info.empty()) {
    return;
  }
  // 和trpc-go保持一直，接入层组装qqlive_head给下游业务
  std::string qqlive_head;
  head_.SerializeToString(&qqlive_head);
  std::string str = tars::TC_Base64::encode(qqlive_head);
  if (str.empty()) return;
  rapidjson::Document document;
  document.Parse("{}");

  if (!document.IsObject()) {
    document.SetObject();
  }

  rapidjson::Value data;
  data.SetString(str.c_str(), str.length());

  document.AddMember("qqlive_head", data, document.GetAllocator());
  // output
  rapidjson::StringBuffer out;
  rapidjson::Writer<rapidjson::StringBuffer> writer(out);
  document.Accept(writer);
  RPC_DLOG("trpc-trans-info:[%s]", out.GetString());
  req_.setHeader("trpc-trans-info", out.GetString());
}

int HttpCommMsg::CheckValidation() {
  RPC_DLOG("hosts:%s, config host:%s", req_.getHost().c_str(), config_->hosts.c_str());
  // 校验host来源合法性，配置为空则不校验
  if (!config_->hosts.empty() && !IsRefererValid(req_.getHost(), config_->hosts))
    return E_HOST_INVALID;

  // 校验refer来源合法性，配置为空则不校验
  if (!config_->referer.empty() && !IsRefererValid(GetHeader("Referer"), config_->referer))
    return E_REFERER_INVALID;

  // gtk校验
  // http://km.oa.com/group/23453/docs/show/186071
  if (config_->gtk_flag != 0) {
    RPC_DLOG("check gtk: main_login[%s]", main_login().c_str());
    // gtk校验验登录态
    if (CheckCSRFToken(GetParam("g_vstk"), vusession())) return 0;
    // openid和accesstoken检验登录态
    if (CheckCSRFToken(GetParam("g_actk"), accesstoken())) return 0;
    // 旧版gtk标准
    if (CheckCSRFToken(GetParam("g_tk"), skey())) return 0;
    // 老逻辑
    if (CheckCSRFToken(GetParam("g_vstk"), vusession_old())) return 0;
    if (CheckCSRFToken(GetParam("g_actk"), accesstoken_old())) return 0;
    return E_GTK_INVALID;
  }
  return 0;
}

bool HttpCommMsg::CheckCSRFToken(const std::string& tk, const std::string& skey) {
  RPC_DLOG("CheckCSRFToken: tk[%s], skey[%s]", tk.c_str(), skey.c_str());
  if (tk.empty() || skey.empty()) {
    return false;
  }
  int64_t ldtk = strtoull(tk.c_str(), NULL, 10);
  int64_t csrf = GetAntiCSRFToken(skey);
  RPC_DLOG("CheckCSRFToken: ldtk[%ld], csrf[%ld]", ldtk, csrf);
  return csrf == ldtk && csrf != 0 && ldtk != 0;
}

}  // namespace comm_access
