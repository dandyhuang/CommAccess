// Copyright 2020 Tencent authors.

#include "src/attr_report.h"

#include <stdio.h>

#include <string>
#include <utility>
#include <vector>

namespace pcg_attr {
// 接入层atta上报字段：appid、app版本、app平台、主调ip、被调ip、接口名、地域
// 接入层atta上报维度：请求量、成功量、失败量、延时、失败错误码，包括主调上报和被调上报
using std::pair;
using std::string;
using std::vector;

int AttrReport::Init() {
  char* env = getenv("DOCKER_ENV");
  if (env != NULL) {
    string s_env = env;
    custom_name_ = "custom_acc_" + s_env;
  } else {
    custom_name_ = "custom_acc_test";
  }

  // nmnt::initAtta();
  return 0;
}

// 5.自定义上报
void AttrReport::CustomItemAttr(const STAttrReport& req) {
  if (req.callee.empty() || req.func.empty()) {
    return;
  }

  vector<string> dimensions;
  vector<pair<float, nmnt::pb::Policy> > custom_values;
  // atta上报字段：接口名、主调ip、被调ip、appid、app版本、app平台、调用类型、分桶id、策略id、app频道、插件id、运营页类型
  // atta上报维度：请求量、成功量、失败量、延时、失败错误码
  // 自定义维度
  dimensions.push_back(req.callee);
  dimensions.push_back(req.func);
  dimensions.push_back(req.active_ip);
  dimensions.push_back(req.passive_ip);
  dimensions.push_back(req.appid);
  dimensions.push_back(req.version);
  dimensions.push_back(req.platform);
  dimensions.push_back(req.calltype);
  dimensions.push_back(std::to_string(req.ret));
  dimensions.push_back(std::to_string(req.func_ret));
  dimensions.push_back(std::to_string(req.auto_retry_flag));

  // 自定义值
  custom_values.push_back(std::make_pair(req.total, nmnt::pb::SUM));
  custom_values.push_back(std::make_pair(req.success, nmnt::pb::SUM));
  custom_values.push_back(std::make_pair(req.failed, nmnt::pb::SUM));
  custom_values.push_back(std::make_pair(req.cost, nmnt::pb::AVG));

  nmnt::Report::getInstance()->reportCustom(custom_name_, dimensions, custom_values);
}

}  // namespace pcg_attr