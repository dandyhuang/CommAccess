// Copyright 2019 Tencent authors.

#pragma once

#include <memory>
#include <string>

#include "request_base.pb.h"
#include "spp_rpc/client/binary_proxy.h"
#include "spp_rpc/msg/trpc_msg.h"
#include "src/comm/config.h"
#include "src/comm/util.h"
namespace comm_access {

using com::tencent::qqlive::protocol::pb::RequestHead;
spp_rpc::SppRpcBaseMsg* TpcCommMsgCreater();

class TrpcCommMsg : public spp_rpc::TrpcMsg {
 public:
  virtual const std::string& RpcLogPrefix() const { return seqnum_; }
  const char* body() const { return body_; }
  size_t body_len() const { return body_len_; }

  void set_rsp(char* value) { rsp_ = value; }
  const char* rsp() const { return rsp_; }
  void set_rsp_size(size_t value) { rsp_size_ = value; }
  size_t rsp_size() const { return rsp_size_; }
  void set_proxy_ptr(spp_rpc::BinaryRpcProxyPtr value) { proxy_ptr_ = value; }

  static std::shared_ptr<WuJiConfig> default_config() {
    static std::shared_ptr<WuJiConfig> trpc_default_config = nullptr;
    if (!trpc_default_config) {
      trpc_default_config = std::make_shared<WuJiConfig>();
      trpc_default_config->service_namespace = INS_DOCKER_ENV->namepsace();
      trpc_default_config->route_flag = comm_access::RouteType::ROUTE_POLIARIS;
    }
    return trpc_default_config;
  }

  std::shared_ptr<const WuJiConfig> config() const {
    if (config_ == nullptr) {
      static std::shared_ptr<WuJiConfig> empty = std::make_shared<WuJiConfig>();
      return empty;
    }
    return config_;
  }

  const std::string& appid() const { return appid_; }

 protected:
  int DecodeReq() override;
  int ProcessServant() override;
  int GetRealCallee();
  void ResponseImp(int frame_code, int logic_code) override;
  const std::string& GetTracerServantName() const override {
    static std::string name = "normal.CommAcc.CommAccess";
    return name;
  }

 protected:
  const char* body_ = nullptr;
  size_t body_len_ = 0;
  std::string appid_;
  spp_rpc::BinaryRpcProxyPtr proxy_ptr_ = nullptr;
  std::shared_ptr<WuJiConfig> config_ = nullptr;
  char* rsp_ = nullptr;
  size_t rsp_size_ = 0;
  std::string seqnum_;
};

}  // namespace comm_access
