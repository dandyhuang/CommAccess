/*
 *
 * Copyright 2019 Tencent authors.
 *
 * third_msg_test
 *
 */

#include "src/third_msg.h"

#include <iostream>

#include "gtest/gtest.h"
namespace comm_access {
class ThirdMsg_Test : public ThirdMsg {
 public:
  void AttaReport(int frame_code, int logic_code) { ThirdMsg::AttaReport(frame_code, frame_code); }

  void ResponseImp(int frame_code, int logic_code) {
    ThirdMsg::ResponseImp(frame_code, frame_code);
  }

  int Code2StatusCode(int code) { return ThirdMsg::Code2StatusCode(code); }

  int CheckParams() { return ThirdMsg::CheckParams(); }

  int PackResponse(int frame_code, int logic_code) {
    return ThirdMsg::PackResponse(frame_code, frame_code);
  }
};
}  // namespace comm_access

TEST(ThirdMsg, ThirdMsg_Test) {
  comm_access::ThirdMsg_Test msg;
  msg.AttaReport(0, 0);
  msg.PackResponse(0, 0);
  EXPECT_EQ(msg.Code2StatusCode(0), 200);
  EXPECT_EQ(msg.Code2StatusCode(-1), 500);
  EXPECT_EQ(msg.CheckParams(), 0);
}
