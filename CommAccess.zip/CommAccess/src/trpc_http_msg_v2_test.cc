// Copyright 2020 Tencent authors.
#include "src/trpc_http_msg_v2.h"

#include <iostream>
#include <vector>

#include "gtest/gtest.h"

namespace comm_access {
class TrpcHttpMsgV2_Test : public TrpcHttpMsgV2 {
 public:
  void ResponseImp(int frame_code, int logic_code) {
    TrpcHttpMsgV2::ResponseImp(frame_code, frame_code);
  }

  int DecodeReq() { return TrpcCommMsgV2::DecodeReq(); }

  int CheckParams() { return TrpcCommMsgV2::CheckParams(); }

  void ParseLoginToken() { TrpcCommMsgV2::ParseLoginToken(); }
  void EncodeQQlive() { TrpcCommMsgV2::EncodeQQlive(); }
};
}  // namespace comm_access

TEST(TrpcCommMsgV2, TrpcHttpMsgV2_Test) {
  tars::TC_HttpRequest http2trp_req;
  tars::TC_HttpResponse* http2trpc_rsp = NULL;
  comm_access::TrpcHttpMsgV2_Test msg;
  msg.mutable_req()->logic_header.set_callee("com.tencent.spp_rpc.RpcHello");
  msg.mutable_req()->logic_header.set_func("/com.tencent.spp_rpc.RpcHello/Sum");

  msg.GetVideoMutableReqHead()->set_callee("com.tencent.spp_rpc.RpcHello");
  msg.GetVideoMutableReqHead()->set_func("/com.tencent.spp_rpc.RpcHello/Sum");

  msg.GetVideoMutableReqHead()->mutable_version_info()->set_app_id("1000005");
  msg.GetVideoMutableReqHead()->mutable_bucket_info()->set_bucket_id(4);
  msg.GetVideoMutableReqHead()->mutable_device_info()->set_guid("pb_test_guid_11");

  // qq
  auto token = msg.GetVideoMutableReqHead()->add_login_token();
  token->set_type(1);
  token->set_account("12345678");

  // 更新包头
  std::vector<char>req_buf;
  msg.mutable_req()->Encode(&req_buf);
  msg.EncodeQQlive();
  auto qqlive_head = (*msg.mutable_req()->logic_header.mutable_trans_info())["qqlive_head"];
  EXPECT_STRNE(qqlive_head.c_str(), "");

  msg.SetReqPkg(req_buf.data(), req_buf.size());
  EXPECT_EQ(msg.DecodeReq(), 0);

  msg.ParseLoginToken();
  EXPECT_EQ(msg.qq(), "12345678");
  EXPECT_EQ(msg.CheckParams(), 0);
}
