#!/bin/sh
# 压测脚本
# 压测规范参考文档：https://git.code.oa.com/videobase/spp_rpc/wikis/pressure
