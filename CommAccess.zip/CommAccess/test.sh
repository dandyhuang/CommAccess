#!/bin/sh
# 接口测试脚本
# 接口测试规范参考文档：https://git.code.oa.com/videobase/spp_rpc/wikis/test/

# sumeru环境
cd /usr/local/services/spp/client/CommAccess/test/
./CommAccess_test --gtest ../conf/CommAccess_integration_testing.xml
# 赤兔环境
# /usr/local/services/spp_PbAccess-2.3/client/PbAccess/test/
# ./PbAccess_test --gtest ../conf/PbAccess.xml
